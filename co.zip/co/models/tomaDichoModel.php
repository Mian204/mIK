<?php 

class tomaDichoModel extends Model{
	public function __construct(){
		parent::__construct();
	}

	public function generarId(){
		$sql="DECLARE @idTomaDicho varchar(45);
		EXECUTE [dbo].[sp_a001_02_contador] '011001','002000','6', @idTomaDicho output ;
		select @idTomaDicho as idTomaDicho;";
		
		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function generarIdDiligencia(){
		$sql="DECLARE @idDiligencia varchar(45);
		EXECUTE [dbo].[sp_a001_02_contador] '011002','002000','6', @idDiligencia output;
		select @idDiligencia as idDiligencia;";
		
		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}
	
	public function getTomaDichos($idTomaDicho,$idTomaDichoArray,$rc,$rucContribuyente,$codTercero,$rucTercero,$fecTomaDichoIni,$fecTomaDichoFin,$resultado,$regResponsableDiligencia,$codAuxRc,$codEjeRc,$fecRegIni,$fecRegFin,$estado,$estadoArray){

		$sql="SELECT
		a.id,
		a.rc,
		b.num_exp_coa as rec,
		b.num_ruc as rucContribuyente,
		b.num_ruc+' - '+b.razon_social as rucDesc,
		b.direccion collate database_default + ' - ' + b.desc_ubigeo  + ' (' + b.referencia + ')'  as direccionContribuyente,
		a.codTercero,
		b.num_ruc_ter as rucTercero,
		b.num_ruc_ter+' - '+b.nom_ter as rucTerceroDesc,
		(select f.direccion  + ' - ' + f.desc_ubigeo + ' (' + f.referencia +')'  from db_fext.reps.ficha_nacional f where f.ruc=b.num_ruc_ter) as direccionTercero,
		CONVERT(char(10), a.fecTomaDicho, 126) as fecTomaDicho,
		CONVERT(char(10), a.fecUltimaDiligencia, 126) as fecUltimaDiligencia,
		a.resultado,
		case 
		when a.resultado='0' then '0 - FRUSTADO'
		when a.resultado='1' then '1 - NO HA PRESENTADO ESCRITO'
		when a.resultado='2' then '2 - NO ES CLIENTE DEL EJECUTADO'
		when a.resultado='3' then '3 - ES CLIENTE DEL EJECUTADO, SIN MONTO A RETENER'
		when a.resultado='4' then '4 - ES CLIENTE DEL EJECUTADO, CON MONTO A RETENER'
		end as resultadoDesc,

		a.subResultado,
		case 
		when a.subResultado='01' then '01 - NO SE UBICA DIRECCIÓN'
        when a.subResultado='02' then '02 - DOMICILIO CERRADO'
        when a.subResultado='03' then '03 - DIRECCIÓN INCORRECTA'
        when a.subResultado='04' then '04 - SIN ACCESO AL DOMICILIO'
        when a.subResultado='05' then '05 - ACTITUD INDIFERENTE'
        when a.subResultado='06' then '06 - ENCARGADO SIN AUTORIDAD'
        when a.subResultado='07' then '07 - TELEFONO APAGADO'
        when a.subResultado='08' then '08 - TELEFONO INCORRECTO'
        when a.subResultado='21' then '21 - FINALIZACIÓN DE CONTRADO'
        when a.subResultado='22' then '22 - NUNCA FUE CLIENTE'
        when a.subResultado='31' then '31 - PAGÓ AL DEUDOR'
        when a.subResultado='32' then '32 - PAGO A FUTURO'
        when a.subResultado='33' then '33 - SIN LIQUIDEZ'
        when a.subResultado='34' then '34 - FIDEICOMISO'
        when a.subResultado='35' then '35 - FACTORING'
        when a.subResultado='36' then '36 - FACTURA CON ERROR'
        when a.subResultado='37' then '37 - TRUEQUE'
		end as subResultadoDesc,

		a.mtoInformado,
		a.nombreEncargadoTer,
		a.telefonoEncargadoTer,
		a.correoEncargadoTer,
		a.regResponsableDiligencia,
		a.regResponsableDiligencia + ' - ' +db_6E2000.dbo.a000_ftUsuarioDesc(a.regResponsableDiligencia) as regResponsableDiligenciaDesc,
		a.usuReg,
		CONVERT(char(10), a.fecReg, 126) as fecReg,
		a.usuMod,
		CONVERT(char(10), a.fecMod, 126) as fecMod,	
		a.estado,
		case 
		when a.estado='00' then '00 - BORRADOR'
		when a.estado='01' then '01 - PEND. DILIGENCIA'
		when a.estado='02' then '02 - FINALIZADO'
		end as estadoDesc,
		b.cod_aux_rc as codAuxRc,
		b.cod_aux_rc + ' - ' +db_6E2000.dbo.a000_ftUsuarioDesc(b.cod_aux_rc) as codAuxRcDesc,
		b.cod_eje_rc as codEjeRc,
		(select count(*) from a011_diligencia d where d.idTomaDicho=a.id and d.estado<>'DE') as cantDiligencias
	

		FROM db_6E2000.dbo.a011_tomaDicho a
		left join db_cobranza.intr.embargos_terceros b on b.num_rc = a.rc and b.num_ter = a.codTercero
		WHERE a.id is not null";


		if ($idTomaDicho=='*'){
			if (count($idTomaDichoArray)>0){

				$idTomaDichoSerie='';
				foreach($idTomaDichoArray as $item){
		 			$idTomaDichoSerie.="'".$item."',";
		 		}

				$idTomaDichoSerie = substr($idTomaDichoSerie, 0, strlen($idTomaDichoSerie) - 1 );
				$sql=$sql." and a.id in ($idTomaDichoSerie)";
			}

		}else{
			if($idTomaDicho<>''){
				$sql=$sql." and a.id = '$idTomaDicho'";
			}
		}	

		if ($rc != '' ){
			$sql=$sql." and a.rc = '$rc'";
		}
		if ($rucContribuyente != '' ){
			$sql=$sql." and b.num_ruc = '$rucContribuyente'";
		}
		if ($rucTercero != '' ){
			$sql=$sql." and a.num_ruc_ter = '$rucTercero'";
		}		
		if (strtotime(str_replace('/', '-', $fecTomaDichoIni)) and strtotime(str_replace('/', '-', $fecTomaDichoFin))){

			$fecTomaDichoIni=date('Y-m-d',strtotime(str_replace('/', '-', $fecTomaDichoIni)));
			$fecTomaDichoFin=date('Y-m-d',strtotime(str_replace('/', '-', $fecTomaDichoFin)));

			$sql=$sql." and a.fecTomaDicho between '".$fecTomaDichoIni." 00:00:00' and '".$fecTomaDichoFin." 23:59:59'";
		}
		if ($resultado != '' ){
			$sql=$sql." and a.resultado = '$resultado'";
		}
		if ($codAuxRc != '' ){
			$sql=$sql." and b.cod_aux_rc = '$codAuxRc'";
		}
		if ($codEjeRc != '' ){
			$sql=$sql." and b.cod_eje_rc = '$codEjeRc'";
		}
		if ($regResponsableDiligencia != '' ){
			$sql=$sql." and a.regResponsableDiligencia = '$regResponsableDiligencia'";
		}

		if (strtotime(str_replace('/', '-', $fecRegIni)) and strtotime(str_replace('/', '-', $fecRegFin))){

			$fecRegIni=date('Y-m-d',strtotime(str_replace('/', '-', $fecRegIni)));
			$fecRegFin=date('Y-m-d',strtotime(str_replace('/', '-', $fecRegFin)));

			$sql=$sql." and a.fecReg between '".$fecRegIni." 00:00:00' and '".$fecRegFin." 23:59:59'";
		}

		if ($estado=='*'){
			if (count($estadoArray)>0){

				$estadoSerie='';
				foreach($estadoArray as $item){
		 			$estadoSerie.="'".$item."',";
		 		}

				$estadoSerie = substr($estadoSerie, 0, strlen($estadoSerie) - 1 );
				$sql=$sql." and a.estado in ($estadoSerie)";
			}

		}else{
			if($estado<>''){
				$sql=$sql." and a.estado = '$estado'";
			}
		}	

		$sql=$sql." order by a.id desc";

		//echo $sql;
		


		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}
	
	public function getDiligencias($idDiligencia,$idTomaDicho,$fecDiligenciaIni,$fecDiligenciaFin,$resultado,$regResponsableDiligencia,$fecRegIni,$fecRegFin,$estado,$estadoArray){

		$sql="select 
		c.id,
		c.idTomaDicho,
		c.fecDiligencia,
		c.resultado,
		case 
		when c.resultado='0' then '0 - FRUSTRADO'
		when c.resultado='1' then '1 - NO HA PRESENTADO ESCRITO'
		when c.resultado='2' then '2 - NO ES CLIENTE DEL EJECUTADO'
		when c.resultado='3' then '3 - ES CLIENTE DEL EJECUTADO, SIN MONTO A RETENER'
		when c.resultado='4' then '4 - ES CLIENTE DEL EJECUTADO, CON MONTO A RETENER'
		end as resultadoDesc,

		c.subResultado,
		case 
		when c.subResultado='01' then '01 - NO SE UBICA DIRECCIÓN'
        when c.subResultado='02' then '02 - DOMICILIO CERRADO'
        when c.subResultado='03' then '03 - DIRECCIÓN INCORRECTA'
        when c.subResultado='04' then '04 - SIN ACCESO AL DOMICILIO'
        when c.subResultado='05' then '05 - ACTITUD INDIFERENTE'
        when c.subResultado='06' then '06 - ENCARGADO SIN AUTORIDAD'
        when c.subResultado='07' then '07 - TELEFONO APAGADO'
        when c.subResultado='08' then '08 - TELEFONO INCORRECTO'
        when c.subResultado='21' then '21 - FINALIZACIÓN DE CONTRADO'
        when c.subResultado='22' then '22 - NUNCA FUE CLIENTE'
        when c.subResultado='31' then '31 - PAGÓ AL DEUDOR'
        when c.subResultado='32' then '32 - PAGO A FUTURO'
        when c.subResultado='33' then '33 - SIN LIQUIDEZ'
        when c.subResultado='34' then '34 - FIDEICOMISO'
        when c.subResultado='35' then '35 - FACTORING'
        when c.subResultado='36' then '36 - FACTURA CON ERROR'
        when c.subResultado='37' then '37 - TRUEQUE'
		end as subResultadoDesc,

		c.observacion,
		c.mtoInformado,
		c.nombreEncargadoTer,
		c.telefonoEncargadoTer,
		c.correoEncargadoTer,
		c.regResponsableDiligencia,
		c.usuReg,
		CONVERT(char(10), c.fecReg, 126) as fecReg,
		c.usuMod,
		CONVERT(char(10), c.fecMod, 126) as fecMod,
		c.estado,
		a.rc,
		a.rucContribuyente,
		a.rucContribuyente+' - '+b.razon_social as rucDesc,
		a.codTercero,
		b.num_ruc_ter as rucTercero,
		b.num_ruc_ter+' - '+b.nom_ter as rucTerceroDesc,
		CONVERT(char(10), a.fecTomaDicho, 126) as fecTomaDicho,
		

		--a.mtoInformado,
		--a.nombreEncargadoTer,
		--a.telefonoEncargadoTer,
		--a.correoEncargadoTer,
		--a.regResponsableDiligencia,
		--a.usuReg,
		--CONVERT(char(10), a.fecReg, 126) as fecReg,
		--a.usuMod,
		--CONVERT(char(10), a.fecMod, 126) as fecMod,	
		--a.estado,
		case 
		when a.estado='00' then '00 - BORRADOR'
		when a.estado='01' then '01 - PEND. DILIGENCIA'
		when a.estado='02' then '02 - CONCLUIDO'
		end as estadoDesc,
		b.cod_aux_rc as codAuxRc,
		b.cod_eje_rc as codEjeRc
			

		from db_6E2000.dbo.a011_tomaDicho a
		inner join db_6E2000.dbo.a011_diligencia c on c.idTomaDicho = a.id
		left join db_cobranza.intr.embargos_terceros b on b.num_rc = a.rc and b.num_ter = a.codTercero
		where a.rc is not null";

		if ($idDiligencia != '' ){
			$sql=$sql." and c.id = '$idDiligencia'";
		}
		if ($idTomaDicho != '' ){
			$sql=$sql." and c.idTomaDicho = '$idTomaDicho'";
		}
		if (strtotime(str_replace('/', '-', $fecDiligenciaIni)) and strtotime(str_replace('/', '-', $fecDiligenciaFin))){

			$fecDiligenciaIni=date('Y-m-d',strtotime(str_replace('/', '-', $fecDiligenciaIni)));
			$fecDiligenciaFin=date('Y-m-d',strtotime(str_replace('/', '-', $fecDiligenciaFin)));

			$sql=$sql." and a.fecDiligencia between '".$fecDiligenciaIni." 00:00:00' and '".$fecDiligenciaFin." 23:59:59'";
		}
		if ($resultado != '' ){
			$sql=$sql." and c.resultado = '$resultado'";
		}
		if ($regResponsableDiligencia != '' ){
			$sql=$sql." and c.regResponsableDiligencia = '$regResponsableDiligencia'";
		}

		if (strtotime(str_replace('/', '-', $fecRegIni)) and strtotime(str_replace('/', '-', $fecRegFin))){

			$fecRegIni=date('Y-m-d',strtotime(str_replace('/', '-', $fecRegIni)));
			$fecRegFin=date('Y-m-d',strtotime(str_replace('/', '-', $fecRegFin)));

			$sql=$sql." and c.fecReg between '".$fecRegIni." 00:00:00' and '".$fecRegFin." 23:59:59'";
		}
		if ($estado=='*'){
			if (count($estadoArray)>0){

				$estadoSerie='';
				foreach($estadoArray as $item){
		 			$estadoSerie.="'".$item."',";
		 		}

				$estadoSerie = substr($estadoSerie, 0, strlen($estadoSerie) - 1 );
				$sql=$sql." and c.estado in ($estadoSerie)";
			}

		}else{
			if($estado<>''){
				$sql=$sql." and c.estado = '$estado'";
			}
		}	

	
		$sql=$sql." order by c.id desc";

		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function insTomaDicho($idTomaDicho,$rc,$codTercero,$regResponsableDiligencia,$usuReg,$estado){

		$sql="INSERT INTO db_6E2000.dbo.a011_tomaDicho(id,rc,codTercero,regResponsableDiligencia,fecReg,usuReg,estado) VALUES('$idTomaDicho','$rc','$codTercero','$regResponsableDiligencia',getdate(),'$usuReg','$estado');";

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function insDiligencia($idDiligencia,$idTomaDicho,$fecDiligencia,$resultado,$subResultado,$observacion,$mtoInformado,$nombreEncargadoTer,$telefonoEncargadoTer,$correoEncargadoTer,$regResponsableDiligencia,$usuReg,$estado){

		$fecDiligencia=date('Y-m-d',strtotime(str_replace('/', '-', $fecDiligencia)));
		
		$sql="insert into db_6E2000.dbo.a011_diligencia(id,idTomaDicho,fecDiligencia,resultado,subResultado,observacion,mtoInformado,nombreEncargadoTer,telefonoEncargadoTer,correoEncargadoTer,regResponsableDiligencia,usuReg,fecReg,estado) VALUES('$idDiligencia','$idTomaDicho','$fecDiligencia','$resultado','$subResultado','$observacion','$mtoInformado','$nombreEncargadoTer','$telefonoEncargadoTer','$correoEncargadoTer','$regResponsableDiligencia','$usuReg',getdate(),'01');";


		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function updTomaDicho($idTomaDicho,$rc,$codTercero,$regResponsableDiligencia,$usuMod,$estado){

		$sql="UPDATE db_6E2000.dbo.a011_tomaDicho 
		SET 
		rc = '$rc',
		codTercero = '$codTercero',
		regResponsableDiligencia = '$regResponsableDiligencia',
		estado = '$estado',
		fecMod = getdate(),
		usuMod = '$usuMod'
		WHERE 
		id = '$idTomaDicho'";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function updDiligencia($idDiligencia,$idTomaDicho,$fecDiligencia,$resultado,$subResultado,$observacion,$mtoInformado,$nombreEncargadoTer,$telefonoEncargadoTer,$correoEncargadoTer,$regResponsableDiligencia,$usuMod,$estado){

		$fecDiligencia=date('Y-m-d',strtotime(str_replace('/', '-', $fecDiligencia)));

		$sql="UPDATE db_6E2000.dbo.a011_diligencia 
		SET 
		fecDiligencia = '$fecDiligencia',
		resultado = '$resultado',
		subResultado = '$subResultado',
		observacion = '$observacion',
		mtoInformado = '$mtoInformado',
		nombreEncargadoTer = '$nombreEncargadoTer',
		telefonoEncargadoTer = '$telefonoEncargadoTer',
		correoEncargadoTer = '$correoEncargadoTer',
		regResponsableDiligencia = '$regResponsableDiligencia',
		usuMod = '$usuMod',
		fecMod = getdate(),
		estado = '$estado'
		WHERE 
		id = '$idDiligencia'";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function delTomaDicho($idTomaDicho){
		
		$sql="UPDATE db_6E2000.dbo.a011_tomaDicho 
		SET 
		estado='DE'
		WHERE 
		id = '$idTomaDicho' ";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function delDiligencia($idDiligencia){
		
		$sql="UPDATE db_6E2000.dbo.a011_diligencia 
		SET 
		estado='DE'
		WHERE 
		id = '$idDiligencia' ";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function conTomaDicho($idTomaDicho,$usuMod){

		$sql="
		declare @totalDiligenciaResultado as integer;
		declare @totalDiligencia as integer;
		
		declare @idDiligenciaTomaDicho as integer;
		declare @idDiligenciaUltima as integer;


		


		set @totalDiligenciaResultado = 
		(select count(*) from db_6E2000.dbo.a011_diligencia 
		where idTomaDicho='$idTomaDicho'
		and resultado in ('2','3','4')
		and estado='01')

		set @totalDiligencia = 
		(select count(*) from db_6E2000.dbo.a011_diligencia 
		where idTomaDicho='$idTomaDicho'
		and resultado in ('0','1','2','3','4')
		and estado='01')

		set @idDiligenciaTomaDicho = (select top 1 id from db_6E2000.dbo.a011_diligencia  
		where idTomaDicho='$idTomaDicho'
		and resultado in ('2','3','4')
		and estado='01'
		order by fecDiligencia desc,id desc)

		set @idDiligenciaUltima = (select top 1 id from db_6E2000.dbo.a011_diligencia  
		where idTomaDicho='$idTomaDicho'
		and resultado in ('0','1','2','3','4')
		and estado='01'
		order by fecDiligencia desc,id desc)


	
		if @totalDiligenciaResultado > 0
			begin
				
				UPDATE
					Tabla_A
				SET
					Tabla_A.fecTomaDicho = Tabla_B.fecDiligencia,
					Tabla_A.resultado = Tabla_B.resultado,
					Tabla_A.subResultado = Tabla_B.subResultado,
					Tabla_A.mtoInformado = Tabla_B.mtoInformado,
					Tabla_A.nombreEncargadoTer = Tabla_B.nombreEncargadoTer,
					Tabla_A.telefonoEncargadoTer = Tabla_B.telefonoEncargadoTer,
					Tabla_A.correoEncargadoTer = Tabla_B.correoEncargadoTer,
					Tabla_A.regResponsableDiligencia = Tabla_B.regResponsableDiligencia,
					Tabla_A.estado = '02',
					Tabla_A.fecMod = getdate(),
					Tabla_A.usuMod = '$usuMod'
				FROM
					db_6E2000.dbo.a011_tomaDicho  AS Tabla_A
					INNER JOIN db_6E2000.dbo.a011_diligencia AS Tabla_B
						ON Tabla_A.id = Tabla_B.idTomaDicho
				WHERE
					Tabla_A.id = '$idTomaDicho'
					and 
					Tabla_B.id = @idDiligenciaTomaDicho



			end
		else

			if @totalDiligencia > 0
				begin

					UPDATE
						Tabla_A
					SET
						fecTomaDicho = null,
						resultado = Tabla_B.resultado,
						subResultado = Tabla_B.subResultado,
						mtoInformado = null,
						nombreEncargadoTer = null,
						telefonoEncargadoTer = null,
						correoEncargadoTer = null,
						estado = '01',
						fecMod = getdate(),
						usuMod = '$usuMod'
						
					FROM
						db_6E2000.dbo.a011_tomaDicho  AS Tabla_A
						INNER JOIN db_6E2000.dbo.a011_diligencia AS Tabla_B
							ON Tabla_A.id = Tabla_B.idTomaDicho
					WHERE
						Tabla_A.id = '$idTomaDicho'
						and 
						Tabla_B.id = @idDiligenciaUltima

				end
			else
				begin
					UPDATE db_6E2000.dbo.a011_tomaDicho 
					SET 
					fecTomaDicho = null,
					resultado = null,
					subResultado = null,
					mtoInformado = null,
					nombreEncargadoTer = null,
					telefonoEncargadoTer = null,
					correoEncargadoTer = null,
					estado = '01',
					fecMod = getdate(),
					usuMod = '$usuMod'
					WHERE 
					id = '$idTomaDicho'
				end




		/**Ultima Fecha**/

		UPDATE
			Tabla_A
		SET
			fecUltimaDiligencia = Tabla_B.fecDiligencia
		FROM
			db_6E2000.dbo.a011_tomaDicho  AS Tabla_A
			INNER JOIN db_6E2000.dbo.a011_diligencia AS Tabla_B
				ON Tabla_A.id = Tabla_B.idTomaDicho
		WHERE
			Tabla_A.id = '$idTomaDicho'
			and 
			Tabla_B.id = @idDiligenciaUltima

		";



		
		$this->_db1->query($sql) or die($sql);
	}

	public function getDatosRC($rc){
		
		$sql="select 
		top 1 
		a.num_rc as rc, 
		a.num_ruc as ruc, 
		a.num_exp_rc as rec, 
		a.razon_social as razonSocial
		from db_cobranza.intr.embargos_terceros a
		where a.num_rc='$rc'";
				
		$result = $this->_db1->query($sql) or die($sql);
		return $result;	
	}

	public function getListaTerceros($rc){
		
		$sql="select 
		a.num_ter as codTercero,
		a.num_ruc_ter as rucTercero,
		a.nom_ter as nombreTercero
		from db_cobranza.intr.embargos_terceros a
		where a.num_rc='$rc'
		order by a.nom_ter";
		
		$result = $this->_db1->query($sql) or die($sql);
		return $result;	
	}


	
}
?>