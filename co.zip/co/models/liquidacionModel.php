<?php 
class liquidacionModel extends Model{

	public function __construct(){
		parent::__construct();

	}

	public function getLiquidaciones($ID,$RLADUANA,$RLANO,$RLNROLIQ,$RLLIBTRI,$EXP_COACTIVO,$SUPERVISOR,$EQUIPO,$IND_ASOC,$ultimosRegistros){

		$sql="SELECT ";

		if ($ultimosRegistros != '' ){
			$sql=$sql." top 100 ";
		}		

		$sql=$sql."a.TIPO_LIQUIDACION,
		a.ADUANA,
		a.NUMERO_LIQUIDACION,
		CONVERT(char(10), a.FEC_LIQUIDACION, 126) as FEC_LIQUIDACION,	
		a.TIP_LIQUIDACION,
		a.TIP_USUARIO,
		a.RLCODUSU,
		a.RLTIPDOC,
		a.RLLIBTRI,
		a.RLCOMITE,
		a.RLCODORIDESC,
		a.RLDIRECC,
		a.COD_INFRACCION,
		a.RLCODCO2,
		a.RLCODCO3,
		a.RLDETALL,
		a.RLDETAL2,
		a.RLDETAL3,
		a.RLDETAL4,
		a.RLDETAL5,
		a.MONEDA,
		a.MONTO_SOLES,
		a.MONTO_DOLARES,
		a.PAGOS_SOLES,
		a.PAGOS_DOLARES,
		CONVERT(char(10), a.FEC_CANCELADO, 126) as FEC_CANCELADO,	
		a.FEC_CONTABLE,
		a.TIP_CANCELACION,
		a.FEC_NOT_AGENT,
		a.FEC_NOT_COMIT,
		a.DOC_ASO,
		a.DES_DOC_ASO,
		a.RLTIPRES,
		a.RLNRORES,
		a.ENT_RECAUDADORA,
		a.FEC_RECLAMO_CO,
		a.RLHORNOT,
		a.ULT_DIA_PAG_AGENT,
		a.ULT_DIA_PAG_COM,
		a.VENC_ADMI_COM,
		a.RLMONRECAR,
		a.RLMONINTER,
		a.RLRECAADIC,
		a.RLINTEFRAC,
		a.RAZONELI,
		a.RLANOPAN,
		a.RLPOLANT,
		a.RLANOLAN,
		a.RLLIQANT,
		a.NUMERO_RECEPCION,
		a.FEC_COACTIVO,
		a.EXP_DE_RECLAMO,
		a.FEC_RECLAMO_LC,
		a.RESULTADO_RECLAMO,
		a.FEC_ANULADA,
		a.EXP_COACTIVO,
		a.FEC_ING_LC,
		a.ESTADO_LC,
		a.DES_ESTADO_LC,
		a.DES_ESTADO_EXP,
		a.FEC_EST_EXP,
		a.RLSTATUS_EXP,
		a.RLULTIMO_EXP,
		a.ERRORES_EN_DATA,
		a.RLADUANA,
		a.RLANO,
		a.RLNROLIQ,
		a.RLAREA,
		a.RLADUASO,
		a.RLANOASO,
		a.RLNUMASO,
		a.ID,
		a.ID_CARGA_SICC,
		a.COD_ASOC_TOTAL,
		a.FEC_CRE_SICC,
		a.EXP_COAC_RELACIONADO,
		a.MEMO,
		a.OBSERVACION_MEMO,
		a.FECHA_REPORTE,
		a.ESTADO_FALLECIDO_SI_NO,
		a.ESTADO_FICHA_RUC,
		a.FEC_INI_ASIG,
		a.FEC_FIN_ASIG,
		a.SUPERVISOR,
		a.EQUIPO,
		a.IND_ASOC,
		a.IND_ORDEN_LIMPIEZA,
		a.IND_PAGO,
		a.SALDO_SIN_INT_SOLES,
		a.SALDO_SIN_INT_DOLARES
		FROM db_6E2000.dbo.DEUDA_ADUANA_SIGAD a
		where a.NUMERO_LIQUIDACION is not null"; 

		if ($ID != '' ){
			$sql=$sql." and a.ID = '$ID'";
		}
		if ($RLADUANA != '' ){
			$sql=$sql." and a.RLADUANA = '$RLADUANA'";
		}
		if ($RLANO != '' ){
			$sql=$sql." and a.RLANO = '$RLANO'";
		}
		if ($RLNROLIQ != '' ){
			$sql=$sql." and a.RLNROLIQ = '$RLNROLIQ'";
		}	
		if ($RLLIBTRI != '' ){
			$sql=$sql." and a.RLLIBTRI = '$RLLIBTRI'";
		}	
		if ($EXP_COACTIVO != '' ){
			$sql=$sql." and a.EXP_COACTIVO like '%$EXP_COACTIVO%'";
		}
		if ($SUPERVISOR != '' ){
			$sql=$sql." and a.SUPERVISOR like '%$SUPERVISOR%'";
		}
		if ($EQUIPO != '' ){
			$sql=$sql." and a.EQUIPO like '%$EQUIPO%'";
		}	
		if ($IND_ASOC != '' ){
			$sql=$sql." and a.IND_ASOC = '$IND_ASOC'";
		}	


		
		
		$sql=$sql." order by a.ID desc";
		
		// if ($fecha_nacimiento != '' ){
		// 	$fecha_nacimiento=date('Y-m-d',strtotime(str_replace('/', '-', $fecha_nacimiento)));

		// 	$sql=$sql." and a.fecha_nacimiento between '".$fecha_nacimiento." 00:00:00' and '".$fecha_nacimiento." 23:59:59'";
		// }
		
		
	

		//echo $sql;
		// return true;

		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
				
	}

	public function getDatosDeudor($RLLIBTRI){

		$sql="SELECT distinct
		
		a.RLLIBTRI,
		a.RLCOMITE
		
		FROM db_6E2000.dbo.DEUDA_ADUANA_SIGAD a
		where a.NUMERO_LIQUIDACION is not null"; 
		
		if ($RLLIBTRI != '' ){
			$sql=$sql." and a.RLLIBTRI = '$RLLIBTRI'";
		}	
		
		
		
		//$sql=$sql." order by a.ID desc";
		
		// if ($fecha_nacimiento != '' ){
		// 	$fecha_nacimiento=date('Y-m-d',strtotime(str_replace('/', '-', $fecha_nacimiento)));

		// 	$sql=$sql." and a.fecha_nacimiento between '".$fecha_nacimiento." 00:00:00' and '".$fecha_nacimiento." 23:59:59'";
		// }	
		
	

		//echo $sql;
		// return true;

		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
				
	}

	public function getPagosACuenta($RLADUANA,$RLANO,$RLNROLIQ,$RLLIBTRI,$RLADUASO,$RLANOASO,$RLNUMASO){

		$sql="
		IF SUBSTRING('$RLLIBTRI', 1, 1) = 1

		BEGIN

		SELECT NUMERO_LIQUIDACION AS ID, RLLIBTRI,RLCOMITE,FEC_LIQUIDACION,FEC_CANCELADO,MONTO_DOLARES,MONTO_SOLES,RLCODORIDESC,RLADUANA,RLANO,RLNROLIQ,RLADUASO,RLANOASO,RLNUMASO  FROM [db_6E2000].[dbo].[DEUDA_ADUANA_SIGAD] 
		WHERE IND_PAGO = '1' 
		and rllibtri = '$RLLIBTRI'
		or  rllibtri = SUBSTRING('$RLLIBTRI', 3, 8)
		ORDER BY FEC_CANCELADO DESC


		END

		ELSE

		BEGIN

		SELECT NUMERO_LIQUIDACION AS ID, RLLIBTRI,RLCOMITE,FEC_LIQUIDACION,FEC_CANCELADO,MONTO_DOLARES,MONTO_SOLES,RLCODORIDESC,RLADUANA,RLANO,RLNROLIQ,RLADUASO,RLANOASO,RLNUMASO  FROM [db_6E2000].[dbo].[DEUDA_ADUANA_SIGAD] 
		WHERE IND_PAGO = '1'
		and rllibtri = '$RLLIBTRI'
		ORDER BY FEC_CANCELADO DESC

		END";
	

		// if ($id=='*'){
		// 	if (count($idArray)>0){

		// 		$idSerie='';
		// 		foreach($idArray as $item){
		//  			$idSerie.="'".$item."',";
		//  		}

		// 		$idSerie = substr($idSerie, 0, strlen($idSerie) - 1 );
		// 		$sql=$sql." and a.id in ($idSerie)";
		// 	}

		// }else{
		// 	if($id<>''){
		// 		$sql=$sql." and a.id = '$id'";
		// 	}
		// }	

		
		// if ($fecha_nacimiento != '' ){
		// 	$fecha_nacimiento=date('Y-m-d',strtotime(str_replace('/', '-', $fecha_nacimiento)));

		// 	$sql=$sql." and a.fecha_nacimiento between '".$fecha_nacimiento." 00:00:00' and '".$fecha_nacimiento." 23:59:59'";
		// }
	
		// echo $sql;
		// return true;

		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
				
	}



	public function getLiquidacionesAsociadas($ID,$RLADUANA,$RLANO,$RLNROLIQ){

		$sql="select 
		x.TIPO_LIQUIDACION,
		x.ADUANA,
		x.NUMERO_LIQUIDACION,
		CONVERT(char(10), x.FEC_LIQUIDACION, 126) as FEC_LIQUIDACION,
		x.TIP_LIQUIDACION,
		x.TIP_USUARIO,
		x.RLCODUSU,
		x.RLTIPDOC,
		x.RLLIBTRI,
		x.RLCOMITE,
		x.RLCODORIDESC,
		x.RLDIRECC,
		x.COD_INFRACCION,
		x.RLCODCO2,
		x.RLCODCO3,
		x.RLDETALL,
		x.RLDETAL2,
		x.RLDETAL3,
		x.RLDETAL4,
		x.RLDETAL5,
		x.MONEDA,
		x.MONTO_SOLES,
		x.MONTO_DOLARES,
		x.PAGOS_SOLES,
		x.PAGOS_DOLARES,
		CONVERT(char(10), x.FEC_CANCELADO, 126) as FEC_CANCELADO,
		x.FEC_CONTABLE,
		x.TIP_CANCELACION,
		x.FEC_NOT_AGENT,
		x.FEC_NOT_COMIT,
		x.DOC_ASO,
		x.DES_DOC_ASO,
		x.RLTIPRES,
		x.RLNRORES,
		x.ENT_RECAUDADORA,
		x.FEC_RECLAMO_CO,
		x.RLHORNOT,
		x.ULT_DIA_PAG_AGENT,
		x.ULT_DIA_PAG_COM,
		x.VENC_ADMI_COM,
		x.RLMONRECAR,
		x.RLMONINTER,
		x.RLRECAADIC,
		x.RLINTEFRAC,
		x.RAZONELI,
		x.RLANOPAN,
		x.RLPOLANT,
		x.RLANOLAN,
		x.RLLIQANT,
		x.NUMERO_RECEPCION,
		x.FEC_COACTIVO,
		x.EXP_DE_RECLAMO,
		x.FEC_RECLAMO_LC,
		x.RESULTADO_RECLAMO,
		x.FEC_ANULADA,
		x.EXP_COACTIVO,
		x.FEC_ING_LC,
		x.ESTADO_LC,
		x.DES_ESTADO_LC,
		x.DES_ESTADO_EXP,
		x.FEC_EST_EXP,
		x.RLSTATUS_EXP,
		x.RLULTIMO_EXP,
		x.ERRORES_EN_DATA,
		x.RLADUANA,
		x.RLANO,
		x.RLNROLIQ,
		x.RLAREA,
		x.RLADUASO,
		x.RLANOASO,
		x.RLNUMASO,
		x.ID,
		x.ID_CARGA_SICC,
		x.COD_ASOC_TOTAL,
		x.FEC_CRE_SICC,
		x.EXP_COAC_RELACIONADO,
		x.MEMO,
		x.OBSERVACION_MEMO,
		x.FECHA_REPORTE,
		x.ESTADO_FALLECIDO_SI_NO,
		x.ESTADO_FICHA_RUC,
		x.FEC_INI_ASIG,
		x.FEC_FIN_ASIG,
		x.SUPERVISOR,
		x.EQUIPO,
		x.IND_ASOC,
		x.IND_ORDEN_LIMPIEZA,
		x.IND_PAGO,
		x.SALDO_SIN_INT_SOLES,
		x.SALDO_SIN_INT_DOLARES
		

		from db_6E2000.dbo.DEUDA_ADUANA_SIGAD AS X
		inner join db_6E2000.dbo.DEUDA_ADUANA_SIGAD AS Y ON (Y.RLADUANA = X.RLADUASO AND Y.RLANO = X.RLANOASO AND Y.RLNROLIQ = X.RLNUMASO)
		or (Y.RLADUANA = X.RLADUANA AND Y.RLANO = X.RLANO AND Y.RLNROLIQ = X.RLNROLIQ)
		and X.FEC_LIQUIDACION >= Y.FEC_LIQUIDACION
		
		where 
		x.TIPO_LIQUIDACION <> 'LC_ANULADA' ";


		if ($ID != '' ){
			$sql=$sql." and Y.ID = '$ID'";
		}

		if ($RLADUANA != '' ){
			$sql=$sql." and Y.RLADUANA = '$RLADUANA'";
		}

		if ($RLANO != '' ){
			$sql=$sql." and Y.RLANO = '$RLANO'";
		}

		if ($RLNROLIQ != '' ){
			$sql=$sql." and Y.RLNROLIQ = '$RLNROLIQ'";
		}

		//$sql=$sql."ORDER BY X.FEC_LIQUIDACION ASC";

		// echo $sql;
		// return true;

		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
				
	}

	public function getLiquidacionesAsociadasDetalle($ID,$RLADUANA,$RLANO,$RLNROLIQ){

		$sql="select 
		d.ID,
		d.RLADUANA,
		d.RLANO,
		d.RLNROLIQ,	
		d.RLADUANA +'-'+ d.RLANO +'-'+ d.RLNROLIQ as NUMERO_LIQUIDACION,
		d.RDCODRUB,
		d.DESCRI,
		d.RDMONDET,
		d.FILLER,
		d.FMOD,
		d.FLAG,
		d.CDIGMOD,
		d.DETMODIF,
		d.ID_CARGA_SICC,
		d.MONEDA,
		d.CONVERSION_SOLES,
		d.CONVERSION_DOLARES,
		d.PAGOS_SOLES,
		d.PAGOS_DOLARES,
		d.SALDO_SIN_INT_SOLES,
		d.SALDO_SIN_INT_DOLARES,
		d.Fec_LIQ
		from
		db_6E2000.dbo.DEUDA_DETALLE_ADUANA_SIGAD d
		where 
		d.id in (


		select x.id 
		from db_6E2000.dbo.DEUDA_ADUANA_SIGAD AS X
				inner join db_6E2000.dbo.DEUDA_ADUANA_SIGAD AS Y ON (Y.RLADUANA = X.RLADUASO AND Y.RLANO = X.RLANOASO AND Y.RLNROLIQ = X.RLNUMASO)
				or (Y.RLADUANA = X.RLADUANA AND Y.RLANO = X.RLANO AND Y.RLNROLIQ = X.RLNROLIQ)
				and X.FEC_LIQUIDACION >= Y.FEC_LIQUIDACION
			
		
		where 
		x.TIPO_LIQUIDACION <> 'LC_ANULADA'";

		if ($ID != '' ){
			$sql=$sql." and Y.ID = '$ID'";
		}

		if ($RLADUANA != '' ){
			$sql=$sql." and Y.RLADUANA = '$RLADUANA'";
		}

		if ($RLANO != '' ){
			$sql=$sql." and Y.RLANO = '$RLANO'";
		}

		if ($RLNROLIQ != '' ){
			$sql=$sql." and Y.RLNROLIQ = '$RLNROLIQ' ";
		}


		$sql=$sql.")";
		

		// return true;

		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
				
	}
	
	public function getLiquidacionesDetalle($ID,$RLADUANA,$RLANO,$RLNROLIQ){

		$sql="select 
		a.ID,
		a.RLADUANA,
		a.RLANO,
		a.RLNROLIQ,
		a.RLADUANA +'-'+ a.RLANO +'-'+ a.RLNROLIQ as NUMERO_LIQUIDACION,
		a.RDCODRUB,
		a.DESCRI,
		a.RDMONDET,
		a.FILLER,
		a.FMOD,
		a.FLAG,
		a.CDIGMOD,
		a.DETMODIF,
		a.ID_CARGA_SICC,
		a.MONEDA,
		a.CONVERSION_SOLES,
		a.CONVERSION_DOLARES,
		a.PAGOS_SOLES,
		a.PAGOS_DOLARES,
		a.SALDO_SIN_INT_SOLES,
		a.SALDO_SIN_INT_DOLARES,
		a.Fec_LIQ


		from 
		db_6E2000.dbo.DEUDA_DETALLE_ADUANA_SIGAD a
		where
		a.RLADUANA is not null ";

		if ($ID != '' ){
			$sql=$sql." and a.ID = '$ID'";
		}

		if ($RLADUANA != '' ){
			$sql=$sql." and a.RLADUANA = '$RLADUANA'";
		}

		if ($RLANO != '' ){
			$sql=$sql." and a.RLANO = '$RLANO'";
		}

		if ($RLNROLIQ != '' ){
			$sql=$sql." and a.RLNROLIQ = '$RLNROLIQ'";
		}

		// echo $sql;
		// return true;

		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
				
	}

	



	
}
?>