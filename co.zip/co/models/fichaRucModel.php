<?php 

class fichaRucModel extends Model{
	public function __construct(){
		parent::__construct();
	}

	
	
	public function getDatosContacto($ruc){

		$sql="select   
		ruc,
		razon_social,
		cod_est as estado,
		direccion as domicilio,
		condicion,
		'TELEFONO' as tipoContacto,
		telef_1 as contacto
		from db_fext.reps.ficha_nacional
		where ruc='$ruc'
		and 
		telef_1<>'-'

		union all

		select   
		ruc,
		razon_social,
		cod_est as estado,
		direccion as domicilio,
		condicion,
		'TELEFONO' as tipoContacto,
		telef_2 as contacto
		from db_fext.reps.ficha_nacional
		where ruc='$ruc'
		and 
		telef_2<>'-'


		union all

		select   
		ruc,
		razon_social,
		cod_est as estado,
		direccion as domicilio,
		condicion,
		'TELEFONO' as tipoContacto,
		telef_3 as contacto
		from db_fext.reps.ficha_nacional
		where ruc='$ruc'
		and 
		telef_3<>'-'

		union all

		select   
		ruc,
		razon_social,
		cod_est as estado,
		direccion as domicilio,
		condicion,
		'FAX' as tipoContacto,
		fax_1 as contacto
		from db_fext.reps.ficha_nacional
		where ruc='$ruc'
		and 
		fax_1<>'-'

		union all

		select   
		ruc,
		razon_social,
		cod_est as estado,
		direccion as domicilio,
		condicion,
		'TELEFONO' as tipoContacto,
		telef_4 as contacto
		from db_fext.reps.ficha_nacional
		where ruc='$ruc'
		and 
		telef_4<>'-'

		union all

		select   
		ruc,
		razon_social,
		cod_est as estado,
		direccion as domicilio,
		condicion,
		'TELEFONO' as tipoContacto,
		telef_5 as contacto
		from db_fext.reps.ficha_nacional
		where ruc='$ruc'
		and 
		telef_5<>'-'

		union all

		select   
		ruc,
		razon_social,
		cod_est as estado,
		direccion as domicilio,
		condicion,
		'TELEFONO' as tipoContacto,
		telef_6 as contacto
		from db_fext.reps.ficha_nacional
		where ruc='$ruc'
		and 
		telef_6<>'-'

		union all

		select   
		ruc,
		razon_social,
		cod_est as estado,
		direccion as domicilio,
		condicion,
		'TELEFONO' as tipoContacto,
		telef_7 as contacto
		from db_fext.reps.ficha_nacional
		where ruc='$ruc'
		and 
		telef_7<>'-'

		union all

		select   
		ruc,
		razon_social,
		cod_est as estado,
		direccion as domicilio,
		condicion,
		'FAX' as tipoContacto,
		fax_2 as contacto
		from db_fext.reps.ficha_nacional
		where ruc='$ruc'
		and 
		fax_2<>'-'

		union all

		select   
		ruc,
		razon_social,
		cod_est as estado,
		direccion as domicilio,
		condicion,
		'CORREO' as tipoContacto,
		correo_1 as contacto
		from db_fext.reps.ficha_nacional
		where ruc='$ruc'
		and 
		correo_1<>'-'

		union all

		select   
		ruc,
		razon_social,
		cod_est as estado,
		direccion as domicilio,
		condicion,
		'CORREO' as tipoContacto,
		correo_2 as contacto
		from db_fext.reps.ficha_nacional
		where ruc='$ruc'
		and 
		correo_2<>'-'";


		
		$sql=$sql." order by 3";

		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}


	public function getDatosRuc($ruc){

		$sql="select   
		ruc,
		razon_social,
		cod_est as estado,
		direccion as domicilio,
		condicion
		from db_fext.reps.ficha_nacional
		where ruc='$ruc'
		";
		
		$sql=$sql." order by 3";

		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}






	public function getMisCompromisosPago($idUsuarioSession){

		// $rucCadena="";

		// if (count($rucArray)>0){
		// 	foreach($rucArray as $item)
	 // 		{
	 // 			$rucCadena=$rucCadena."'".$item."',";
	 // 		}
		// 	$rucCadena = substr($rucCadena, 0, strlen($rucCadena) - 1 );
		// }

		$sql="SELECT TOP 10 
		a.id,
		a.ruc,
		a.ruc+' - '+b.razon_social as rucDesc,
		a.rec,
		a.rc,
		a.numEmb,
		CONVERT(char(10), a.fecPagoPropuesto, 126) as fecPagoPropuesto,
		a.formaPagoPropuesto,
		case 
		when a.formaPagoPropuesto='01' then '01 - BOLETA PAGO 1662'
		when a.formaPagoPropuesto='02' then '02 - CHEQUE'
		when a.formaPagoPropuesto='03' then '03 - NPS'
		when a.formaPagoPropuesto='09' then '09 - OTROS'
		when a.formaPagoPropuesto='99' then '99 - NO ESPECIFICO'
		end as formaPagoPropuesto_desc,
		a.cantidadPagoPropuesto,
		a.dniEncargadoTercero,
		a.nombreEncargadoTercero,
		a.observacion,
		a.fecReg,
		a.usuReg,
		a.fecMod,
		a.usuMod,
		a.estado,
		a.codTercero,
		b.num_ruc_ter as rucTercero,
		b.num_ruc_ter+' - '+ b.nom_ter as rucTerceroDesc,
		b.nom_ter as razonSocialTercero,
		case 
		when a.estado='01' then '01 - ACTIVO'
		end as estado_desc,
		b.num_ruc_ter,
		b.nom_ter

		FROM db_6E2000.dbo.a010_compromisoPago a
		left join db_cobranza.intr.embargos_terceros b on b.num_rc = a.rc and b.num_ter = a.codTercero
		WHERE a.id is not null
		and
		a.estado<>'DE' ";

		if ($idUsuarioSession != "" ){
			$sql=$sql." and a.usuReg = '".$idUsuarioSession."'";
		}
		
	
		//error_log($sql) ;
		$sql=$sql." order by a.id desc";

		


		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}
	
	public function getCompromisoPago($idCompromiso){

		$sql="SELECT
		a.id,
		a.ruc,
		a.ruc+' - '+b.razon_social as rucDesc,
		a.rec,
		a.rc,
		a.numEmb,
		CONVERT(char(10), a.fecPagoPropuesto, 126) as fecPagoPropuesto,
		a.formaPagoPropuesto,
		case 
		when a.formaPagoPropuesto='01' then '01 - BOLETA PAGO 1662'
		when a.formaPagoPropuesto='02' then '02 - CHEQUE'
		when a.formaPagoPropuesto='03' then '03 - NPS'
		when a.formaPagoPropuesto='09' then '09 - OTROS'
		when a.formaPagoPropuesto='99' then '99 - NO ESPECIFICO'
		end as formaPagoPropuesto_desc,
		a.cantidadPagoPropuesto,
		a.dniEncargadoTercero,
		a.nombreEncargadoTercero,
		a.observacion,
		a.fecReg,
		a.usuReg,
		a.fecMod,
		a.usuMod,
		a.estado,
		a.codTercero,
		case 
		when a.estado='01' then '01 - ACTIVO'
		end as estado_desc,
		b.num_ruc_ter,
		b.nom_ter

		FROM db_6E2000.dbo.a010_compromisoPago a
		left join db_cobranza.intr.embargos_terceros b on b.num_rc = a.rc and b.num_ter = a.codTercero
		where a.id = '$idCompromiso'
		and
		a.estado<>'DE'";


		$result = $this->_db1->query($sql) or die($sql);
		return $result;
	}

	public function insCompromiso($idCompromiso,$ruc,$rec,$rc,$fecPagoPropuesto,$formaPagoPropuesto,$cantidadPagoPropuesto,$dniEncargadoTercero,$nombreEncargadoTercero,$observacion,$usuReg,$estado,$codTercero){

		$sql="INSERT INTO db_6E2000.dbo.a010_compromisoPago(id,ruc,rec,rc,fecPagoPropuesto,formaPagoPropuesto,cantidadPagoPropuesto,dniEncargadoTercero,nombreEncargadoTercero,observacion,usuReg,fecReg,estado,codTercero) VALUES('$idCompromiso','$ruc','$rec','$rc','$fecPagoPropuesto','$formaPagoPropuesto','$cantidadPagoPropuesto','$dniEncargadoTercero','$nombreEncargadoTercero','$observacion','$usuReg',getdate(),'$estado','$codTercero');";


		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function updCompromiso($idCompromiso,$rc,$rec,$ruc,$codTercero,$fecPagoPropuesto,$formaPagoPropuesto,$cantidadPagoPropuesto,$dniEncargadoTercero,$nombreEncargadoTercero,$observacion,$estado,$usuMod){


		$sql="UPDATE db_6E2000.dbo.a010_compromisoPago 
		SET 
		rc = '$rc',
		rec = '$rec', 
		ruc = '$ruc',
		codTercero = '$codTercero', 		
		fecPagoPropuesto = '$fecPagoPropuesto', 
		formaPagoPropuesto = '$formaPagoPropuesto', 
		cantidadPagoPropuesto = '$cantidadPagoPropuesto',
		dniEncargadoTercero = '$dniEncargadoTercero',
		nombreEncargadoTercero = '$nombreEncargadoTercero',
		observacion = '$observacion',
		fecMod = getdate(),
		usuMod = '$usuMod'
		WHERE 
		id = '$idCompromiso' ";
		
		

		$this->_db1->query($sql) or die($sql);
		
	}



	public function delCompromiso($idCompromiso){
		//$sql="delete from db_6E2000.dbo.a010_compromisoPago where id = '$idCompromiso'";


		$sql="UPDATE db_6E2000.dbo.a010_compromisoPago 
		SET 
		estado='DE'
		WHERE 
		id = '$idCompromiso' ";
		
		$this->_db1->query($sql) or die($sql);
	}


	public function autActividadPersonal($idActividad){
		
		$sql="UPDATE [DPO2].[dbo].[actividadPersonal] 
		SET 
		estado = '04'

		WHERE 
		id = '$idActividad' ";
		
		

		$this->_db1->query($sql) or die($sql);
	}

	public function getDatosRC($rc){
		
		$sql="select 
		top 1 
		a.num_rc as rc, 
		a.num_ruc as ruc, 
		a.num_exp_rc as rec, 
		a.razon_social as razonSocial
		from db_cobranza.intr.embargos_terceros a
		where a.num_rc='$rc'";
				
		$result = $this->_db1->query($sql) or die($sql);
		return $result;	
	}


	public function getListaTerceros($rc){
		
		$sql="select 
		a.num_ter as codTercero,
		a.num_ruc_ter as rucTercero,
		a.nom_ter as nombreTercero
		from db_cobranza.intr.embargos_terceros a
		where a.num_rc='$rc'
		order by a.nom_ter";
		
		$result = $this->_db1->query($sql) or die($sql);
		return $result;	
	}

	public function getDatosGrafico1($idUsuario,$anho,$mes){
		$sql="select 
		cast(a.fecha as date) as dia,

		(select 
		case
		when sum(b.horasOcupadas) is not null then sum(b.horasOcupadas)
		else 0
		end  
		from dpo2.dbo.actividadPersonal b where b.fecha = a.fecha and b.idUsuario='$idUsuario' and b.estado='04') as horasOcupadas

		
		from
		db_sunat.dbo.a000_fecha a
		

		where
		a.mes = '$mes'
		and
		a.anho = '$anho'
		and
		a.dia_sem in ('2','3','4','5','6') and a.ind_feriado='0' 

		order by cast(a.fecha as date)";
		//echo($sql);

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}

	public function getDatosGrafico2($idArea,$anho,$mes){
		$sql="select 
		cast(a.fecha as date) as dia,

		(select 
		case
		when sum(b.horasOcupadas) is not null then sum(b.horasOcupadas)
		else 0
		end  
		from dpo2.dbo.actividadPersonal b where b.fecha = a.fecha and b.idArea like '$idArea' and b.estado='04') as horasOcupadas

		
		from
		db_sunat.dbo.a000_fecha a
		

		where
		a.mes = '$mes'
		and
		a.anho = '$anho'
		and
		a.dia_sem in ('2','3','4','5','6') and a.ind_feriado='0' 

		order by cast(a.fecha as date)";
		//echo($sql);

		$result = $this->_db1->query($sql) or die($sql);

		return $result;
	}


	public function getOfCombo($id_desc,$id_usuario){
		//Ruc o Razón

		$sql = "


		select 
		c.num_ord_fis as id, 
		c.num_ord_fis + ' - ' + c.ddp_nombre as descripcion

		from 
		dpo.dbo.cof c

		where
		c.num_ord_fis in (select r.num_ord_fis from dpo.dbo.rec_aud r where r.cod_reg_rec ='$id_usuario' and r.flg_est_rec='1')
		
		and
		
		(c.num_ord_fis like'$id_desc%' 
		or 
		c.ddp_nombre like '%$id_desc%' )

		 ";


		$result =$this->_db2->query($sql) or die($sql);
		return $result;
	}

	
}
?>