<?php 
class usuarioModel extends Model{

	public function __construct(){
		parent::__construct();

	}

	public function getUsuarios($id,$idArray,$nombres,$apellido_paterno,$apellido_materno,$correo,$fecha_nacimiento,$id_area,$id_modalidad_contrato,$id_dependencia,$estado,$username,$jefe){

		$sql="select 
		a.id, 
		a.nombres, 
		a.apellido_paterno, 
		a.apellido_materno, 
		lower(a.correo)  as correo, 
		CONVERT(char(10), a.fecha_nacimiento, 126) as fecha_nacimiento,
		a.id_area, 
		a.id_modalidad_contrato, 
		a.estado, 
		a.perfil, 
		a.sexo, 
		a.username, 
		a.id_dependencia,
		a.jefe
		from db_6E2000.dbo.a000_usuario a
		where a.id is not null";

		

		if ($id=='*'){
			if (count($idArray)>0){

				$idSerie='';
				foreach($idArray as $item){
		 			$idSerie.="'".$item."',";
		 		}

				$idSerie = substr($idSerie, 0, strlen($idSerie) - 1 );
				$sql=$sql." and a.id in ($idSerie)";
			}

		}else{
			if($id<>''){
				$sql=$sql." and a.id = '$id'";
			}
		}	

		if ($nombres != '' ){
			$sql=$sql." and a.nombres = '$nombres'";
		}
		if ($apellido_paterno != '' ){
			$sql=$sql." and a.apellido_paterno = '$apellido_paterno'";
		}
		if ($apellido_materno != '' ){
			$sql=$sql." and a.apellido_materno = '$apellido_materno'";
		}
		if ($correo != '' ){
			$sql=$sql." and a.correo = '$correo'";
		}
		if ($fecha_nacimiento != '' ){
			$fecha_nacimiento=date('Y-m-d',strtotime(str_replace('/', '-', $fecha_nacimiento)));

			$sql=$sql." and a.fecha_nacimiento between '".$fecha_nacimiento." 00:00:00' and '".$fecha_nacimiento." 23:59:59'";
		}
		if ($id_area != '' ){
			$sql=$sql." and a.id_area = '$id_area'";
		}
		if ($id_modalidad_contrato != '' ){
			$sql=$sql." and a.id_modalidad_contrato = '$id_modalidad_contrato'";
		}
		if ($id_dependencia != '' ){
			$sql=$sql." and a.id_dependencia = '$id_dependencia'";
		}
		if ($estado != '' ){
			$sql=$sql." and a.estado = '$estado'";
		}
		if ($username != '' ){
			$sql=$sql." and a.username = '$username'";
		}
		if ($jefe != '' ){
			$sql=$sql." and a.jefe = '$jefe'";
		}
	

		$result=$this->_db1->query($sql) or die($sql);
		
		return $result;
				
	}

	public function insUsuario($id,$nombres,$apellido_paterno,$apellido_materno,$correo,$fecha_nacimiento,$id_area,$id_modalidad_contrato,$id_dependencia,$estado,$username,$sexo,$jefe){

		$fecha_nacimiento=date('Y-m-d',strtotime(str_replace('/', '-', $fecha_nacimiento)));

		$sql="insert into db_6E2000.dbo.a000_usuario( 
		id,
		registro,
		nombres,
		apellido_paterno,
		apellido_materno,
		correo,
		fecha_nacimiento,
		id_area,
		id_modalidad_contrato,
		id_dependencia,
		estado,
		username,
		sexo,
		jefe)

		values 
		('$id',
		'$id',
		'$nombres',
		'$apellido_paterno',
		'$apellido_materno',
		'$correo',
		'$fecha_nacimiento',
		'$id_area',
		'$id_modalidad_contrato',
		'$id_dependencia',
		'$estado',
		'$username',
		'$sexo',
		'$jefe')";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function updUsuario($id,$nombres,$apellido_paterno,$apellido_materno,$correo,$fecha_nacimiento,$id_area,$id_modalidad_contrato,$id_dependencia,$estado,$username,$sexo,$jefe){

		$fecha_nacimiento=date('Y-m-d',strtotime(str_replace('/', '-', $fecha_nacimiento)));

		$sql="UPDATE db_6E2000.dbo.a000_usuario 
		SET 
		nombres = '$nombres',
		apellido_paterno = '$apellido_paterno',
		apellido_materno = '$apellido_materno',
		correo = '$correo',
		fecha_nacimiento = '$fecha_nacimiento',
		id_area = '$id_area',
		id_modalidad_contrato = '$id_modalidad_contrato',
		id_dependencia = '$id_dependencia',
		estado = '$estado',
		username = '$username',
		sexo = '$sexo',
		jefe = '$jefe'
		WHERE 
		id = '$id'";
		
		$this->_db1->query($sql) or die($sql);
	}

	public function delUsuario($id){
		
		$sql="UPDATE db_6E2000.dbo.a000_usuario 
		SET 
		estado='00'
		WHERE 
		id = '$id' ";
		
		$this->_db1->query($sql) or die($sql);
	}




	
}
?>