<?php 

require_once('.\libs\TCPDF-master\tcpdf.php');

class tomaDichoController extends Controller{
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
	}

	
	public function consulta(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('TOMADICHO/CONSULTA',true)){

			    $idTomaDicho = '';
			    $idTomaDichoArray = array();
				$rc = '';
			    $rucContribuyente = '';
			    $codTercero = '';
			    $rucTercero = '';
			    $fecTomaDichoIni = '';
			    $fecTomaDichoFin = '';
			    $resultado = '';
			    $regResponsableDiligencia = '';
			    $codAuxRc = '';
			    $codEjeRc = '';
			    $fecRegIni = '';
				$fecRegFin = '';
			    $estado = '';
			    $estadoArray = array();
			    $title = 'Consulta General de Toma de Dichos';
			    $shape = '1';

			   	if(isset($_POST['idTomaDicho'])){
					$idTomaDicho = trim($_POST['idTomaDicho']);
				}
				if(isset($_POST['idTomaDichoArray'])){
					$idTomaDichoArray = $_POST['idTomaDichoArray'];
				}
				if(isset($_POST['rc'])){
					$rc = trim($_POST['rc']);
				}
				if(isset($_POST['rucContribuyente'])){
					$rucContribuyente = trim($_POST['rucContribuyente']);
				}
				if(isset($_POST['codTercero'])){
					$codTercero = trim($_POST['codTercero']);
				}
				if(isset($_POST['rucTercero'])){
					$rucTercero = trim($_POST['rucTercero']);
				}
				if(isset($_POST['fecTomaDichoIni'])){
					$fecTomaDichoIni = trim($_POST['fecTomaDichoIni']);
				}
				if(isset($_POST['fecTomaDichoFin'])){
					$fecTomaDichoFin = trim($_POST['fecTomaDichoFin']);
				}
				if(isset($_POST['resultado'])){
					$resultado = trim($_POST['resultado']);
				}
				if(isset($_POST['regResponsableDiligencia'])){
					$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
				}
				if(isset($_POST['codAuxRc'])){
					$codAuxRc = trim($_POST['codAuxRc']);
				}
				if(isset($_POST['codEjeRc'])){
					$codEjeRc = trim($_POST['codEjeRc']);
				}
				if(isset($_POST['fecRegIni'])){
					$fecRegIni = trim($_POST['fecRegIni']);
				}
				if(isset($_POST['fecRegFin'])){
					$fecRegFin = trim($_POST['fecRegFin']);
				}
				if(isset($_POST['estado'])){
					$estado = trim($_POST['estado']);
				}
				if(isset($_POST['estadoArray'])){
					$estadoArray = $_POST['estadoArray'];
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}


				$this->_view->idTomaDicho = $idTomaDicho;
				$this->_view->rc = $rc;
				$this->_view->rucContribuyente = $rucContribuyente;
				$this->_view->codTercero = $codTercero;
				$this->_view->rucTercero = $rucTercero;
				$this->_view->fecTomaDichoIni = $fecTomaDichoIni;
				$this->_view->fecTomaDichoFin = $fecTomaDichoFin;
				$this->_view->resultado = $resultado;
				$this->_view->regResponsableDiligencia = $regResponsableDiligencia;
				$this->_view->codAuxRc = $codAuxRc;
				$this->_view->codEjeRc = $codEjeRc;
				$this->_view->fecRegIni = $fecRegIni;
				$this->_view->fecRegFin = $fecRegFin;
				$this->_view->estado = $estado;
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('consultaV20220729')); 
				$this->_view->renderizar('consulta');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function registro(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('TOMADICHO/REGISTRO',true)){
					
				$_POST['shape']='2';
				$_POST['title']='Registro de Toma de Dichos';

				$this->consulta();

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);//true para que aprezca sin encabezado
		}
	}

	public function misAsignados(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('TOMADICHO/MISASIGNADOS',true)){
					
				$_POST['estado']='01';
				$_POST['regResponsableDiligencia']=$_SESSION['id'];
				$_POST['shape']='3';
				$_POST['title']='Mis Asignados Pendientes';

				$this->consulta();

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);//true para que aprezca sin encabezado
		}
	}

	public function diligencia(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('TOMADICHO/DILIGENCIA',true)){

			    $idDiligencia = '';
			    $idTomaDicho = '';
			    $fecDiligenciaIni = '';
				$fecDiligenciaFin = '';
				$resultado = '';
				$mtoInformado = '';
				$nombreEncargadoTer = '';
				$telefonoEncargadoTer = '';
				$correoEncargadoTer = '';
				$regResponsableDiligencia = '';
				$estado = '';
				$shape = '1';
			    $title = 'Consulta General de Diligencias';

			    if(isset($_POST['idDiligencia'])){
					$idDiligencia = trim($_POST['idDiligencia']);
				}
				if(isset($_POST['idTomaDicho'])){
					$idTomaDicho = trim($_POST['idTomaDicho']);
				}
				if(isset($_POST['fecDiligenciaIni'])){
					$fecDiligenciaIni = trim($_POST['fecDiligenciaIni']);
				}
				if(isset($_POST['fecDiligenciaFin'])){
					$fecDiligenciaFin = trim($_POST['fecDiligenciaFin']);
				}
				if(isset($_POST['resultado'])){
					$resultado = trim($_POST['resultado']);
				}
				if(isset($_POST['mtoInformado'])){
					$mtoInformado = trim($_POST['mtoInformado']);
				}
				if(isset($_POST['nombreEncargadoTer'])){
					$nombreEncargadoTer = trim($_POST['nombreEncargadoTer']);
				}
				if(isset($_POST['telefonoEncargadoTer'])){
					$telefonoEncargadoTer = trim($_POST['telefonoEncargadoTer']);
				}
				if(isset($_POST['correoEncargadoTer'])){
					$correoEncargadoTer = trim($_POST['correoEncargadoTer']);
				}
				if(isset($_POST['regResponsableDiligencia'])){
					$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
				}
				if(isset($_POST['estado'])){
					$estado = trim($_POST['estado']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}	


				$this->_view->idDiligencia = $idDiligencia;
				$this->_view->idTomaDicho = $idTomaDicho;
				$this->_view->fecDiligenciaIni = $fecDiligenciaIni;
				$this->_view->fecDiligenciaFin = $fecDiligenciaFin;
				$this->_view->resultado = $resultado;
				$this->_view->mtoInformado = $mtoInformado;
				$this->_view->nombreEncargadoTer = $nombreEncargadoTer;
				$this->_view->telefonoEncargadoTer = $telefonoEncargadoTer;
				$this->_view->correoEncargadoTer = $correoEncargadoTer;
				$this->_view->regResponsableDiligencia = $regResponsableDiligencia;
				$this->_view->estado = $estado;
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('diligenciaV20220729')); 
				$this->_view->renderizar('diligencia');
				
			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function estadistica1(){

		if(isset($_SESSION['id'])){
			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;
			
			$this->_view->setJs(array('estadistica1')); //carga un js en la vista
			$this->_view->renderizar('estadistica1');

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);//true para que aprezca sin encabezado
		}
	}

	public function generarId(){

		$idTomaDicho = '';

		$objModel = $this->loadModel('tomaDicho');
		$result = $objModel->generarId();

		$result->nextRowset();
		
		if ($result->rowCount()){
				foreach ($result as $row) {	
					$idTomaDicho=$row['idTomaDicho'];
				}
		}
		return $idTomaDicho;
	}

	public function generarIdDiligencia(){

		$idDiligencia = '';

		$objModel = $this->loadModel('tomaDicho');
		$result = $objModel->generarIdDiligencia();

		$result->nextRowset();
		
		if ($result->rowCount()){
				foreach ($result as $row) {	
					$idDiligencia=$row['idDiligencia'];
				}
		}
		return $idDiligencia;
	}

	public function getTomaDichos(){

		if(isset($_SESSION['id'])){
					
			$idTomaDicho = '';
			$idTomaDichoArray = array();
			$rc = '';
		    $rucContribuyente = '';
		    $codTercero = '';
		    $rucTercero = '';
		    $fecTomaDichoIni = '';
		    $fecTomaDichoFin = '';
		    $resultado = '';
		    $regResponsableDiligencia = '';
		    $codAuxRc = '';
		    $codEjeRc = '';
		    $fecRegIni = '';
			$fecRegFin = '';
		    $estado = '';
		    $estadoArray = array();

		   	if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = trim($_POST['idTomaDicho']);
			}
			if(isset($_POST['idTomaDichoArray'])){
				$idTomaDichoArray = $_POST['idTomaDichoArray'];
			}
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			if(isset($_POST['rucContribuyente'])){
				$rucContribuyente = trim($_POST['rucContribuyente']);
			}
			if(isset($_POST['codTercero'])){
				$codTercero = trim($_POST['codTercero']);
			}
			if(isset($_POST['rucTercero'])){
				$rucTercero = trim($_POST['rucTercero']);
			}
			if(isset($_POST['fecTomaDichoIni'])){
				$fecTomaDichoIni = trim($_POST['fecTomaDichoIni']);
			}
			if(isset($_POST['fecTomaDichoFin'])){
				$fecTomaDichoFin = trim($_POST['fecTomaDichoFin']);
			}
			if(isset($_POST['resultado'])){
				$resultado = trim($_POST['resultado']);
			}
			if(isset($_POST['regResponsableDiligencia'])){
				$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
			}
			if(isset($_POST['codEjeRc'])){
				$codEjeRc = trim($_POST['codEjeRc']);
			}
			if(isset($_POST['fecRegIni'])){
				$fecRegIni = trim($_POST['fecRegIni']);
			}
			if(isset($_POST['fecRegFin'])){
				$fecRegFin = trim($_POST['fecRegFin']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}
			if(isset($_POST['estadoArray'])){
				$estadoArray = $_POST['estadoArray'];
			}
			
			if($estado==''){
				$estado = '*';
				array_push($estadoArray, '01');
				array_push($estadoArray, '02');
			}

			$objModel = $this->loadModel('tomaDicho');
			$result = $objModel->getTomaDichos($idTomaDicho,$idTomaDichoArray,$rc,$rucContribuyente,$codTercero,$rucTercero,$fecTomaDichoIni,$fecTomaDichoFin,$resultado,$regResponsableDiligencia,$codAuxRc,$codEjeRc,$fecRegIni,$fecRegFin,$estado,$estadoArray);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}

	public function getDiligencias(){

		if(isset($_SESSION['id'])){
			
			$idDiligencia = '';
			$idTomaDicho = '';
			$fecDiligenciaIni = '';
			$fecDiligenciaFin = '';
			$resultado = '';
			$regResponsableDiligencia = '';
			$fecRegIni = '';
			$fecRegFin = '';
			$estado = '';
			$estadoArray = array();

		    if(isset($_POST['idDiligencia'])){
				$idDiligencia = trim($_POST['idDiligencia']);
			}
			if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = trim($_POST['idTomaDicho']);
			}
			if(isset($_POST['fecDiligenciaIni'])){
				$fecDiligenciaIni = trim($_POST['fecDiligenciaIni']);
			}
			if(isset($_POST['fecDiligenciaFin'])){
				$fecDiligenciaFin = trim($_POST['fecDiligenciaFin']);
			}
			if(isset($_POST['resultado'])){
				$resultado = trim($_POST['resultado']);
			}
			if(isset($_POST['regResponsableDiligencia'])){
				$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
			}
			if(isset($_POST['fecRegIni'])){
				$fecRegIni = trim($_POST['fecRegIni']);
			}
			if(isset($_POST['fecRegFin'])){
				$fecRegFin = trim($_POST['fecRegFin']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}
			if(isset($_POST['estadoArray'])){
				$estadoArray = trim($_POST['estadoArray']);
			}

			if($estado==''){
				$estado = '*';
				array_push($estadoArray, '01');
			}
			
			$objModel = $this->loadModel('tomaDicho');
			$result = $objModel->getDiligencias($idDiligencia,$idTomaDicho,$fecDiligenciaIni,$fecDiligenciaFin,$resultado,$regResponsableDiligencia,$fecRegIni,$fecRegFin,$estado,$estadoArray);

			

			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);
		}	
	}

	public function insTomaDicho(){

		if(isset($_SESSION['id'])){
			
			$idTomaDicho=$this->generarId();			
			$rc = '';
			$rucContribuyente = '';
			$codTercero = '';		
			$regResponsableDiligencia = '';	
			$usuReg = $_SESSION['id'];
			$estado = '01';
			

			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			if(isset($_POST['rucContribuyente'])){
				$rucContribuyente = trim($_POST['rucContribuyente']);
			}
			if(isset($_POST['codTercero'])){
				$codTercero = trim($_POST['codTercero']);
			}	
			if(isset($_POST['regResponsableDiligencia'])){
				$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
			}


			$objModel = $this->loadModel('tomaDicho');
			$objModel->insTomaDicho($idTomaDicho,$rc,$codTercero,$regResponsableDiligencia,$usuReg,$estado);


			
			$_POST = array();
			$_POST['idTomaDicho']=$idTomaDicho;
			$this->getTomaDichos();

		}
	}

	public function insMasTomaDicho(){

		if(isset($_SESSION['id'])){

			$datosArray = array();
			$idTomaDichoArray = array();

			if(isset($_POST['datosArray'])){
				$datosArray = $_POST['datosArray'];
			}	

			if (count($datosArray)>0){
				foreach($datosArray as $item)
		 		{
		 			$idTomaDicho=$this->generarId();
		 			$rc = $item[0];
		 			$codTercero = $item[1];	
		 			$regResponsableDiligencia = $item[2];	
		 			$usuReg = $_SESSION['id'];
					$estado = '01';

					$objModel = $this->loadModel('tomaDicho');
					$objModel->insTomaDicho($idTomaDicho,$rc,$codTercero,$regResponsableDiligencia,$usuReg,$estado);

					array_push($idTomaDichoArray, $idTomaDicho);
					
		 		}
			}
			

			$_POST = array();
			$_POST['idTomaDicho']='*';
			$_POST['idTomaDichoArray']=$idTomaDichoArray;
			$this->getTomaDichos();

		}
	}

	public function insDiligencia(){

		if(isset($_SESSION['id'])){
			
			$idDiligencia=$this->generarIdDiligencia();			
			$idTomaDicho = '';
			$fecDiligencia = '';
			$resultado = '';
			$subResultado = '';
			$observacion = '';
			$mtoInformado = '';
			$nombreEncargadoTer = '';
			$telefonoEncargadoTer = '';
			$correoEncargadoTer = '';
			$regResponsableDiligencia = '';
			$usuReg = $_SESSION['id'];
			$estado = '01';
			

			if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = trim($_POST['idTomaDicho']);
			}
			if(isset($_POST['fecDiligencia'])){
				$fecDiligencia = trim($_POST['fecDiligencia']);
			}
			if(isset($_POST['resultado'])){
				$resultado = trim($_POST['resultado']);
			}	
			if(isset($_POST['subResultado'])){
				$subResultado = trim($_POST['subResultado']);
			}	
			if(isset($_POST['observacion'])){
				$observacion = trim($_POST['observacion']);
			}	
			if(isset($_POST['mtoInformado'])){
				$mtoInformado = trim($_POST['mtoInformado']);
			}	
			if(isset($_POST['nombreEncargadoTer'])){
				$nombreEncargadoTer = trim($_POST['nombreEncargadoTer']);
			}	
			if(isset($_POST['telefonoEncargadoTer'])){
				$telefonoEncargadoTer = trim($_POST['telefonoEncargadoTer']);
			}	
			if(isset($_POST['correoEncargadoTer'])){
				$correoEncargadoTer = trim($_POST['correoEncargadoTer']);
			}
			if(isset($_POST['regResponsableDiligencia'])){
				$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
			}	
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}

			if ($resultado<>'4'){
				$mtoInformado='0';
			}

			$objModel = $this->loadModel('tomaDicho');
			$objModel->insDiligencia($idDiligencia,$idTomaDicho,$fecDiligencia,$resultado,$subResultado,$observacion,$mtoInformado,$nombreEncargadoTer,$telefonoEncargadoTer,$correoEncargadoTer,$regResponsableDiligencia,$usuReg,$estado);

			$objModel->conTomaDicho($idTomaDicho,$usuReg);

			$_POST = array();
			$_POST['idDiligencia']=$idDiligencia;
			$this->getDiligencias();			

		}		
	}

	public function updTomaDicho(){

		if(isset($_SESSION['id'])){

			$idTomaDicho = '';
			$rc = '';
			$codTercero = '';
			$regResponsableDiligencia = '';
			$usuMod = $_SESSION['id'];
			$estado = '';

		
			if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = trim($_POST['idTomaDicho']);
			}
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			if(isset($_POST['codTercero'])){
				$codTercero = trim($_POST['codTercero']);
			}
			if(isset($_POST['regResponsableDiligencia'])){
				$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
			}
			if(isset($_POST['usuMod'])){
			 	$usuMod = trim($_POST['usuMod']);
			}
			if(isset($_POST['estado'])){
			 	$estado = trim($_POST['estado']);
			}
			

			$objModel = $this->loadModel('tomaDicho');
			$objModel->updTomaDicho($idTomaDicho,$rc,$codTercero,$regResponsableDiligencia,$usuMod,$estado);

			
			$_POST = array();
			$_POST['idTomaDicho']=$idTomaDicho;
			$this->getTomaDichos();
			

		}
	}

	public function updDiligencia(){

		if(isset($_SESSION['id'])){

			$idDiligencia = '';		
			$idTomaDicho = '';
			$fecDiligencia = '';
			$resultado = '';
			$subResultado = '';
			$observacion = '';
			$mtoInformado = '';
			$nombreEncargadoTer = '';
			$telefonoEncargadoTer = '';
			$correoEncargadoTer = '';
			$regResponsableDiligencia = '';
			$usuMod = $_SESSION['id'];
			$estado = '01';

		
			if(isset($_POST['idDiligencia'])){
				$idDiligencia = trim($_POST['idDiligencia']);
			}
			if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = trim($_POST['idTomaDicho']);
			}
			if(isset($_POST['fecDiligencia'])){
				$fecDiligencia = trim($_POST['fecDiligencia']);
			}
			if(isset($_POST['resultado'])){
				$resultado = trim($_POST['resultado']);
			}	
			if(isset($_POST['subResultado'])){
				$subResultado = trim($_POST['subResultado']);
			}	
			if(isset($_POST['observacion'])){
				$observacion = trim($_POST['observacion']);
			}	
			if(isset($_POST['mtoInformado'])){
				$mtoInformado = trim($_POST['mtoInformado']);
			}	
			if(isset($_POST['nombreEncargadoTer'])){
				$nombreEncargadoTer = trim($_POST['nombreEncargadoTer']);
			}	
			if(isset($_POST['telefonoEncargadoTer'])){
				$telefonoEncargadoTer = trim($_POST['telefonoEncargadoTer']);
			}	
			if(isset($_POST['correoEncargadoTer'])){
				$correoEncargadoTer = trim($_POST['correoEncargadoTer']);
			}
			if(isset($_POST['regResponsableDiligencia'])){
				$regResponsableDiligencia = trim($_POST['regResponsableDiligencia']);
			}	

			$objModel = $this->loadModel('tomaDicho');
			$objModel->updDiligencia($idDiligencia,$idTomaDicho,$fecDiligencia,$resultado,$subResultado,$observacion,$mtoInformado,$nombreEncargadoTer,$telefonoEncargadoTer,$correoEncargadoTer,$regResponsableDiligencia,$usuMod,$estado);

			$objModel->conTomaDicho($idTomaDicho,$usuMod);

			$_POST = array();
			$_POST['idDiligencia']=$idDiligencia;
			$this->getDiligencias();

		}
	}

	public function delTomaDicho(){

		if(isset($_SESSION['id'])){

			$idTomaDicho = '';
		
			if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = $_POST['idTomaDicho'];
			}

			$objModel = $this->loadModel('tomaDicho');
			$objModel->delTomaDicho($idTomaDicho);


			$_POST = array();
			$_POST['idTomaDicho']=$idTomaDicho;
			$_POST['estado']='DE';
			$this->getTomaDichos();


		}
	}

	public function delDiligencia(){

		if(isset($_SESSION['id'])){

			$idDiligencia = '';
			$idTomaDicho = '';
			
			if(isset($_POST['idDiligencia'])){
				$idDiligencia = $_POST['idDiligencia'];
			}
			if(isset($_POST['idTomaDicho'])){
				$idTomaDicho = $_POST['idTomaDicho'];
			}

			$objModel = $this->loadModel('tomaDicho');
			$objModel->delDiligencia($idDiligencia);

			$objModel->conTomaDicho($idTomaDicho,$_SESSION['id']);
			
			$_POST = array();
			$_POST['idDiligencia']=$idDiligencia;
			$_POST['estado']='DE';
			$this->getDiligencias();
		}
	}

	public function getDatosRC(){

		if(isset($_SESSION['id'])){

			$rc = '';
	    
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			
			$objModel = $this->loadModel('tomaDicho');
			$result = $objModel->getDatosRC($rc);


			$arreglo['data'] = array();
			

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);

		}
	}

	// public function getExisteRC(){

	// 	if(isset($_SESSION['id'])){

	// 		$rc = '';
	    
	// 		if(isset($_POST['rc'])){
	// 			$rc = trim($_POST['rc']);
	// 		}
			
	// 		$objModel = $this->loadModel('tomaDicho');
	// 		$result = $objModel->getTomaDichos('','',$rc,'','','','','','','','','','','','',array());

	// 		$arreglo['data'] = array();
			

	// 		while ($row = $result->fetch())  {
	// 		    $arreglo['data'][] = $row;
	// 		}

	// 		echo json_encode($arreglo);

	// 	}
	// }

	public function getListaTerceros(){

		if(isset($_SESSION['id'])){

			$rc = '';
	    
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			
			$objModel = $this->loadModel('tomaDicho');
			$result = $objModel->getListaTerceros($rc);


			$arreglo["data"] = array();
			
			
			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		
		}
	}
	
	public function genPdfInd() {
	
		if(isset($_SESSION['id'])){

			$idTomaDicho='';
			if(isset($_GET['idTomaDicho'])){
				$idTomaDicho = trim($_GET['idTomaDicho']);
			}
			

			
			$objModel= $this->loadModel('tomaDicho');			
			$result = $objModel->getTomaDichos($idTomaDicho,array(),'','','','','','','','','','','','','',array());

			
			while ($row = $result->fetch())  {

				$rc = trim($row['rc']);
				$rec = trim($row['rec']);
				$rucTerceroDesc = trim($row['rucTerceroDesc']);
				$direccionTercero = trim($row['direccionTercero']);				
				$rucDesc = trim($row['rucDesc']);
				$direccionContribuyente = trim($row['direccionContribuyente']);
				$codAuxRcDesc = trim($row['codAuxRcDesc']);
				$regResponsableDiligenciaDesc = trim($row['regResponsableDiligenciaDesc']);

			}

			$fechaImpresion = date('d-m-Y');  
			//echo "The current date and time are $DateAndTime.";

			//$direccion = mb_strtolower($direccion, 'UTF-8');

			//$direccion = ucwords($direccion);
			

			

			//Obteniendo ruta servidor
			/*$result = $objCarta->getRutaRepositorio();
			$ruta_repositorio="";

			while ($row = $result->fetch()){
			     $ruta_repositorio=$row[0]; 
			}*/

			
			$pdf = new MYPDF('P', PDF_UNIT, 'A4', true, 'UTF-8', false, true);
							
			//$ruta_visto = $ruta_visto."V.jpg";
			//$ruta_visto = str_replace('\\\\', '\\', $ruta_visto);
			//$ruta_visto = '\\PO-7\POD\FIRMAS\19181530V.jpg';

			//$pdf->setRutaVisto1($ruta_visto);
			//$pdf->setEstado($estado);
			//$pdf->setNombreAnual($nombre_anual);
			//$pdf->setNombreDecenio($nombre_decenio);
		
			// set document information
			$pdf->SetCreator(PDF_CREATOR);
			$pdf->SetAuthor('Cobraly');
			$pdf->SetTitle('Acta de Toma de Dicho');
			$pdf->SetSubject('Acta de Toma de Dicho');
			$pdf->SetKeywords('Cobraly');
	
			// remove default header/footer 
			$pdf->setPrintHeader(true); 
			//$pdf->setPrintFooter(true);

			// set auto page breaks
			$pdf->SetAutoPageBreak(TRUE, 10);
		
			// ---------------------------------------------------------

			// set default font subsetting mode
			$pdf->setFontSubsetting(true);

			// Set font
			$pdf->SetFont('helvetica', '', 10, '', true);

			//SetMargins($left,$top,$right = -1,$keepmargins = false)
			$pdf->SetMargins(0, 35, 0, true);
			
			// Add a page
			$pdf->AddPage('P', 'A4');

			// Set some content to print
			$html = <<<EOD
<span style="text-align:center;">
<b><u>ACTA DE TOMA DE DICHO</u></b><br><br>
MEDIDA DE EMBARGO EN FORMA DE RETENCIÓN:<br>
<b>RESOLUCIÓN COACTIVA N° $rc</b><br>
</span>

<br>

<table width="100%" border="1" cellpadding="2" cellspacing="0" bordercolor="#9B9B9B">
	<tr>
		<td>
			
			<table width="100%" border="0" cellpadding="0" cellspacing="0">
				<tr>
					<td align="left" width="30%"><b>TERCERO RETENEDOR:</b></td>
					<td align="left" width="70%"><b>$rucTerceroDesc</b></td>
				</tr>
				<tr>
					<td align="left" width="30%"><b>DOMICILIO:</b></td>
					<td align="left" width="70%"><b>$direccionTercero</b></td>
				</tr>

			</table>

		</td>
	</tr>
</table>

<br>
<br>


<table width="100%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td align="left" width="30%"><b>DEUDOR TRIBUTARIO:</b></td>
		<td align="left" width="70%"><b>$rucDesc</b></td>
	</tr>
	<tr>
		<td align="left" width="30%"><b>DOMICILIO FISCAL:</b></td>
		<td align="left" width="70%"><b>$direccionContribuyente</b></td>
	</tr>
	<tr>
		<td align="left" width="30%"><b>EXPEDIENTE NÚMERO:</b></td>
		<td align="left" width="70%"><b>$rec</b></td>
	</tr>
	<tr>
		<td align="left" width="30%"><b>AUXILIAR COACTIVO:</b></td>
		<td align="left" width="70%"><b>$codAuxRcDesc</b></td>
	</tr>

</table>

<br>
<br>

Lima, ____________________________<br><br>		

<span style="text-align:justify;">A las _____________ horas del día de hoy, y en cumplimiento de lo ordenado mediante Resolución Coactiva N° $rc, en el procedimiento de medida de embargo en forma de Retención seguido por la SUNAT con el deudor tributario y dando cumplimiento a la resolución coactiva mencionada, me constituí en la empresa Retenedora señalada, con el objeto de realizar la toma de dicho, entendiéndome con __________________________________________________________, identificado con DNI N° _________________________, en representación de la entidad retenedora, del cual obtuve el siguiente resultado:
<br>
<br>

<table width="40%" border="0" cellpadding="0" cellspacing="0">
	<tr>
		<td align="left" width="60%"><b>Con monto a retener:</b></td>
		<td align="left" width="20%"><b>SI</b></td>
		<td align="left" width="20%"><b>NO</b></td>
	</tr>
	
</table>

<br>
<br>

El tercero manifiesta_____________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________________
<br>
<br>
Importe a Retener:______________ con lo que concluyó la diligencia a las__________horas del día de hoy, de lo cual doy fe.

<br>
<br>
<br>

</span>

<center>
	<table width="100%" border="0" cellpadding="2" cellspacing="0">
		
		<tr>
			
			<td align="center" >
				_____________________________
			</td>
			
			<td align="center">
				____________________________________
			</td>
		</tr>
		<tr>
			
			<td align="center" >
				<br>
				$regResponsableDiligenciaDesc<br>
				Representante SUNAT
			</td>

			

			<td align="center">
				
				Nombre:____________________________<br>
				DNI:_______________________________<br>
				Telefono:___________________________<br>
				Correo Electronico:___________________<br>
				
			</td>
		</tr>
	</table>
</center>

<br>
<font size="8">
Se deja constancia que de acuerdo a lo señalado en el numeral 23 del artículo 177 del Código Tributario aprobado mediante DECRETO SUPREMO  133-2013-EF:<br>
•	Constituyen infracciones relacionadas con la obligación de permitir el control de la Administración, informar y comparecer ante la misma: Numeral 23: No proporcionar la información solicitada con ocasión de la ejecución del embargo en forma de Retención a que se refiere el numeral 4 del artículo 118° del presente Código Tributario.<br>
Asimismo, se precisa que de acuerdo a lo señalado en el numeral 6 del artículo 178 del Código Tributario aprobado mediante DECRETO SUPREMO  133-2013-EF:<br>
•	Constituyen infracciones relacionadas con el cumplimiento de las obligaciones tributarias:
Numeral 6: No entregar a la Administración Tributaria el monto retenido por embargo en forma de retención.
 
<font>

EOD;

		// Print text using writeHTMLCell()
		$pdf->writeHTMLCell(165, 0, 25, 30, $html, 0, 1, 0, true, '', true);

		
	
		//Primiliminar
		$pdf->Output($idTomaDicho.'.pdf', 'I');

		//Emitir
		// $ruta_final = $ruta_repositorio.$id_carta.'.pdf';
		// $ruta_final=addslashes($ruta_final);
		// $pdf->Output($ruta_final, 'F');
				
					
				

		}


	}
}


class MYPDF extends TCPDF {

	private $rutaVisto1;
	private $estado;
	private $nombreAnual;
	private $nombreDecenio;

	protected $last_page_flag = false;

	public function setRutaVisto1($RutaVisto1) {
		$this->rutaVisto1=$RutaVisto1;
	}

	public function setEstado($Estado) {
		$this->estado=$Estado;
	}

	public function setNombreAnual($NombreAnual) {
		$this->nombreAnual=$NombreAnual;
	}

	public function setNombreDecenio($NombreDecenio) {
		$this->nombreDecenio=$NombreDecenio;
	}

	public function Header() {

		//Cabecera
		$html = '
		<table cellspacing="20" cellpadding="0" border="0">
			<tr>
				<td>

					<table cellspacing="0" cellpadding="0" border="0">
						<tr>
							<td><font size="12" face="arial">I.LIMA<br>COBRANZA COACTIVA<br></font></td>
							<td></td>
							<td><img src=".\reportes\carta\Logout5.jpg"></td>
						</tr>
					</table>
				</td>
			</tr>
		</table>';

     	$this->writeHTMLCell($w = 0, $h = 0, $x = '', $y = '', $html, $border = 0, $ln = 1, $fill = 0, $reseth = true, $align = 'top', $autopadding = true);
    	    	    	
	}

	public function Close() {
	    $this->last_page_flag = true;
	    parent::Close();
	}

	public function Footer(){
	    /*if($this->last_page_flag){
	        $footer_html = ''; //HTML for the footer on the last page


	    }
	    else{
	    	if($this->estado == "04" || $this->estado == "05" ){

	    		$footer_html = '
		    	<table cellspacing="0" cellpadding="0" border="0">
					<tr>
						<td align="center">				
							<img src="'.$this->rutaVisto1.'" width="400" height="400">				
						</td>
					</tr>
				</table>'; //HTML for the rest of the pages
	    	}else{
	    		$footer_html = '';
	    	}
	        
	    }

	    

	   	$this->writeHTMLCell($w = 24, $h = 24, $x = 2, $y = 175, $footer_html, $border = 0, $ln = 1, $fill = 0, $reseth = true, $align = 'top', $autopadding = true);
	   	*/

	    $html = '
    	<table cellspacing="0" cellpadding="0" border="0">
    		
			<tr>
				<td align="center">
					<!--<img src=".\reportes\carta\pie.jpg" width="900" height="60">-->		
				</td>
			</tr>
		</table>';

    	$this->writeHTMLCell($w = 190, $h = 13, $x = 10, $y = 275, $html, $border = 0, $ln = 1, $fill = 0, $reseth = true, $align = 'top', $autopadding = true);

    	$this->setPageMark();
	}
}

?>