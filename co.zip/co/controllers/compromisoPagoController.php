<?php 

require_once('.\libs\TCPDF-master\tcpdf.php');

class compromisoPagoController extends Controller{
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
	}

	public function consulta(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('COMPROMISOPAGO/CONSULTA',true)){

			    $idCompromiso = '';
			    $rc = '';
			    $rec = '';
			    $ruc = '';
			    $rucTercero = '';
			    $dniEncargadoTercero = '';
			    $fecRegIni = '';
			    $fecRegFin = '';
			    $shape = '1';
			    $title = 'Consulta General de Compromisos';

			    if(isset($_POST['idCompromiso'])){
					$idCompromiso = trim($_POST['idCompromiso']);
				}
				if(isset($_POST['rc'])){
					$rc = trim($_POST['rc']);
				}
				if(isset($_POST['rec'])){
					$rec = trim($_POST['rec']);
				}
				if(isset($_POST['ruc'])){
					$ruc = trim($_POST['ruc']);
				}
				if(isset($_POST['rucTercero'])){
					$rucTercero = trim($_POST['rucTercero']);
				}
				if(isset($_POST['dniEncargadoTercero'])){
					$dniEncargadoTercero = trim($_POST['dniEncargadoTercero']);
				}
				if(isset($_POST['fecRegIni'])){
					$fecRegIni = trim($_POST['fecRegIni']);
				}
				if(isset($_POST['fecRegFin'])){
					$fecRegFin = trim($_POST['fecRegFin']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}			


				$this->_view->idCompromiso = $idCompromiso;
				$this->_view->rc = $rc;
				$this->_view->rec = $rec;
				$this->_view->ruc = $ruc;
				$this->_view->rucTercero = $rucTercero;
				$this->_view->dniEncargadoTercero = $dniEncargadoTercero;
				$this->_view->fecRegIni = $fecRegIni;
				$this->_view->fecRegFin = $fecRegFin;
				$this->_view->shape = $shape;
				$this->_view->title = $title;
				
				$this->_view->setJs(array('consulta')); 
				$this->_view->renderizar('consulta');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function cuota(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('COMPROMISOPAGO/CUOTA',true)){

			    $idCompromiso = '';
			    $rucTercero = '';
			    $fechaVencimientoCuotaIni = '';
				$fechaVencimientoCuotaFin = '';
				$mtoCuotaIni = '';
				$mtoCuotaFin = '';
				$saldoMtoEmbIni = '';
				$saldoMtoEmbFin = '';
				$shape = '1';
			    $title = 'Consulta General de Cuotas de Compromiso';

			    if(isset($_POST['idCompromiso'])){
					$idCompromiso = trim($_POST['idCompromiso']);
				}
				if(isset($_POST['rucTercero'])){
					$rucTercero = trim($_POST['rucTercero']);
				}
				if(isset($_POST['fechaVencimientoCuotaIni'])){
					$fechaVencimientoCuotaIni = trim($_POST['fechaVencimientoCuotaIni']);
				}
				if(isset($_POST['fechaVencimientoCuotaFin'])){
					$fechaVencimientoCuotaFin = trim($_POST['fechaVencimientoCuotaFin']);
				}
				if(isset($_POST['mtoCuotaIni'])){
					$mtoCuotaIni = trim($_POST['mtoCuotaIni']);
				}
				if(isset($_POST['mtoCuotaFin'])){
					$mtoCuotaFin = trim($_POST['mtoCuotaFin']);
				}
				if(isset($_POST['saldoMtoEmbIni'])){
					$saldoMtoEmbIni = trim($_POST['saldoMtoEmbIni']);
				}
				if(isset($_POST['saldoMtoEmbFin'])){
					$saldoMtoEmbFin = trim($_POST['saldoMtoEmbFin']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}	


				$this->_view->idCompromiso = $idCompromiso;
				$this->_view->rucTercero = $rucTercero;
				$this->_view->fechaVencimientoCuotaIni = $fechaVencimientoCuotaIni;
				$this->_view->fechaVencimientoCuotaFin = $fechaVencimientoCuotaFin;
				$this->_view->mtoCuotaIni = $mtoCuotaIni;
				$this->_view->mtoCuotaFin = $mtoCuotaFin;
				$this->_view->saldoMtoEmbIni = $saldoMtoEmbIni;
				$this->_view->saldoMtoEmbFin = $saldoMtoEmbFin;
				$this->_view->shape = $shape;
				$this->_view->title = $title;


				$this->_view->setJs(array('cuota'));
				$this->_view->renderizar('cuota');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function estadistica1(){

		if(isset($_SESSION['id'])){

			if ($objLayout->validarAccesoOpcion('COMPROMISOPAGO/ESTADISTICA1',true)){

				$objLayout = $this->loadModel('layout');
				$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
				$this->_view->layout = $objLayout;
				
				$this->_view->setJs(array('estadistica1'));
				$this->_view->renderizar('estadistica1');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function generarId(){

		$idCompromiso = "";

		$objModel = $this->loadModel('compromisoPago');
		$result = $objModel->generarId();

		$result->nextRowset();
		
		if ($result->rowCount()){
				foreach ($result as $row) {	
					$idCompromiso=$row['idCompromiso'];
				}
		}
		return $idCompromiso;
	}

	public function generarIdDet(){

		$idCompromisoDet = "";

		$objModel = $this->loadModel('compromisoPago');
		$result = $objModel->generarIdDet();

		$result->nextRowset();
		
		if ($result->rowCount()){
				foreach ($result as $row) {	
					$idCompromisoDet=$row['idCompromisoDet'];
				}
		}
		return $idCompromisoDet;
	}

	public function getCompromisos(){

		if(isset($_SESSION['id'])){
					
			$idCompromiso = '';
			$ruc = '';
		    $rec = '';
		    $rc = '';
		    $rucTercero = '';
		    $dniEncargadoTercero = '';
		    $fecRegIni = '';
		    $fecRegFin = '';
		    $estado = '';
			$idUsuarioSession = $_SESSION['id'];

		   	if(isset($_POST['idCompromiso'])){
				$idCompromiso = trim($_POST['idCompromiso']);
			}
			if(isset($_POST['ruc'])){
				$ruc = trim($_POST['ruc']);
			}
			if(isset($_POST['rec'])){
				$rec = trim($_POST['rec']);
			}
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			if(isset($_POST['rucTercero'])){
				$rucTercero = trim($_POST['rucTercero']);
			}
			if(isset($_POST['dniEncargadoTercero'])){
				$dniEncargadoTercero = trim($_POST['dniEncargadoTercero']);
			}
			if(isset($_POST['fecRegIni'])){
				$fecRegIni = trim($_POST['fecRegIni']);
			}
			if(isset($_POST['fecRegFin'])){
				$fecRegFin = trim($_POST['fecRegFin']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}

			$objModel = $this->loadModel('compromisoPago');
			$result = $objModel->getCompromisos($idCompromiso,$ruc,$rec,$rc,$rucTercero,$dniEncargadoTercero,$fecRegIni,$fecRegFin,$estado,$idUsuarioSession);

			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}


	public function getCuotas(){

		if(isset($_SESSION['id'])){
			
			$idCompromiso = '';
			$rucTercero = '';
			$fechaVencimientoCuotaIni = '';
			$fechaVencimientoCuotaFin = '';
			$mtoCuotaIni = '';
			$mtoCuotaFin = '';
			$saldoMtoEmbIni = '';
			$saldoMtoEmbFin = '';

		    if(isset($_POST['idCompromiso'])){
				$idCompromiso = trim($_POST['idCompromiso']);
			}
			if(isset($_POST['rucTercero'])){
				$rucTercero = trim($_POST['rucTercero']);
			}
			if(isset($_POST['fechaVencimientoCuotaIni'])){
				$fechaVencimientoCuotaIni = trim($_POST['fechaVencimientoCuotaIni']);
			}
			if(isset($_POST['fechaVencimientoCuotaFin'])){
				$fechaVencimientoCuotaFin = trim($_POST['fechaVencimientoCuotaFin']);
			}
			if(isset($_POST['mtoCuotaIni'])){
				$mtoCuotaIni = trim($_POST['mtoCuotaIni']);
			}
			if(isset($_POST['mtoCuotaFin'])){
				$mtoCuotaFin = trim($_POST['mtoCuotaFin']);
			}
			if(isset($_POST['saldoMtoEmbIni'])){
				$saldoMtoEmbIni = trim($_POST['saldoMtoEmbIni']);
			}
			if(isset($_POST['saldoMtoEmbFin'])){
				$saldoMtoEmbFin = trim($_POST['saldoMtoEmbFin']);
			}
			
			$objModel = $this->loadModel('compromisoPago');
			$result = $objModel->getCuotas($idCompromiso,$rucTercero,$fechaVencimientoCuotaIni,$fechaVencimientoCuotaFin,$mtoCuotaIni,$mtoCuotaFin,$saldoMtoEmbIni,$saldoMtoEmbFin);
		

			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);
		}
		
	}


	public function insCompromiso(){

		if(isset($_SESSION['id'])){
			
			$idCompromiso=$this->generarId();
			$ruc = '';
			$rec = '';
			$rc = '';
			$numEmb = '';
			$fecPrimerPago = '';
			$formaPagoPropuesto = '';
			$nroCuotas = '';
			$mtoCuota = '';
			$tipoFrecuencia = '';
			$diaSemana = '';
			$diaMes = '';
			$montoTotalInformado = '';
			$dniEncargadoTercero = '';
			$nombreEncargadoTercero = '';
			$observacion = '';
			$usuReg = $_SESSION['id'];
			$estado = '01';
			$codTercero = '';

			if(isset($_POST['ruc'])){
				$ruc = trim($_POST['ruc']);
			}
			if(isset($_POST['rec'])){
				$rec = trim($_POST['rec']);
			}
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			if(isset($_POST['fecPrimerPago'])){
				$fecPrimerPago = trim($_POST['fecPrimerPago']);
			}			
			if(isset($_POST['formaPagoPropuesto'])){
				$formaPagoPropuesto = trim($_POST['formaPagoPropuesto']);
			}
			if(isset($_POST['nroCuotas'])){
				$nroCuotas = trim($_POST['nroCuotas']);
			}

			if(isset($_POST['tipoFrecuencia'])){
				$tipoFrecuencia = trim($_POST['tipoFrecuencia']);
			}			
			if(isset($_POST['diaSemana'])){
				$diaSemana = trim($_POST['diaSemana']);
			}			
			if(isset($_POST['diaMes'])){
				$diaMes = trim($_POST['diaMes']);
			}			
			if(isset($_POST['montoTotalInformado'])){
				$montoTotalInformado = trim($_POST['montoTotalInformado']);
			}
			if(isset($_POST['dniEncargadoTercero'])){
				$dniEncargadoTercero = trim($_POST['dniEncargadoTercero']);
			}
			if(isset($_POST['nombreEncargadoTercero'])){
				$nombreEncargadoTercero = trim($_POST['nombreEncargadoTercero']);
			}
			if(isset($_POST['observacion'])){
				$observacion = trim($_POST['observacion']);
			}
			if(isset($_POST['codTercero'])){
				$codTercero = trim($_POST['codTercero']);
			}

			$mtoCuota = intval($montoTotalInformado / $nroCuotas);


			$objModel = $this->loadModel('compromisoPago');
			$objModel->insCompromiso($idCompromiso,$ruc,$rec,$rc,$fecPrimerPago,$formaPagoPropuesto,$nroCuotas,$mtoCuota,$tipoFrecuencia,$diaSemana,$diaMes,$montoTotalInformado,$dniEncargadoTercero,$nombreEncargadoTercero,$observacion,$usuReg,$estado,$codTercero);


			$this->insCompromisoDet($idCompromiso,$ruc,$rec,$rc,$fecPrimerPago,$formaPagoPropuesto,$nroCuotas,$mtoCuota,$tipoFrecuencia,$diaSemana,$diaMes,$montoTotalInformado,$dniEncargadoTercero,$nombreEncargadoTercero,$observacion,$usuReg,$estado,$codTercero);

			

			$result = $objModel->getCompromisos($idCompromiso,'','','','','','','','','');

			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);

		}
	}

	public function updCompromiso(){

		if(isset($_SESSION['id'])){

			$idCompromiso = '';
			$rc = '';
			$rec = '';
			$ruc = '';
			$codTercero = '';
			$fecPrimerPago = '';
			$formaPagoPropuesto = '';
			$nroCuotas = '';
			$mtoCuota = '';
			$tipoFrecuencia = '';
			$diaSemana = '';
			$diaMes = '';
			$montoTotalInformado = '';
			$dniEncargadoTercero = '';
			$nombreEncargadoTercero = '';
			$observacion = '';
			$estado = '';
			$usuMod=$_SESSION['id'];

			if(isset($_POST['idCompromiso'])){
				$idCompromiso = trim($_POST['idCompromiso']);
			}
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			if(isset($_POST['rec'])){
				$rec = trim($_POST['rec']);
			}
			if(isset($_POST['ruc'])){
			 	$ruc = trim($_POST['ruc']);
			}
			if(isset($_POST['codTercero'])){
				$codTercero = trim($_POST['codTercero']);
			}			
			if(isset($_POST['fecPrimerPago'])){
				$fecPrimerPago = trim($_POST['fecPrimerPago']);
			}
			if(isset($_POST['formaPagoPropuesto'])){
				$formaPagoPropuesto = trim($_POST['formaPagoPropuesto']);
			}			
			if(isset($_POST['nroCuotas'])){
				$nroCuotas = trim($_POST['nroCuotas']);
			}
			if(isset($_POST['tipoFrecuencia'])){
				$tipoFrecuencia = trim($_POST['tipoFrecuencia']);
			}	
			if(isset($_POST['diaSemana'])){
				$diaSemana = trim($_POST['diaSemana']);
			}	
			if(isset($_POST['diaMes'])){
				$diaMes = trim($_POST['diaMes']);
			}			
			if(isset($_POST['montoTotalInformado'])){
				$montoTotalInformado = trim($_POST['montoTotalInformado']);
			}
			if(isset($_POST['dniEncargadoTercero'])){
				$dniEncargadoTercero = trim($_POST['dniEncargadoTercero']);
			}
			if(isset($_POST['nombreEncargadoTercero'])){
				$nombreEncargadoTercero = trim($_POST['nombreEncargadoTercero']);
			}
			if(isset($_POST['observacion'])){
				$observacion = trim($_POST['observacion']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}

			$mtoCuota = intval($montoTotalInformado / $nroCuotas);
			
			$objModel = $this->loadModel('compromisoPago');
			
			$objModel->updCompromiso($idCompromiso,$rc,$rec,$ruc,$codTercero,$fecPrimerPago,$formaPagoPropuesto,$nroCuotas,$mtoCuota,$tipoFrecuencia,$diaSemana,$diaMes,$montoTotalInformado,$dniEncargadoTercero,$nombreEncargadoTercero,$observacion,$estado,$usuMod);


			$objModel->delCompromisoDet($idCompromiso);


			$this->insCompromisoDet($idCompromiso,$ruc,$rec,$rc,$fecPrimerPago,$formaPagoPropuesto,$nroCuotas,$mtoCuota,$tipoFrecuencia,$diaSemana,$diaMes,$montoTotalInformado,$dniEncargadoTercero,$nombreEncargadoTercero,$observacion,$usuMod,$estado,$codTercero);

			$result = $objModel->getCompromisos($idCompromiso,'','','','','','','','','');

			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
		else{
			$this->_view->renderizar('login',true);//true para que aprezca sin encabezado
		}
	}

	public function delCompromiso(){

		if(isset($_SESSION['id'])){

			$idCompromiso = "";
		
			if(isset($_POST['idCompromiso'])){
				$idCompromiso = $_POST['idCompromiso'];
			}

			$objModel = $this->loadModel('compromisoPago');
			$objModel->delCompromiso($idCompromiso);


			$result = $objModel->getCompromisos($idCompromiso,'','','','','','','','01','');

			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);

		}
		else{
			$this->_view->renderizar('login',true);//true para que aprezca sin encabezado
		}
	}

	public function insCompromisoDet($idCompromiso,$ruc,$rec,$rc,$fecPrimerPago,$formaPagoPropuesto,$nroCuotas,$mtoCuota,$tipoFrecuencia,$diaSemana,$diaMes,$montoTotalInformado,$dniEncargadoTercero,$nombreEncargadoTercero,$observacion,$usuReg,$estado,$codTercero){

		$saldoMtoEmb = $montoTotalInformado;
		$fechaVencimientoCuota = $fecPrimerPago;


		$objModel = $this->loadModel('compromisoPago');


		if($tipoFrecuencia=="03"){
			//SEMANAL
			for ($i = 1; $i <= $nroCuotas; $i++) {
			    				
				if (date('w', strtotime($fechaVencimientoCuota))==0){
					$diaSemana2 = 'DO';
				}
				if (date('w', strtotime($fechaVencimientoCuota))==1){
					$diaSemana2 = 'LU';
				}
				if (date('w', strtotime($fechaVencimientoCuota))==2){
					$diaSemana2 = 'MA';
				}
				if (date('w', strtotime($fechaVencimientoCuota))==3){
					$diaSemana2 = 'MI';
				}
				if (date('w', strtotime($fechaVencimientoCuota))==4){
					$diaSemana2 = 'JU';
				}
				if (date('w', strtotime($fechaVencimientoCuota))==5){
					$diaSemana2 = 'VI';
				}
				if (date('w', strtotime($fechaVencimientoCuota))==6){
					$diaSemana2 = 'SA';
				}
				

				while ($diaSemana <> $diaSemana2) {

					$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' + 1 days'));

					if (date('w', strtotime($fechaVencimientoCuota))==0){
						$diaSemana2 = 'DO';
					}
					if (date('w', strtotime($fechaVencimientoCuota))==1){
						$diaSemana2 = 'LU';
					}
					if (date('w', strtotime($fechaVencimientoCuota))==2){
						$diaSemana2 = 'MA';
					}
					if (date('w', strtotime($fechaVencimientoCuota))==3){
						$diaSemana2 = 'MI';
					}
					if (date('w', strtotime($fechaVencimientoCuota))==4){
						$diaSemana2 = 'JU';
					}
					if (date('w', strtotime($fechaVencimientoCuota))==5){
						$diaSemana2 = 'VI';
					}
					if (date('w', strtotime($fechaVencimientoCuota))==6){
						$diaSemana2 = 'SA';
					}

					//echo $fechaVencimientoCuota;
					//echo ' ';
		        }


				$idCompromisoDet = $this->generarIdDet();
				$fechaVencimientoCuota = $fechaVencimientoCuota;
				$mtoCuota = intval($montoTotalInformado / $nroCuotas);					
				$saldoMtoEmb = $saldoMtoEmb - $mtoCuota;
				if ($i == $nroCuotas){
					if($saldoMtoEmb>0){
						$mtoCuota = intval($mtoCuota + $saldoMtoEmb);
						$saldoMtoEmb = 0;
					}
				}
				$estado = '01';

				

				$objModel->insCompromisoDet($idCompromisoDet,$idCompromiso,$fechaVencimientoCuota,$mtoCuota,$saldoMtoEmb,$estado,$usuReg);

				if ($i < $nroCuotas){
						$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' + 1 days'));
				}
			}
		}

		if($tipoFrecuencia=="05"){
			//BIMENSUAL

			/*while (date('j', strtotime($fechaVencimientoCuota)) <> $diaMes){
				$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' + 1 days'));
			}*/

			$diaMes = date('j', strtotime($fechaVencimientoCuota));

			$fechaVencimientoSegundaCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' + 14 days'));	
			

			$i = 1;
			
			while ($i <= $nroCuotas){

				

				if ($i == 1){

					$idCompromisoDet = $this->generarIdDet();
					$fechaVencimientoCuota = $fechaVencimientoCuota;
					$mtoCuota = intval($montoTotalInformado / $nroCuotas);
					$saldoMtoEmb = $saldoMtoEmb - $mtoCuota;
					if ($i == $nroCuotas){
						if($saldoMtoEmb>0){
							$mtoCuota = intval($mtoCuota + $saldoMtoEmb);
							$saldoMtoEmb = 0;
						}
					}
					$estado = '01';

					$objModel->insCompromisoDet($idCompromisoDet,$idCompromiso,$fechaVencimientoCuota,$mtoCuota,$saldoMtoEmb,$estado,$usuReg);
				}else{

					
					while (date('j', strtotime($fechaVencimientoCuota)) > 28){
						$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' - 1 days'));							
					}
					
					$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' + 1 month'));

					$idCompromisoDet = $this->generarIdDet();
					$fechaVencimientoCuota = $fechaVencimientoCuota;
					$mtoCuota = intval($montoTotalInformado / $nroCuotas);
					$saldoMtoEmb = $saldoMtoEmb - $mtoCuota;
					if ($i == $nroCuotas){
						if($saldoMtoEmb>0){
							$mtoCuota = intval($mtoCuota + $saldoMtoEmb);
							$saldoMtoEmb = 0;
						}
					}
					$estado = '01';

					$objModel->insCompromisoDet($idCompromisoDet,$idCompromiso,$fechaVencimientoCuota,$mtoCuota,$saldoMtoEmb,$estado,$usuReg);
				}

				$i++;

				if ($i <= $nroCuotas){

					if ($i == 2){

						$idCompromisoDet = $this->generarIdDet();
						$fechaVencimientoSegundaCuota = $fechaVencimientoSegundaCuota;
						$mtoCuota = intval($montoTotalInformado / $nroCuotas);
						$saldoMtoEmb = $saldoMtoEmb - $mtoCuota;
						if ($i == $nroCuotas){
							if($saldoMtoEmb>0){
								$mtoCuota = intval($mtoCuota + $saldoMtoEmb);
								$saldoMtoEmb = 0;
							}
						}
						$estado = '01';

						$objModel->insCompromisoDet($idCompromisoDet,$idCompromiso,$fechaVencimientoSegundaCuota,$mtoCuota,$saldoMtoEmb,$estado,$usuReg);
					}else{
						$fechaVencimientoSegundaCuota = date('Y-m-d', strtotime($fechaVencimientoSegundaCuota. ' + 1 month'));

						$idCompromisoDet = $this->generarIdDet();
						$fechaVencimientoSegundaCuota = $fechaVencimientoSegundaCuota;
						$mtoCuota = intval($montoTotalInformado / $nroCuotas);
						$saldoMtoEmb = $saldoMtoEmb - $mtoCuota;
						if ($i == $nroCuotas){
							if($saldoMtoEmb>0){
								$mtoCuota = intval($mtoCuota + $saldoMtoEmb);
								$saldoMtoEmb = 0;
							}
						}
						$estado = '01';

						$objModel->insCompromisoDet($idCompromisoDet,$idCompromiso,$fechaVencimientoSegundaCuota,$mtoCuota,$saldoMtoEmb,$estado,$usuReg);
					}

					$i++;

				}

				
			}
		}

		if($tipoFrecuencia=='07' || 
			$tipoFrecuencia=='09' || 
			$tipoFrecuencia=='11' ||
			$tipoFrecuencia=='13' ||
			$tipoFrecuencia=='15' ||
			$tipoFrecuencia=='17'){
			//MENSUAL
			/*while (date('j', strtotime($fechaVencimientoCuota)) <> $diaMes){
				$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' + 1 days'));
			}*/

			for ($i = 1; $i <= $nroCuotas; $i++) {
			    
				

				$idCompromisoDet = $this->generarIdDet();
				$fechaVencimientoCuota = $fechaVencimientoCuota;
				$mtoCuota = intval($montoTotalInformado / $nroCuotas);
				$saldoMtoEmb = $saldoMtoEmb - $mtoCuota;
				if ($i == $nroCuotas){
					if($saldoMtoEmb>0){
						$mtoCuota = intval($mtoCuota + $saldoMtoEmb);
						$saldoMtoEmb = 0;
					}
				}
				$estado = '01';

				

				$objModel->insCompromisoDet($idCompromisoDet,$idCompromiso,$fechaVencimientoCuota,$mtoCuota,$saldoMtoEmb,$estado,$usuReg);

				while (date('j', strtotime($fechaVencimientoCuota)) > 28){
					$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' - 1 days'));			
				}


				if ($i < $nroCuotas){

					if($tipoFrecuencia=='07'){
						$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' +1 month'));
					}
					if($tipoFrecuencia=='09'){
						$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' +2 month'));
					}
					if($tipoFrecuencia=='11'){
						$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' +3 month'));
					}
					if($tipoFrecuencia=='13'){
						$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' +4 month'));
					}
					if($tipoFrecuencia=='15'){
						$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' +6 month'));
					}
					if($tipoFrecuencia=='17'){
						$fechaVencimientoCuota = date('Y-m-d', strtotime($fechaVencimientoCuota. ' +12 month'));
					}
				}
			}
		}
	}


	public function getCantCompromisosPorTercero(){

		if(isset($_SESSION['id'])){
			
			
		    $idUsuarioSession = $_SESSION['id'];



			$objModel = $this->loadModel('compromisoPago');
			$result = $objModel->getCantCompromisosPorTercero();

			

			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
		else{
			$this->_view->renderizar('login',true);//true para que aprezca sin encabezado
		}
	}
	

	public function getDatosRC(){

		if(isset($_SESSION['id'])){

			$rc = '';
	    
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			
			$objModel = $this->loadModel('compromisoPago');
			$result = $objModel->getDatosRC($rc);


			$arreglo['data'] = array();
			

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);

		}
	}


	public function getListaTerceros(){

		if(isset($_SESSION['id'])){

			$rc = '';
	    
			if(isset($_POST['rc'])){
				$rc = trim($_POST['rc']);
			}
			
			$objModel = $this->loadModel('compromisoPago');
			$result = $objModel->getListaTerceros($rc);


			$arreglo["data"] = array();
			
			
			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		
		}
	}

	
	public function pdfCronograma() {
	
		if(isset($_SESSION['id'])){

			if(isset($_POST['idCompromiso'])){
				$idCompromiso = trim($_POST['idCompromiso']);
			}
		
			
			$objCompromisoPago= $this->loadModel('compromisoPago');
			$result = $objCompromisoPago->getCompromisos($idCompromiso,'','','','','','','','','');	
													 	
			while ($row = $result->fetch())  {

				$id = $row['id'];
				$ruc = $row['ruc'];				
				$rucDesc = $row['rucDesc'];
				$rec = $row['rec'];
				$rc = $row['rc'];
				$fecPrimerPago = $row['fecPrimerPago'];
				$formaPagoPropuesto_desc = $row['formaPagoPropuesto_desc'];
				$nroCuotas = $row['nroCuotas'];
				$mtoCuota = $row['mtoCuota'];
				$tipoFrecuencia = $row['tipoFrecuencia'];
				$montoTotalInformado = $row['montoTotalInformado'];
				$dniEncargadoTercero = $row['dniEncargadoTercero'];
				$nombreEncargadoTercero = $row['nombreEncargadoTercero'];
				$observacion = $row['observacion'];
				$num_ruc_ter = $row['num_ruc_ter'];
				$nom_ter = $row['nom_ter'];
				

			}

			$fechaImpresion = date('d-m-Y');  
			//echo "The current date and time are $DateAndTime.";

			//$direccion = mb_strtolower($direccion, 'UTF-8');

			//$direccion = ucwords($direccion);
			

			

			//Obteniendo ruta servidor
			/*$result = $objCarta->getRutaRepositorio();
			$ruta_repositorio="";

			while ($row = $result->fetch()){
			     $ruta_repositorio=$row[0]; 
			}*/

			
			$pdf = new MYPDF('P', PDF_UNIT, 'A4', true, 'UTF-8', false, true);
							
			//$ruta_visto = $ruta_visto."V.jpg";
			//$ruta_visto = str_replace('\\\\', '\\', $ruta_visto);
			//$ruta_visto = '\\PO-7\POD\FIRMAS\19181530V.jpg';

			//$pdf->setRutaVisto1($ruta_visto);
			//$pdf->setEstado($estado);
			//$pdf->setNombreAnual($nombre_anual);
			//$pdf->setNombreDecenio($nombre_decenio);
		
			// set document information
			$pdf->SetCreator(PDF_CREATOR);
			$pdf->SetAuthor('Cobraly');
			$pdf->SetTitle('Cronograma de Pagos de Compromisos');
			$pdf->SetSubject('Cronograma de Pagos de Compromisos');
			$pdf->SetKeywords('Cronograma,Cobraly');
	
			// remove default header/footer 
			$pdf->setPrintHeader(true); 
			//$pdf->setPrintFooter(true);

			// set auto page breaks
			$pdf->SetAutoPageBreak(TRUE, 25);
		
			// ---------------------------------------------------------

			// set default font subsetting mode
			$pdf->setFontSubsetting(true);

			// Set font
			$pdf->SetFont('helvetica', '', 10, '', true);

			//SetMargins($left,$top,$right = -1,$keepmargins = false)
			$pdf->SetMargins(0, 35, 0, true);
			
			// Add a page
			$pdf->AddPage('P', 'A4');

			// Set some content to print
			$html = <<<EOD

<span style="text-align:justify;"><b><u>Código de Cronograma: $id</u></b><br><br>
Tercero:<br>
<b>$nom_ter</b><br>
RUC N°: $num_ruc_ter<br>
Fecha Impresión: $fechaImpresion<br><br>

</span>


	
<center>
	<table width="100%" border="1" cellpadding="2" cellspacing="0" bordercolor="#9B9B9B">
		
		<tr>
			
			<td align="center" >
				N° Cuota
			</td>
			
			<td align="center">
				Fecha Vencimiento
			</td>

			<td align="center">
				Monto Cuota
			</td>												

			<td align="center">
				Saldo Monto 
			</td>

		</tr>
EOD;

		$result = $objCompromisoPago->getCuotas($idCompromiso,'','','','','','','');	
				 	
		while ($row = $result->fetch())  {
		    $html .= 
			'<tr>

				<td align="center">
					'.$row['nroCuota'].'
				</td>	
				<td align="center">
					'.$row['fechaVencimientoCuota'].'
				</td>	
				<td align="center">
					'.$row['mtoCuota'].'
				</td>												
				<td align="center">
					'.$row['saldoMtoEmb'].'
				</td>										
			</tr>';
		}

		$html .= '
		

	</table>
</center>		
<br>
<br>
<br>
<br>

				
<center>
	<table width="100%" border="0" cellpadding="2" cellspacing="0">
		
		<tr>
			
			<td align="center" >
				_____________________________
			</td>
			
			<td align="center">
				_____________________________
			</td>
		</tr>
		<tr>
			
			<td align="center" >
				<br>
				<br>
				Representante SUNAT
			</td>

			

			<td align="center">
				<b>'.$nombreEncargadoTercero.'</b><br>
				DNI N°: '.$dniEncargadoTercero.'<br>
				Representante de '.$nom_ter.'<br>
			</td>
		</tr>
	</table>
</center>
					
					
				

';
//EOD;
//echo 			$html;
			// Print text using writeHTMLCell()
			$pdf->writeHTMLCell(165, 0, 25, 40, $html, 0, 1, 0, true, '', true);

			$pdf->Output('prueba.pdf', 'I');
			/*if ($accion=="01"){
				//Primiliminar
				$pdf->Output($num_doc.'.pdf', 'I');
			}elseif($accion=="02"){
				//Emitir
				$ruta_final = $ruta_repositorio.$id_carta.'.pdf';
				$ruta_final=addslashes($ruta_final);
				$pdf->Output($ruta_final, 'F');
			}*/
			

		
			
		
		}else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
		}
	}


	

	

	public function getDatosGrafico1(){
		
		if(isset($_SESSION['id'])){
	
			$idUsuario = '';
			$periodo='';

			if(isset($_POST['idUsuario'])){
				$idUsuario = $_POST['idUsuario'];
			}
			if(isset($_POST['periodo'])){
				$periodo = $_POST['periodo'];
			}

			$anho=substr($periodo, 0, 4); 
			$mes=(int)substr($periodo, 5, 2); 


			$objModel = $this->loadModel('actividadPersonal');
			$result = $objModel->getDatosGrafico1($idUsuario,$anho,$mes);

			$arrayDatos["data"] = array();

			while ($row = $result->fetch())  {
			    $arrayDatos["data"][] = $row;
			}

			echo json_encode($arrayDatos);

		}
	}


	public function getDatosGrafico2(){
		
		if(isset($_SESSION['id'])){
	
			$idArea = '';
			$periodo='';

			if(isset($_POST['idArea'])){
				$idArea = $_POST['idArea'];
			}
			if(isset($_POST['periodo'])){
				$periodo = $_POST['periodo'];
			}




			$anho=substr($periodo, 0, 4); 
			$mes=(int)substr($periodo, 5, 2); 


			if(substr($idArea, -4) =='0000'){
				$idArea=substr($idArea, 0, 2).'%';
			}

			if(substr($idArea, -3) =='000'){
				$idArea=substr($idArea, 0, 3).'%';
			}

			if(substr($idArea, -2) =='00'){
				$idArea=substr($idArea, 0, 4).'%';
			}

			if(substr($idArea, -1) =='0'){
				$idArea=substr($idArea, 0, 5).'%';
			}


			$objModel = $this->loadModel('actividadPersonal');
			$result = $objModel->getDatosGrafico2($idArea,$anho,$mes);

			$arrayDatos["data"] = array();

			while ($row = $result->fetch())  {
			    $arrayDatos["data"][] = $row;
			}

			echo json_encode($arrayDatos);

		}
	}
	
	
}


class MYPDF extends TCPDF {

	private $rutaVisto1;
	private $estado;
	private $nombreAnual;
	private $nombreDecenio;

	protected $last_page_flag = false;

	public function setRutaVisto1($RutaVisto1) {
		$this->rutaVisto1=$RutaVisto1;
	}

	public function setEstado($Estado) {
		$this->estado=$Estado;
	}

	public function setNombreAnual($NombreAnual) {
		$this->nombreAnual=$NombreAnual;
	}

	public function setNombreDecenio($NombreDecenio) {
		$this->nombreDecenio=$NombreDecenio;
	}

	public function Header() {

		//Cabecera
		$html = '
		<table cellspacing="20" cellpadding="0" border="0">
			<tr>
				<td>

					<table cellspacing="0" cellpadding="0" border="0">
						<tr>
							<td></td>
							<td></td>
							<td><img src=".\reportes\carta\Logout5.jpg"></td>
						</tr>
					
					</table>

					<table cellspacing="0" cellpadding="0" border="0">
					
						<tr>
							<td align="center">
								<font size="12" face="arial">
									CRONOGRAMA DE PAGOS
									<br>
								</font>
							</td>
							
						</tr>
					
					</table>
				</td>
			</tr>
		</table>
		';

     	$this->writeHTMLCell($w = 0, $h = 0, $x = '', $y = '', $html, $border = 0, $ln = 1, $fill = 0, $reseth = true, $align = 'top', $autopadding = true);
    	    	    	
	}

	public function Close() {
	    $this->last_page_flag = true;
	    parent::Close();
	}

	public function Footer(){
	    /*if($this->last_page_flag){
	        $footer_html = ''; //HTML for the footer on the last page


	    }
	    else{
	    	if($this->estado == "04" || $this->estado == "05" ){

	    		$footer_html = '
		    	<table cellspacing="0" cellpadding="0" border="0">
					<tr>
						<td align="center">				
							<img src="'.$this->rutaVisto1.'" width="400" height="400">				
						</td>
					</tr>
				</table>'; //HTML for the rest of the pages
	    	}else{
	    		$footer_html = '';
	    	}
	        
	    }

	    

	   	$this->writeHTMLCell($w = 24, $h = 24, $x = 2, $y = 175, $footer_html, $border = 0, $ln = 1, $fill = 0, $reseth = true, $align = 'top', $autopadding = true);
	   	*/

	    $html = '
    	<table cellspacing="0" cellpadding="0" border="0">
    		
			<tr>
				<td align="center">
					<img src=".\reportes\carta\pie.jpg" width="900" height="60">				
				</td>
			</tr>
		</table>';

    	$this->writeHTMLCell($w = 190, $h = 13, $x = 10, $y = 275, $html, $border = 0, $ln = 1, $fill = 0, $reseth = true, $align = 'top', $autopadding = true);

    	$this->setPageMark();
	}
}

?>