<?php 

class layoutController extends Controller{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
	}

	public function getFotoUsuarioSession(){

		if(isset($_SESSION['id'])){
			
			$objModelLayout = $this->loadModel('layout');
			$objModelLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
		
			$foto = $objModelLayout->getFoto();


			if (is_null($foto)==true){
				//echo BASE_URL."public/assets/img/" .(($objModel->getSexo() == 'F') ? 'admin-avatar_woman.png' : 'admin-avatar.png');


				$image = BASE_URL."public/assets/img/" .(($objModelLayout->getSexo() == 'F') ? 'admin-avatar_woman.png' : 'admin-avatar.png');

				$mimetype="image/jpeg";
				header("Content-Type: ".$mimetype);

				echo file_get_contents($image);
			}else{
				$mimetype="image/jpeg";
				header("Content-Type: ".$mimetype);
				


				//pack('H*', $foto)
				//base64_decode
				//echo pack('H*', $fo);
				echo  pack('H*', $foto);
			}

				

			

		}
		
	}

	
}
?>