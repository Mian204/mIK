<?php 

class solicitudServicioController extends Controller{
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
	}


	public function consulta(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SOLICITUDSERVICIO/CONSULTA',true)){

			    $idSolicitudServicio = '';
				$usuReg = '';
				$estado = '';
				$usuTrabajador = '';
				$shape = '1';
			    $title = 'Solicitudes de Servicio';
			    
			   	
			   	if(isset($_POST['idSolicitudServicio'])){	
					$idSolicitudServicio = trim($_POST['idSolicitudServicio']);
				}
			   	if(isset($_POST['usuReg'])){	
					$usuReg = trim($_POST['usuReg']);
				}
				if(isset($_POST['estado'])){	
					$estado = trim($_POST['estado']);
				}			   	
				if(isset($_POST['usuTrabajador'])){	
					$usuTrabajador = trim($_POST['usuTrabajador']);
				}				
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}			

				$this->_view->idSolicitudServicio = $idSolicitudServicio;
				$this->_view->usuReg = $usuReg;
				$this->_view->estado = $estado;
				$this->_view->usuTrabajador = $usuTrabajador;
				$this->_view->shape = $shape;
				$this->_view->title = $title;

				$this->_view->setJs(array('consulta')); 
				$this->_view->renderizar('consulta');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}
	
	public function asignacion(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SOLICITUDSERVICIO/ASIGNACION',true)){
				
				$_POST['estado'] = '01';
				$_POST['shape']='2';
				$_POST['title']='Asignacion de Solicitudes';

				$this->consulta();

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);//true para que aprezca sin encabezado
		}
	}

	public function misPendientes(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('SOLICITUDSERVICIO/ASIGNACION',true)){
				
				$_POST['usuTrabajador'] = $_SESSION['id'];
				$_POST['estado'] = '02';				
				$_POST['shape']='3';
				$_POST['title']='Mis Solicitudes Pendientes';

				$this->consulta();

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);//true para que aprezca sin encabezado
		}
	}

	public function generarId(){

		$idSolicitudServicio = '';

		$objModel = $this->loadModel('solicitudServicio');
		$result = $objModel->generarId();

		$result->nextRowset();
		
		if ($result->rowCount()){
				foreach ($result as $row) {	
					$idSolicitudServicio=$row['idSolicitudServicio'];
				}
		}
		return $idSolicitudServicio;
	}

	
	public function getSolicitudesServicios(){

		if(isset($_SESSION['id'])){
			
			$idSolicitudServicio  = '';
			$usuReg = '';
			$fecRegIni = '';
			$fecRegFin = '';	
			$usuTrabajador = '';					
			$estado = '';
		    $estadoArray = array();



		   	if(isset($_POST['idSolicitudServicio'])){	
				$idSolicitudServicio = trim($_POST['idSolicitudServicio']);
			}					
			if(isset($_POST['usuReg'])){	
				$usuReg = trim($_POST['usuReg']);
			}
			if(isset($_POST['fecRegIni'])){	
				$fecRegIni = trim($_POST['fecRegIni']);
			}
			if(isset($_POST['fecRegFin'])){	
				$fecRegFin = trim($_POST['fecRegFin']);
			}
		   	if(isset($_POST['usuTrabajador'])){	
				$usuTrabajador = trim($_POST['usuTrabajador']);
			}
			if(isset($_POST['estado'])){	
				$estado = trim($_POST['estado']);
			}
			if(isset($_POST['estadoArray'])){
				$estadoArray = $_POST['estadoArray'];
			}
			
			if($estado==''){
				$estado = '*';
				array_push($estadoArray, '01');
				array_push($estadoArray, '02');
				array_push($estadoArray, '03');
			}
		

			$objModel = $this->loadModel('solicitudServicio');
			$result = $objModel->getSolicitudesServicios($idSolicitudServicio,$usuReg,$fecRegIni,$fecRegFin,$usuTrabajador,$estado,$estadoArray);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}
	
	public function insSolicitudServicio(){

		if(isset($_SESSION['id'])){
						
			$idSolicitudServicio = $this->generarId();
			$tipoSolicitud = '';
			$tipoRes = '';
			$rutaArchivoPdf = $idSolicitudServicio.'.pdf';
			$rutaArchivoExcel = $idSolicitudServicio.'.xlsx';
			$totalDocumentos = '';
			$usuReg = $_SESSION['id'];	
			$estado = '01';
			$obsRegistro = '';
			$obsAtencion = '';

			
			
		   	if(isset($_POST['tipoSolicitud'])){	
				$tipoSolicitud = trim($_POST['tipoSolicitud']);
			}
		   	if(isset($_POST['tipoRes'])){	
				$tipoRes = trim($_POST['tipoRes']);
			}
		   	
		   	if(isset($_POST['totalDocumentos'])){	
				$totalDocumentos = trim($_POST['totalDocumentos']);
			}		   	
			
		   	if(isset($_POST['obsRegistro'])){	
				$obsRegistro = trim($_POST['obsRegistro']);
			}


		   	if(isset($_POST['obsAtencion'])){	
				$obsAtencion = trim($_POST['obsAtencion']);
			}

			

			
					
			
			//Obteniendo id_dependencia
			$id_dependencia = '';
			
			if(isset($_SESSION['id_dependencia'])){
				$id_dependencia = $_SESSION['id_dependencia'];
			}

			//Obteniendo ruta servidor
			$objAplicacion = $this->loadModel('aplicacion');
			$result = $objAplicacion->getRutasDependencia('015_001',$id_dependencia,'','',array());
			
			$rutaRepositorio='';

			while ($row = $result->fetch()){
			     $rutaRepositorio=$row['ruta']; 
			}


			$archivo1Copiado = false;

			//Moviendo pdf
			if (!empty($_FILES['rutaArchivoPdf']['tmp_name']) ) 
			{
				$pcAdjunto = $_FILES['rutaArchivoPdf']['tmp_name'];
				//$nomAdjunto = $_FILES['rutaArchivoPdf']['name'];

				//$nombre_adjunto=$nomAdjunto;
				$targetFile = $rutaRepositorio.$rutaArchivoPdf;
				
				if (move_uploaded_file($pcAdjunto, $targetFile)){
					$archivo1Copiado = true;
				}else{
					$archivo1Copiado = false;
				}
			}

			$archivo2Copiado = false;

			//Moviendo Excel
			if (!empty($_FILES['rutaArchivoExcel']['tmp_name']) ) 
			{
				$pcAdjunto = $_FILES['rutaArchivoExcel']['tmp_name'];
				//$nomAdjunto = $_FILES['rutaArchivoPdf']['name'];

				//$nombre_adjunto=$nomAdjunto;
				$targetFile = $rutaRepositorio.$rutaArchivoExcel;
				
				if (move_uploaded_file($pcAdjunto, $targetFile)){
					$archivo2Copiado = true;
				}else{
					$archivo2Copiado = false;
				}
			}

			//if ($archivo1Copiado && $archivo2Copiado){
				$objModel = $this->loadModel('solicitudServicio');
				$objModel->insSolicitudServicio($idSolicitudServicio,$tipoSolicitud,$tipoRes,$rutaArchivoPdf,$rutaArchivoExcel,$totalDocumentos,$usuReg,$estado,$obsRegistro,$obsAtencion);
			//}
			

			
			$_POST = array();
			$_POST['idSolicitudServicio']=$idSolicitudServicio;
			$this->getSolicitudesServicios();

		}
	}
	 
	public function updSolicitudServicio(){

		if(isset($_SESSION['id'])){

			
			// $idAduanaLlamada = '';
			// $telefono = '';
			// $razonSocial = '';
			// $fecLlamada = '';
			// $apellidoPaterno = '';
			// $apellidoMaterno = '';
			// $nombres = '';
			// $cargo = '';
			// $contribuyenteContactado = '';
			// $resultadoLlamada = '';
			// $resultadoNegociacion = '';
			// $tipoLLamada = '';
			// $observacion = '';
			// $expCoactivo = '';
			// $rcEmbargo = '';
			// $respuesta = '';
			// $fecEstimadaEntrega = '';
			// $usuMod = $_SESSION['id'];
			// $estado = '';

		
			// if(isset($_POST['idAduanaLlamada'])){	
			// 	$idAduanaLlamada = trim($_POST['idAduanaLlamada']);
			// }
			// if(isset($_POST['telefono'])){	
			// 	$telefono = trim($_POST['telefono']);
			// }			
			// if(isset($_POST['razonSocial'])){	
			// 	$razonSocial = trim($_POST['razonSocial']);
			// }
			// if(isset($_POST['fecLlamada'])){	
			// 	$fecLlamada = trim($_POST['fecLlamada']);
			// }
		 //   	if(isset($_POST['apellidoPaterno'])){	
			// 	$apellidoPaterno = trim($_POST['apellidoPaterno']);
			// }
		 //   	if(isset($_POST['apellidoMaterno'])){	
			// 	$apellidoMaterno = trim($_POST['apellidoMaterno']);
			// }
		 //   	if(isset($_POST['nombres'])){	
			// 	$nombres = trim($_POST['nombres']);
			// }
		 //   	if(isset($_POST['cargo'])){	
			// 	$cargo = trim($_POST['cargo']);
			// }
		 //   	if(isset($_POST['contribuyenteContactado'])){	
			// 	$contribuyenteContactado = trim($_POST['contribuyenteContactado']);
			// }
		 //   	if(isset($_POST['resultadoLlamada'])){	
			// 	$resultadoLlamada = trim($_POST['resultadoLlamada']);
			// }
		 //   	if(isset($_POST['resultadoNegociacion'])){	
			// 	$resultadoNegociacion = trim($_POST['resultadoNegociacion']);
			// }
		 //   	if(isset($_POST['tipoLLamada'])){	
			// 	$tipoLLamada = trim($_POST['tipoLLamada']);
			// }
		 //   	if(isset($_POST['observacion'])){	
			// 	$observacion = trim($_POST['observacion']);
			// }
		 //   	if(isset($_POST['expCoactivo'])){	
			// 	$expCoactivo = trim($_POST['expCoactivo']);
			// }
		 //   	if(isset($_POST['rcEmbargo'])){	
			// 	$rcEmbargo = trim($_POST['rcEmbargo']);
			// }
		 //   	if(isset($_POST['respuesta'])){	
			// 	$respuesta = trim($_POST['respuesta']);
			// }
		 //   	if(isset($_POST['fecEstimadaEntrega'])){	
			// 	$fecEstimadaEntrega = trim($_POST['fecEstimadaEntrega']);
			// }
		  
			// if(isset($_POST['estado'])){	
			// 	$estado = trim($_POST['estado']);
			// }


			

			// $objModel = $this->loadModel('aduanaLlamada');
			// $objModel->updAduanaLlamada($idAduanaLlamada,$fecLlamada,$telefono,$razonSocial,$apellidoPaterno,$apellidoMaterno,$nombres,$cargo,$contribuyenteContactado,$resultadoLlamada,$resultadoNegociacion,$tipoLLamada,$observacion,$expCoactivo,$rcEmbargo,$respuesta,$fecEstimadaEntrega,$usuMod,$estado);

			
			// $_POST = array();
			// $_POST['idAduanaLlamada']=$idAduanaLlamada;
			// $this->getAduanasLlamadas();
			

		}
	}

	public function asiSolicitudServicio(){

		if(isset($_SESSION['id'])){

			$idSolicitudServicio = '';
			$usuAsigna = $_SESSION['id'];
			$usuTrabajador = '';	
			$fecTrabajador = '';		

			if(isset($_POST['idSolicitudServicio'])){	
				$idSolicitudServicio = trim($_POST['idSolicitudServicio']);
			}		   	
		   	if(isset($_POST['usuTrabajador'])){	
				$usuTrabajador = trim($_POST['usuTrabajador']);
			}

			if(isset($_POST['fecTrabajador'])){
				$fecTrabajador = date('m-d-Y h:i:s a', time());  
			}

			$objModel = $this->loadModel('solicitudServicio');
			$objModel->asiSolicitudServicio($idSolicitudServicio,$usuAsigna,$usuTrabajador,$fecTrabajador);

			
			$_POST = array();
			$_POST['idSolicitudServicio']=$idSolicitudServicio;
			$this->getSolicitudesServicios();
			

		}
	}

	public function conSolicitudServicio(){

		if(isset($_SESSION['id'])){

			$idSolicitudServicio = '';
			$obsAtencion = '';	


			if(isset($_POST['obsAtencion'])){	
				$obsAtencion = trim($_POST['obsAtencion']);
			}	

			if(isset($_POST['idSolicitudServicio'])){	
				$idSolicitudServicio = trim($_POST['idSolicitudServicio']);
			}	



			$objModel = $this->loadModel('solicitudServicio');
			$objModel->conSolicitudServicio($idSolicitudServicio,$obsAtencion);

			
			$_POST = array();
			$_POST['idSolicitudServicio']=$idSolicitudServicio;
			$this->getSolicitudesServicios();
			

		}
	}



	public function delSolicitudServicio(){

		if(isset($_SESSION['id'])){

			$idSolicitudServicio = '';
		
			if(isset($_POST['idSolicitudServicio'])){
				$idSolicitudServicio = $_POST['idSolicitudServicio'];
			}

			$objModel = $this->loadModel('solicitudServicio');
			$objModel->delSolicitudServicio($idSolicitudServicio);


			$_POST = array();
			$_POST['idSolicitudServicio']=$idSolicitudServicio;
			$_POST['estado']='DE';
			$this->getSolicitudesServicios();


		}
	}

	public function descargarPdf() {

		if(isset($_SESSION['id'])){

			$idSolicitudServicio = "";

			if(isset($_POST['idSolicitudServicio'])){
				$idSolicitudServicio = trim($_POST['idSolicitudServicio']);
			}

			//Obteniendo id_dependencia
			$id_dependencia = '';
			
			if(isset($_SESSION['id_dependencia'])){
				$id_dependencia = $_SESSION['id_dependencia'];
			}

			//Obteniendo ruta servidor
			$objAplicacion = $this->loadModel('aplicacion');
			$result = $objAplicacion->getRutasDependencia('015_001',$id_dependencia,'','',array());
			
			$rutaRepositorio='';

			while ($row = $result->fetch()){
			     $rutaRepositorio=$row['ruta']; 
			}



			

			$ruta=$rutaRepositorio.$idSolicitudServicio.".pdf";

			//echo $ruta;
			
			if(file_exists($ruta)){
				
				// The location of the PDF file 
				// on the server 
				$filename = $ruta; 
				  
				// Header content type 
				header("Content-type: application/pdf"); 
				  
				header("Content-Length: " . filesize($filename)); 
				header('Content-Disposition: inline; filename='.$idSolicitudServicio.'.pdf');
				// Send the file to the browser. 
				readfile($filename); 


			}else{
				echo "No se encontró pdf, comuniquese con el administrador.";
			}
				

			
		}
		else{
			$this->_view->renderizar('../index/login',true);//true para que aprezca sin encabezado
		}
	}

	public function descargarExcel() {

		if(isset($_SESSION['id'])){

			$idSolicitudServicio = "";

			if(isset($_POST['idSolicitudServicio'])){
				$idSolicitudServicio = trim($_POST['idSolicitudServicio']);
			}

			//Obteniendo id_dependencia
			$id_dependencia = '';
			
			if(isset($_SESSION['id_dependencia'])){
				$id_dependencia = $_SESSION['id_dependencia'];
			}

			//Obteniendo ruta servidor
			$objAplicacion = $this->loadModel('aplicacion');
			$result = $objAplicacion->getRutasDependencia('015_001',$id_dependencia,'','',array());
			
			$rutaRepositorio='';

			while ($row = $result->fetch()){
			     $rutaRepositorio=$row['ruta']; 
			}
			

			$ruta=$rutaRepositorio.$idSolicitudServicio.".xlsx";

			//echo $ruta;
			
			if(file_exists($ruta)){
				
				// The location of the PDF file 
				// on the server 
				$filename = $ruta; 
				  
				// Header content type 
				header("Content-type: application/vnd.ms-excel"); 
				  
				header("Content-Length: " . filesize($filename)); 
				header('Content-Disposition: inline; filename='.$idSolicitudServicio.'.xlsx');
				// Send the file to the browser. 
				readfile($filename); 


			}else{
				echo "No se encontró excel, comuniquese con el administrador.";
			}
				

			
		}
		else{
			$this->_view->renderizar('../index/login',true);//true para que aprezca sin encabezado
		}
	}



	
	public function getEstadisticos(){


	
			$objModel = $this->loadModel('solicitudServicio');
			$objModel->getEstadisticos();


			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);


	}

	
	
}




?>