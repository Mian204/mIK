<?php 

class aplicacionController extends Controller{
	
	public function __construct(){
		parent::__construct();
	}
	
	public function index(){
	}

	//LOGIN
	/*public function login2(){
		
		$username = '';
		$clave = '';
		$id_dependencia = '';
		$urlAnterior = '';


	    if(isset($_POST['username'])){
			$username = trim($_POST['username']);
		}
		if(isset($_POST['clave'])){
			$clave = trim($_POST['clave']);
		}
		if(isset($_POST['id_dependencia'])){
			$id_dependencia = trim($_POST['id_dependencia']);
		}
		if(isset($_POST['urlAnterior'])){
			$urlAnterior = trim($_POST['urlAnterior']);
		}

		if($urlAnterior==''){
			$urlAnterior = $_SERVER['REQUEST_URI'];	
			$urlAnterior = str_replace("aplicacion/login", "", $urlAnterior);
		}
		


		$objModelAplicacion = $this->loadModel('aplicacion');
		$result = $objModelAplicacion->validarCuenta($username,$id_dependencia);

		$id = '';
		$estado = '';
		$id_dependencia = '';
		$id_session = '';

		while ($row = $result->fetch())  {
		    $id = $row['id'];
		    $estado = $row['estado'];
		    $id_dependencia = $row['id_dependencia'];
		}


		if($estado=='01' and $objModelAplicacion->validarPassword($username,$clave)){

			$result = $objModelAplicacion->registrarSesion($username,$id_dependencia);

			$result->nextRowset();
			$result->nextRowset();
			$result->nextRowset();

			foreach ($result as $row) {	
				$id_session = $row['id_session'];
			}
		
            $_SESSION['id'] = $id;
			$_SESSION['id_dependencia'] = $id_dependencia;
			$_SESSION['id_session'] = $id_session;
			
			$this->redireccionar('..'.$urlAnterior);
			

		}
		else{
			unset($_SESSION['id']);
			$this->_view->tipoError = '1';
			$this->_view->urlAnterior = $urlAnterior;
			$this->_view->renderizar('../index/login',true);
		}	
	}*/
	public function login(){
		
		$username = '';
		$clave = '';
		$id_dependencia = '';
		$urlAnterior = '';


	    if(isset($_POST['username'])){
			$username = trim($_POST['username']);
		}
		if(isset($_POST['clave'])){
			$clave = trim($_POST['clave']);
		}
		if(isset($_POST['id_dependencia'])){
			$id_dependencia = trim($_POST['id_dependencia']);
		}
		if(isset($_POST['urlAnterior'])){
			$urlAnterior = trim($_POST['urlAnterior']);
		}

		if($urlAnterior==''){
			$urlAnterior = $_SERVER['REQUEST_URI'];	
			$urlAnterior = str_replace("aplicacion/login", "", $urlAnterior);
		}
		
		$modoPruebaPerfil=false;
		if (strtoupper(substr($username, 0, 7) ) == 'PRUEBA_' ) {
			$modoPruebaPerfil=true;
			$username=substr($username, 7);
		}

		$objModelAplicacion = $this->loadModel('aplicacion');
		$result = $objModelAplicacion->validarCuenta($username,$id_dependencia);

		$id = '';
		$estado = '';
		$id_dependencia = '';
		$id_session = '';

		while ($row = $result->fetch())  {
		    $id = $row['id'];
		    $estado = $row['estado'];
		    $id_dependencia = $row['id_dependencia'];
		}

		$validacionPassword=false;
		if ($modoPruebaPerfil==true){
			$validacionPassword=$objModelAplicacion->validarPassword(USUARIOPRUEBA,$clave);
		}else{
			$validacionPassword=$objModelAplicacion->validarPassword($username,$clave);
		}

		if ($id_dependencia =='') {
			$id_dependencia='002000';
		}

		if($estado=='01' and $validacionPassword==true){

			if ($modoPruebaPerfil==true){
				$result = $objModelAplicacion->registrarSesion(USUARIOPRUEBA,$id_dependencia);
			}else{
				$result = $objModelAplicacion->registrarSesion($username,$id_dependencia);
			}
			
			$result->nextRowset();
			$result->nextRowset();
			$result->nextRowset();

			foreach ($result as $row) {	
				$id_session = $row['id_session'];
			}

            $_SESSION['id'] = $id;
			$_SESSION['id_dependencia'] = $id_dependencia;
			$_SESSION['id_session'] = $id_session;
			
			$this->redireccionar('..'.$urlAnterior);
			
		}
		else{
			unset($_SESSION['id']);
			$this->_view->tipoError = '1';
			$this->_view->urlAnterior = $urlAnterior;
			$this->_view->renderizar('../index/login',true);
		}	
		
		
	}

	///////TABLAS PARAMETROS
	public function modulo(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('APLICACION/MODULO',true)){


				$id_modulo = '';
				$estado = '';
				$title = 'Consulta General de Modulos';
			    $shape = '1';

			    if(isset($_POST['id_modulo'])){
					$id_modulo = trim($_POST['id_modulo']);
				}
				if(isset($_POST['estado'])){
					$estado = trim($_POST['estado']);
				}
				
				
				$this->_view->id_modulo = $id_modulo;
				$this->_view->estado = $estado;
				$this->_view->title = $title;
				$this->_view->shape = $shape;
			
				
				$this->_view->setJs(array('modulo'));
				$this->_view->renderizar('modulo');

			}else{

				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');

			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function getModulos(){

		if(isset($_SESSION['id'])){
			
			$id_modulo = '';
			$estado = '';

		   	if(isset($_POST['id_modulo'])){
				$id_modulo = trim($_POST['id_modulo']);
			}
			
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}
			

			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getModulos($id_modulo,$estado);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}

	public function insModulo(){

		if(isset($_SESSION['id'])){
			
			$id_modulo = '';
			$descripcion = '';
			$estado = '';

			if(isset($_POST['id_modulo'])){
				$id_modulo = trim($_POST['id_modulo']);
			}
			if(isset($_POST['descripcion'])){
				$descripcion = trim($_POST['descripcion']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}


			$objModel = $this->loadModel('aplicacion');
			$objModel->insModulo($id_modulo,$descripcion,$estado);

	
			$_POST = array();
			$_POST['id_modulo']=$id_modulo;
			$this->getModulos();

		}
	}

	public function updModulo(){

		if(isset($_SESSION['id'])){

			$id_modulo = '';
			$descripcion = '';
			$estado = '';

			if(isset($_POST['id_modulo'])){
				$id_modulo = trim($_POST['id_modulo']);
			}
			if(isset($_POST['descripcion'])){
				$descripcion = trim($_POST['descripcion']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}

			$objModel = $this->loadModel('aplicacion');
			$objModel->updModulo($id_modulo,$descripcion,$estado);

			$_POST = array();
			$_POST['id_modulo']=$id_modulo;
			$this->getModulos();
			

		}
	}

	public function delModulo(){

		if(isset($_SESSION['id'])){

			$id_perfil = '';
		
			if(isset($_POST['id_modulo'])){
				$id_modulo = $_POST['id_modulo'];
			}

			$objModel = $this->loadModel('aplicacion');
			$objModel->delModulo($id_modulo);


			$_POST = array();
			$_POST['id_modulo']=$id_modulo;
			$this->getModulos();


		}
	}

	public function perfil(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('APLICACION/PERFIL',true)){

				$id_perfil = '';
				$id_usuario_actualiza = $_SESSION['id'];
				$estado = '';
				$idCuentaInd = '';
				$title = 'Consulta General de Perfiles';
			    $shape = '1';

			    if(isset($_POST['id_perfil'])){
					$id_perfil = trim($_POST['id_perfil']);
				}
				if(isset($_POST['estado'])){
					$estado = trim($_POST['estado']);
				}
				if(isset($_POST['idCuentaInd'])){
					$idCuentaInd = trim($_POST['idCuentaInd']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				
				
				$this->_view->id_perfil = $id_perfil;
				$this->_view->estado = $estado;
				$this->_view->idCuentaInd = $idCuentaInd;
				$this->_view->title = $title;
				$this->_view->shape = $shape;
			
				
				$this->_view->setJs(array('perfil'));
				$this->_view->renderizar('perfil');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function getPerfiles(){

		if(isset($_SESSION['id'])){
			
			$id_perfil = '';
			$estado = '';
			$idCuentaInd = '';

		   	if(isset($_POST['id_perfil'])){
				$id_perfil = trim($_POST['id_perfil']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}
			if(isset($_POST['idCuentaInd'])){
				$idCuentaInd = trim($_POST['idCuentaInd']);
			}
			

			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getPerfiles($id_perfil,$estado,$idCuentaInd);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}

	public function insPerfil(){

		if(isset($_SESSION['id'])){
			
			$id_perfil = '';
			$descripcion = '';
			$id_usuario_actualiza = $_SESSION['id'];
			$estado = '';

			if(isset($_POST['id_perfil'])){
				$id_perfil = trim($_POST['id_perfil']);
			}
			if(isset($_POST['descripcion'])){
				$descripcion = trim($_POST['descripcion']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}


			$objModel = $this->loadModel('aplicacion');
			$objModel->insPerfil($id_perfil,$descripcion,$id_usuario_actualiza,$estado);

	
			$_POST = array();
			$_POST['id_perfil']=$id_perfil;
			$this->getPerfiles();

		}
	}

	public function updPerfil(){

		if(isset($_SESSION['id'])){

			$id_perfil = '';
			$descripcion = '';
			$id_usuario_actualiza = $_SESSION['id'];
			$estado = '';

			if(isset($_POST['id_perfil'])){
				$id_perfil = trim($_POST['id_perfil']);
			}
			if(isset($_POST['descripcion'])){
				$descripcion = trim($_POST['descripcion']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}

			$objModel = $this->loadModel('aplicacion');
			$objModel->updPerfil($id_perfil,$descripcion,$id_usuario_actualiza,$estado);

			$_POST = array();
			$_POST['id_perfil']=$id_perfil;
			$this->getPerfiles();
			

		}
	}

	public function delPerfil(){

		if(isset($_SESSION['id'])){

			$id_perfil = '';
		
			if(isset($_POST['id_perfil'])){
				$id_perfil = $_POST['id_perfil'];
			}

			$objModel = $this->loadModel('aplicacion');
			$objModel->delPerfil($id_perfil);


			$_POST = array();
			$_POST['id_perfil']=$id_perfil;
			$this->getPerfiles();


		}
	}

	public function vinPerfil(){

		if(isset($_SESSION['id'])){

			$id_perfil = '';
			$id_cuenta = '';

			if(isset($_POST['id_perfil3'])){
				$id_perfil = trim($_POST['id_perfil3']);
			}
			if(isset($_POST['id_cuenta3'])){
				$id_cuenta = trim($_POST['id_cuenta3']);
			}
			
			$objModel = $this->loadModel('aplicacion');
			$objModel->vinPerfil($id_perfil,$id_cuenta);

			$_POST = array();
			$_POST['id_perfil']=$id_perfil;
			$_POST['idCuentaInd']=$id_cuenta;
			$this->getPerfiles();
			

		}
	}

	public function vinMasPerfil(){ // Modulo Cuenta

		if(isset($_SESSION['id'])){

			$idArray = array();
			$id_dependencia = '';
			$id_perfil = '';

			$id_cuenta = '';

			$id_cuentaArray = array();

			if(isset($_POST['idArray3'])){
				$idArray = $_POST['idArray3'];
			}
			if(isset($_POST['id_dependencia3'])){
				$id_dependencia = trim($_POST['id_dependencia3']);
			}
			if(isset($_POST['id_perfil3'])){
				$id_perfil = trim($_POST['id_perfil3']);
			}	

			$objModel = $this->loadModel('aplicacion');

			if (count($idArray)>0){
				foreach($idArray as $item)
		 		{
		 			$id = $item;
		 			$id_cuenta = $id.$id_dependencia;

		 			if (strlen($id_cuenta)==10 and strlen($id_perfil)==7){
		 				
		 				$objModel->desPerfil($id_perfil,$id_cuenta);
						$objModel->vinPerfil($id_perfil,$id_cuenta);

						array_push($id_cuentaArray, $id.$id_dependencia);
		 			}
		 		}
			}
			

			$_POST = array();
			$_POST['id_cuenta']='*';
			$_POST['id_cuentaArray']=$id_cuentaArray;
			$this->getCuentas();

		}
	}

	public function desPerfil(){

		if(isset($_SESSION['id'])){

			$id_perfil = '';
			$id_cuenta = '';
			
			if(isset($_POST['id_perfil3'])){
				$id_perfil = trim($_POST['id_perfil3']);
			}
			if(isset($_POST['id_cuenta3'])){
				$id_cuenta = trim($_POST['id_cuenta3']);
			}
			

			$objModel = $this->loadModel('aplicacion');
			$objModel->desPerfil($id_perfil,$id_cuenta);

			$_POST = array();
			$_POST['id_perfil']=$id_perfil;
			$_POST['idCuentaInd']=$id_cuenta;
			$this->getPerfiles();
			

		}
	}

	public function cuenta(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('APLICACION/CUENTA',true)){

				$id_cuenta = '';
				$id_cuentaArray = array();
				$id_usuario = '';
				$id_dependencia = '';
				$estado = '';
				$title = 'Consulta General de Cuentas';
			    $shape = '1';

			    if(isset($_POST['id_cuenta'])){
					$id_cuenta = trim($_POST['id_cuenta']);
				}
				if(isset($_POST['id_cuentaArray'])){
					$id_cuentaArray = $_POST['id_cuentaArray'];
				}
				if(isset($_POST['id_usuario'])){
					$id_usuario = trim($_POST['id_usuario']);
				}
				if(isset($_POST['id_dependencia'])){
					$id_dependencia = trim($_POST['id_dependencia']);
				}
				if(isset($_POST['estado'])){
					$estado = trim($_POST['estado']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				
				$this->_view->id_cuenta = $id_cuenta;
				$this->_view->id_cuentaArray = $id_cuentaArray;
				$this->_view->id_usuario = $id_usuario;
				$this->_view->id_dependencia = $id_dependencia;
				$this->_view->estado = $estado;
				$this->_view->title = $title;
				$this->_view->shape = $shape;
			
				
				$this->_view->setJs(array('cuenta'));
				$this->_view->renderizar('cuenta');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}
		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function getCuentas(){

		if(isset($_SESSION['id'])){
			
			$id_cuenta = '';
			$id_cuentaArray = array();
			$id_usuario = '';
			$id_dependencia = '';
			$estado = '';

		   	if(isset($_POST['id_cuenta'])){
				$id_cuenta = trim($_POST['id_cuenta']);
			}
			if(isset($_POST['id_cuentaArray'])){
				$id_cuentaArray = $_POST['id_cuentaArray'];
			}
			if(isset($_POST['id_usuario'])){
				$id_usuario = trim($_POST['id_usuario']);
			}
			if(isset($_POST['id_dependencia'])){
				$id_dependencia = trim($_POST['id_dependencia']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}
			

			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getCuentas($id_cuenta,$id_cuentaArray,$id_usuario,$id_dependencia,$estado);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}

	public function insCuenta(){

		if(isset($_SESSION['id'])){
			
			$id_usuario = '';
			$id_dependencia = '';
			$estado = '';

			if(isset($_POST['id_usuario'])){
				$id_usuario = trim($_POST['id_usuario']);
			}
			if(isset($_POST['id_dependencia'])){
				$id_dependencia = trim($_POST['id_dependencia']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}


			$objModel = $this->loadModel('aplicacion');
			$objModel->insCuenta($id_usuario,$id_dependencia,$estado);

			$id_cuenta = $id_usuario.$id_usuario;

			$_POST = array();
			$_POST['id_cuenta']=$id_cuenta;
			$this->getCuentas();

		}
	}

	public function insMasCuenta(){

		if(isset($_SESSION['id'])){

			$idArray = array();
			$id_dependencia = '';

			$id_cuentaArray = array();

			$id_cuentaBase = '';
			$id_usuarioBase = '';
			$id_dependenciaBase = '';

			if(isset($_POST['idArray2'])){
				$idArray = $_POST['idArray2'];
			}
			if(isset($_POST['id_dependencia2'])){
				$id_dependencia = trim($_POST['id_dependencia2']);
			}	

			$objModel = $this->loadModel('aplicacion');
			
			if (count($idArray)>0){
				foreach($idArray as $item)
		 		{
		 			
		 			$id = $item;

		 			if (strlen($id)==4 and strlen($id_dependencia)==6){

						$result = $objModel->getCuentas($id.$id_dependencia,array(),'','','');

						while ($row = $result->fetch())  {
						    $id_cuentaBase = $row['id'];
							$id_usuarioBase = $row['id_usuario'];
							$id_dependenciaBase = $row['id_dependencia'];
						}

						if ($id_cuentaBase == ($id.$id_dependencia) ){
							$objModel->updCuenta($id_cuentaBase,$id_usuarioBase,$id_dependenciaBase,'01');
						}else{
							$objModel->insCuenta($id,$id_dependencia,'01');
						}

						array_push($id_cuentaArray, $id.$id_dependencia);
					}
					
		 		}
			}
			

			$_POST = array();
			$_POST['id_cuenta']='*';
			$_POST['id_cuentaArray']=$id_cuentaArray;
			$this->getCuentas();

		}
	}

	public function updCuenta(){

		if(isset($_SESSION['id'])){

			$id_cuenta = '';
			$id_usuario = '';
			$id_dependencia = '';
			$estado = '';

		   	if(isset($_POST['id_cuenta'])){
				$id_cuenta = trim($_POST['id_cuenta']);
			}
			if(isset($_POST['id_usuario'])){
				$id_usuario = trim($_POST['id_usuario']);
			}
			if(isset($_POST['id_dependencia'])){
				$id_dependencia = trim($_POST['id_dependencia']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}


			$objModel = $this->loadModel('aplicacion');
			$objModel->updCuenta($id_cuenta,$id_usuario,$id_dependencia,$estado);

			$id_cuenta=$id_usuario.$id_dependencia;

			$_POST = array();
			$_POST['id_cuenta']=$id_cuenta;
			$this->getCuentas();
			

		}
	}

	public function delCuenta(){

		if(isset($_SESSION['id'])){

			$id_cuenta = '';
		
			if(isset($_POST['id_cuenta'])){
				$id_cuenta = $_POST['id_cuenta'];
			}

			$objModel = $this->loadModel('aplicacion');
			$objModel->delCuenta($id_cuenta);


			$_POST = array();
			$_POST['id_cuenta']=$id_cuenta;
			$_POST['estado']='00';
			$this->getCuentas();


		}
	}

	public function opcion(){

		if(isset($_SESSION['id'])){

			$objLayout = $this->loadModel('layout');
			$objLayout->instanciarUsuario($_SESSION['id'],$_SESSION['id_dependencia']);
			$this->_view->layout = $objLayout;

			if ($objLayout->validarAccesoOpcion('APLICACION/OPCION',true)){

				$id_opcion = '';
				$id_modulo = '';
				$estado = '';
				$idPerfilInd = '';
				$title = 'Consulta General de Opciones';
			    $shape = '1';

			    if(isset($_POST['id_opcion'])){
					$id_opcion = trim($_POST['id_opcion']);
				}
				if(isset($_POST['id_modulo'])){
					$id_modulo = trim($_POST['id_modulo']);
				}
				if(isset($_POST['estado'])){
					$estado = trim($_POST['estado']);
				}
				if(isset($_POST['idPerfilInd'])){
					$idPerfilInd = trim($_POST['idPerfilInd']);
				}
				if(isset($_POST['shape'])){
					$shape = trim($_POST['shape']);
				}
				if(isset($_POST['title'])){
					$title = trim($_POST['title']);
				}
				
				$this->_view->id_opcion = $id_opcion;
				$this->_view->id_modulo = $id_modulo;
				$this->_view->estado = $estado;
				$this->_view->idPerfilInd = $idPerfilInd;
				$this->_view->title = $title;
				$this->_view->shape = $shape;
			
				
				$this->_view->setJs(array('opcion'));
				$this->_view->renderizar('opcion');

			}else{
				$this->_view->shape = '1';
				$this->_view->title = 'Sin Acceso';
				$this->_view->setJs(array('../../index/js/sinAcceso'));
				$this->_view->renderizar('../index/sinAcceso');
			}

		}
		else{
			$this->_view->urlAnterior = $_SERVER['REQUEST_URI'];
			$this->_view->tipoError = '2';
			$this->_view->renderizar('../index/login',true);
		}
	}

	public function getOpciones(){

		if(isset($_SESSION['id'])){
			
			$id_opcion = '';
			$id_modulo = '';
			$estado = '';
			$idPerfilInd = '';

		   	if(isset($_POST['id_opcion'])){
				$id_opcion = trim($_POST['id_opcion']);
			}
			if(isset($_POST['id_modulo'])){
				$id_modulo = trim($_POST['id_modulo']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}
			if(isset($_POST['idPerfilInd'])){
				$idPerfilInd = trim($_POST['idPerfilInd']);
			}
			

			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getOpciones($id_opcion,$id_modulo,$estado,$idPerfilInd);


			$arreglo['data'] = array();

			while ($row = $result->fetch())  {
			    $arreglo['data'][] = $row;
			}

			echo json_encode($arreglo);
		}
	}

	public function insOpcion(){

		if(isset($_SESSION['id'])){
			
			$id_opcion = '';
			$opcion = '';
			$id_modulo = '';
			$observacion = '';
			$estado = '';

			if(isset($_POST['id_opcion'])){
				$id_opcion = trim($_POST['id_opcion']);
			}
			if(isset($_POST['opcion'])){
				$opcion = trim($_POST['opcion']);
			}
			if(isset($_POST['id_modulo'])){
				$id_modulo = trim($_POST['id_modulo']);
			}
			if(isset($_POST['observacion'])){
				$observacion = trim($_POST['observacion']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}


			$objModel = $this->loadModel('aplicacion');
			$objModel->insOpcion($id_opcion,$opcion,$id_modulo,$observacion,$estado);

	
			$_POST = array();
			$_POST['id_opcion']=$id_opcion;
			$this->getOpciones();

		}
	}

	public function updOpcion(){

		if(isset($_SESSION['id'])){

			$id_opcion = '';
			$opcion = '';
			$id_modulo = '';
			$observacion = '';
			$estado = '';

			if(isset($_POST['id_opcion'])){
				$id_opcion = trim($_POST['id_opcion']);
			}
			if(isset($_POST['opcion'])){
				$opcion = trim($_POST['opcion']);
			}
			if(isset($_POST['id_modulo'])){
				$id_modulo = trim($_POST['id_modulo']);
			}
			if(isset($_POST['observacion'])){
				$observacion = trim($_POST['observacion']);
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}

			$objModel = $this->loadModel('aplicacion');
			$objModel->updOpcion($id_opcion,$opcion,$id_modulo,$observacion,$estado);

			$_POST = array();
			$_POST['id_opcion']=$id_opcion;
			$this->getOpciones();
			

		}
	}

	public function delOpcion(){

		if(isset($_SESSION['id'])){

			$id_opcion = '';
		
			if(isset($_POST['id_opcion'])){
				$id_opcion = $_POST['id_opcion'];
			}

			$objModel = $this->loadModel('aplicacion');
			$objModel->delOpcion($id_opcion);


			$_POST = array();
			$_POST['id_opcion']=$id_opcion;
			$this->getOpciones();


		}
	}

	public function vinOpcion(){

		if(isset($_SESSION['id'])){

			$id_opcion = '';
			$id_perfil = '';

			if(isset($_POST['id_opcion3'])){
				$id_opcion = trim($_POST['id_opcion3']);
			}
			if(isset($_POST['id_perfil3'])){
				$id_perfil = trim($_POST['id_perfil3']);
			}


			$objModel = $this->loadModel('aplicacion');
			$objModel->vinOpcion($id_opcion,$id_perfil);

			$_POST = array();
			$_POST['id_opcion']=$id_opcion;
			$_POST['idPerfilInd']=$id_perfil;
			$this->getOpciones();
			

		}
	}

	public function desOpcion(){

		if(isset($_SESSION['id'])){

			$id_opcion = '';
			$id_perfil = '';

			if(isset($_POST['id_opcion3'])){
				$id_opcion = trim($_POST['id_opcion3']);
			}
			if(isset($_POST['id_perfil3'])){
				$id_perfil = trim($_POST['id_perfil3']);
			}
			

			$objModel = $this->loadModel('aplicacion');
			$objModel->desOpcion($id_opcion,$id_perfil);

			$_POST = array();
			$_POST['id_opcion']=$id_opcion;
			$_POST['idPerfilInd']=$id_perfil;
			$this->getOpciones();
			

		}
	}

	public function getDependencias(){

		$id_dependencia = '';
		$id_dependenciaArray = array();
		$term = '';
		$estado = '';
		$estadoArray = array();


		if(isset($_POST['id_dependencia'])){
			$id_dependencia = trim($_POST['id_dependencia']);
		}
		if(isset($_POST['id_dependenciaArray'])){
			$id_dependenciaArray = $_POST['id_dependenciaArray'];
		}
		if(isset($_POST['term'])){
			$term = trim($_POST['term']);
		}
		if(isset($_POST['estado'])){
			$estado = trim($_POST['estado']);
		}
		if(isset($_POST['estadoArray'])){
			$estadoArray = $_POST['estadoArray'];
		}
		if($estado==''){
			$estado = '*';
			array_push($estadoArray, '01');
		}
						
		$objModel = $this->loadModel('aplicacion');
		$result = $objModel->getDependencias($id_dependencia,$id_dependenciaArray,$term,$estado,$estadoArray);


		$arreglo["data"] = array();

		while ($row = $result->fetch())  {
		    $arreglo["data"][] = $row;
		}

		echo json_encode($arreglo);
	}

	public function getAreas(){

		if(isset($_SESSION['id'])){

			$id_area = '';
			$id_areaArray = array();
			$term = '';
			$id_dependencia = '';
			$id_dependenciaArray = array();
			$estado = '';
			$estadoArray = array();

			if(isset($_POST['id_area'])){
				$id_area = trim($_POST['id_area']);
			}
			if(isset($_POST['id_areaArray'])){
				$id_areaArray = $_POST['id_areaArray'];
			}
			if(isset($_POST['term'])){
				$term = trim($_POST['term']);
			}
			if(isset($_POST['id_dependencia'])){
				$id_dependencia = trim($_POST['id_dependencia']);
			}
			if(isset($_POST['id_dependenciaArray'])){
				$id_dependenciaArray = $_POST['id_dependenciaArray'];
			}
			if(isset($_POST['estado'])){
				$estado = trim($_POST['estado']);
			}
			if(isset($_POST['estadoArray'])){
				$estadoArray = $_POST['estadoArray'];
			}
			if($estado==''){
				$estado = '*';
				array_push($estadoArray, '01');
			}
						
			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getAreas($id_area,$id_areaArray,$term,$id_dependencia,$id_dependenciaArray,$estado,$estadoArray);


			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		}
	}



	

	public function getNotificaciones(){

		$objModel = $this->loadModel('aplicacion');
		$objModel->setId_Usuario($_SESSION['id']);
		$objModel->setId_Dependencia($_SESSION['id_dependencia']);

		$result = $objModel->getNotificaciones();
		$cadena_html="";
		while($row=$result->fetch()){
			$cadena_html.="
			
				<a class='list-group-item' id=".$row['id_notificacion_usuario']." >
			        <div class='media' >
			            <!--<div class='media-img'>
			                <span class='badge badge-success badge-big'><i class='fa fa-check'></i></span>
			            </div>-->
			            <div class='media-body'>
			                <div class='font-13'>".$row['titulo']."</div>
			                <!--<small class='text-muted'>22 mins</small>-->
			            </div>
			        </div>
			    </a>
			
			";
		}

		$cadena_html.="";

		
		echo $cadena_html;	
	}
	
	public function getAreasDependencia(){

		if(isset($_SESSION['id'])){

			$idDependencia = $_SESSION['id_dependencia'];

			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getAreasDependencia($idDependencia);


			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		}
		else{
			$this->_view->renderizar('login',true);//true para que aprezca sin encabezado
		}
	}

	public function getAreasSubordinadas(){

		if(isset($_SESSION['id'])){

			$idArea=$_SESSION['id_area'];
			
			
			if(substr($idArea, -4) =='0000'){
				$idArea=substr($idArea, 0, 2).'%';
			}

			if(substr($idArea, -3) =='000'){
				$idArea=substr($idArea, 0, 3).'%';
			}

			if(substr($idArea, -2) =='00'){
				$idArea=substr($idArea, 0, 4).'%';
			}

			if(substr($idArea, -1) =='0'){
				$idArea=substr($idArea, 0, 5).'%';
			}


			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getAreasSubordinadas($idArea);


			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		}
	}

	public function getAreaCombo(){

		if(isset($_SESSION['id'])){

			$id_desc="";

			if(isset($_POST['term'])){
				$id_desc = trim($_POST['term']);
			}		
						
			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getAreaCombo($id_desc);


			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		}		
	}

	public function getUsuarioSelect2(){

		if(isset($_SESSION['id'])){

			$reg_nombres="";

			if(isset($_POST['term'])){
				$reg_nombres = trim($_POST['term']);
			}		
						
			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getUsuarioSelect2($reg_nombres);


			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		}
	}

	public function getUsuariosSubordinados(){

		if(isset($_SESSION['id'])){

			$idUsuarioSession=$_SESSION['id'];

			$indIncluirJefe=true;

			if(isset($_POST['indIncluirJefe'])){
				$indIncluirJefe = $_POST['indIncluirJefe'];
			}		
									
			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getUsuariosSubordinados($idUsuarioSession,$indIncluirJefe);

			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		}		
	}

	public function getUsuarioSession(){

		if(isset($_SESSION['id'])){

			$idUsuario=$_SESSION['id'];
		
						
			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getUsuario($idUsuario);


			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		
		}
	}

	public function getJefeUsuario(){

		if(isset($_SESSION['id'])){

			$idUsuario='';
			//$idUsuario=$_SESSION['id'];

			if(isset($_POST['idUsuario'])){
				$idUsuario = trim($_POST['idUsuario']);
			}	
						
			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getJefeUsuario($idUsuario);


			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		
		}
	}
	
	public function getJefeUsuarioSession(){

		if(isset($_SESSION['id'])){

			$idUsuarioSession=$_SESSION['id'];
				
						
			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getJefeUsuario($idUsuarioSession);


			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);
	
		}
	}


	public function getSupervisor($id_area){
	
		$objModel = $this->loadModel('aplicacion');
		$result = $objModel->getSupervisor($id_area);

		$arreglo["data"] = array();

		while ($row = $result->fetch()){
		    $arreglo["data"][] = $row;
		}

		echo json_encode($arreglo);
	}

	





	public function getFeriados(){

		if(isset($_SESSION['id'])){
			
			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getFeriados();

			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		}
		
	}


	public function isLogger(){
		if(isset($_SESSION['id'])){
			echo '1';
		}else{
			unset($_SESSION['id']);
			echo '0';
		}
		
	}

	public function logout(){
		unset($_SESSION['id']);
		$this->redireccionar('');
	}


	public function pruebaCorreo(){
		//enviar correo
		$this->getLibrary ( 'phpmailer/class.phpmailer' );
		$this->getLibrary ( 'phpmailer/class.smtp' );

		$mail = new PHPMailer ();

		$aplicacionModel = $this->loadModel('aplicacion');
		$mail = $aplicacionModel->configurarObjetoMailer($mail);

		$mail->Subject = "Prueba Correo";

		$mail->addAddress('vchacaliazad@sunat.gob.pe');

		$cadena_html = "<!DOCTYPE html>
		<html>
		<head>
			<meta http-equiv='Content-Type' content='text/html; charset=UTF-8' />

			<style>
				body {margin: 10px 10px 10px 10px;background-color:#E6E6E6;}
				</style>
			</head>

		<body>
			<div>
				<center>
					<table WIDTH='500' border='0' cellspacing='0' cellpadding='0' style='margin-bottom: auto;margin-top: auto;margin-right: auto;margin-left: auto;'>
						<tbody>
							Prueba
						</tbody>
					</table>
				</center>
			</div>
		</body>
		</html>";

		$mail->Body = $cadena_html ;
		
		//$mail->AddAddress ( 'vchacaliazad@sunat.gob.pe');
		//$mail->AddAttachment ( '/var/www/html/framephp/temp/Reporte.xlsx', '' );
		
		//$mail->IsHTML ( true );
		if (!$mail->Send())
		{
			echo "Error: " . $mail->ErrorInfo;
		}else{
			echo "Mensaje enviado correctamente";
		}
		
		$mail->ClearAddresses ();
	}


	public function getParametros(){

			$codigo = $_POST['codigo'];

			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getParametros($codigo);


			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

	}

	public function getIdParametros(){

			$codigo = $_POST['codigo'];
			$argumento = $_POST['argumento'];

			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getIdParametros($codigo,$argumento);


			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

	}

	
	
	/*public function getFeriados(){

		if(isset($_SESSION['id'])){

			
						
			$objModel = $this->loadModel('aplicacion');
			$result = $objModel->getFeriados();


			$arreglo["data"] = array();

			while ($row = $result->fetch())  {
			    $arreglo["data"][] = $row;
			}

			echo json_encode($arreglo);

		}
		else{
			$this->_view->renderizar('login',true);//true para que aprezca sin encabezado
		}
	}*/
}
?>