
$(document).ready(function () {

    inicializarModulo();

    //Modal Sel
    $("#mostrarModalSel").on("click", function(){

        limpiarModalCrud();
        
        $('#tituloCrud').text('Consulta DNI');
        //$("#btnAceptCrud").attr('accion','sel');
        $("#btnAceptCrud").text('Buscar');
        $("#btnCancelCrud").show();

        $('#formSel *').prop('disabled', false);
        $('#btnAceptCrud').prop('disabled', false);

        $("#formSel div.form-group").hide();
        $("#dniDiv").show();
        $("#num_docide_pnat").prop('disabled', false);
        
        
        $("#num_docide_pnat").focus();

        $('#btnAceptCrud').attr('class','btn btn-primary');

        $('#modalCrud').modal('show');


        //Obtener Datos DNI
        getDni();
    }); 
    





    //Modal Ins
    /*$("#mostrarModalIns").on("click", function(){
        
        limpiarModalCrud();

        $('#tituloCrud').text('Nuevo Registro');
        $("#btnAceptCrud").attr('accion','ins');
        $("#btnAceptCrud").text('Registrar');
        $("#btnCancelCrud").show();

        $('#formSel *').prop('disabled', false);
        $('#btnAceptCrud').prop('disabled', false);

        $("#formSel div.form-group").show();
        $("#idCompromisoDiv").hide();
        $("#idCompromiso").prop('disabled', false);
        $("#rcDiv").show();
        $("#recDiv").show();
        $("#rucDiv").show();
       
        $("#codTerceroDiv").show(); 
        $("#fecPagoPropuestoDiv").show(); 
        $("#fecPagoPropuestoRangoDiv").hide();        
        $("#cantidadPagoPropuesto").show();
        $("#formaPagoPropuestoDiv").show();
        $("#dniEncargadoTerceroDiv").show(); 
        $("#nombreEncargadoTerceroDiv").show(); 
        $("#observacionDiv").show(); 


        $("#fecRegRangoDiv").hide();
        $("#fecRegDiv").hide();
        $("#usuRegDiv").hide();
        $("#estadoDiv").show();



        $("#idCompromiso").focus();
        
        //$("#fecRegDiv .input-group.date").datepicker().datepicker("setDate", moment(new Date()).format('DD/MM/YYYY'));
        //$("#fecReg").val(moment(new Date()).format('DD/MM/YYYY'));
       

        $('#btnAceptCrud').attr('class','btn btn-primary');         

        $('#modalCrud').modal('show');
    });*/       

    $("#mostrarModalSel").trigger('click'); 
    
});



//function que obtiene datos, con condicion para consultar auto al ingresar 8 digitos
function getDni() {
  var can = ($("#num_docide_pnat").val().length);
  if(can == 8){
        var frm = $("#formSel").serialize();
        $('#formSel *').prop('disabled', false);
        $('#formSel *').prop('disabled', true);           
        $('#modalCrud').modal('hide');
        $("#btnAceptCrud").prop("disabled", true);

             $.ajax({
                method:"POST",
                url: "./getDatosDni",
                data: frm,
                success :function(data) {
                    var jsonData = JSON.parse(data);
                    for (var i = 0; i < jsonData.data.length; i++) {
                    $('#load').hide();
                    var row = jsonData.data[i];
                    $("#datosper").text(row.des_nombre_pnat +' '+ row.des_apepat_pnat + ' '+ row.des_apemat_pnat);
                    $("#DocIde").html(row.num_docide_pnat);
                    $("#Fechanac").html(row.fec_nac_pnat);
                    $("#estado").html(row.des_estciv_pnat);
                    $("#Direcc").html(row.des_domici_pnat);
                    $("#edad").html(row.edad);
                    $("#distrito").html(row.distrito);
                    $("#genero").html(row.des_sexo_pnat);
                    $("#provincia").html(row.provincia);
                    } 
                    var genero = row.des_sexo_pnat;
                    if(genero  == 'F'){
                        $("#imgUser").attr("src","../public/imagenes/userowomen.gif");
                    }else{
                        $("#imgUser").attr("src","../public/imagenes/usermen.gif");
                    }
                    //$('#FormaDatosPers').show();
                    document.getElementById("FormaDatosPers").style.display = "block";
                    // Alerta Dinamica
                    AlertaExito();
          
                },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Comunicarse con el administrador.");
                    }
            });
    }
  
} 



function limpiarModalCrud(){

    $("#formSel")[0].reset();
}
   
function AlertaExito(){
    const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            })
    Toast.fire({
    icon: 'success',
    title: 'Consulta con exito'
    })

}

function inicializarModulo(){
  
    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());
    //$('#FormaDatosPers').hide();
    $("#imgUser").attr("src","../public/imagenes/load.gif");
    if($('#shape').val()=='1'){}

    setInterval(timer, 10000);
  
}

