$(document).ready(function () {

    inicializarModulo();
    
    var frmSelBkp = null;

    //Modal Sel
    $("#mostrarModalSel").on("click", function(){

        limpiarModalCrud();

        $('#tituloModalCrud').text('Seleccionar');
        $("#btnAceptModalCrud").attr('accion','sel');
        $("#btnAceptModalCrud").text('Buscar');
        $("#btnCancelModalCrud").show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $("#formCrud div.form-group").hide();
        $("#idCompromisoDiv").show();
        $("#idCompromiso").prop('disabled', false);
        $("#rucTerceroDiv").show();
        $("#fechaVencimientoCuotaDiv").hide();
        $("#fechaVencimientoCuotaRangoDiv").show();
        $("#mtoCuotaDiv").hide();
        $("#mtoCuotaRangoDiv").show();
        $("#saldoMtoEmbDiv").hide();
        $("#saldoMtoEmbRangoDiv").hide();               
        
        $("#idCompromiso").focus();

        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }

        $('#modalCrud').modal('show');
    }); 
    
    //Modal Ins
    /*$("#mostrarModalIns").on("click", function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Nuevo Registro');
        $("#btnAceptModalCrud").attr('accion','ins');
        $("#btnAceptModalCrud").text('Registrar');
        $("#btnCancelModalCrud").show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $("#formCrud div.form-group").show();
        $("#idCompromisoDiv").hide();
        $("#idCompromiso").prop('disabled', false);
        $("#rcDiv").show();
        $("#recDiv").show();
        $("#rucDiv").show();
       
        $("#codTerceroDiv").show(); 
        $("#fecPagoPropuestoDiv").show(); 
        $("#fecPagoPropuestoRangoDiv").hide();        
        $("#cantidadPagoPropuesto").show();
        $("#formaPagoPropuestoDiv").show();
        $("#dniEncargadoTerceroDiv").show(); 
        $("#nombreEncargadoTerceroDiv").show(); 
        $("#observacionDiv").show(); 


        $("#fecRegRangoDiv").hide();
        $("#fecRegDiv").hide();
        $("#usuRegDiv").hide();
        $("#estadoDiv").show();



        $("#idCompromiso").focus();
        
        //$("#fecRegDiv .input-group.date").datepicker().datepicker("setDate", moment(new Date()).format('DD/MM/YYYY'));
        //$("#fecReg").val(moment(new Date()).format('DD/MM/YYYY'));
       

        $('#btnAceptModalCrud').attr('class','btn btn-primary');         

        $('#modalCrud').modal('show');
    });*/       

    //btnAceptModalCrud
    $("#btnAceptModalCrud").on("click", function(){



        if ($(this).attr('accion')=='sel'){

            if (true){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();
                $('#formCrud *').prop('disabled', true);

                $("#btnAceptModalCrud").prop("disabled", true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 100,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[3,"desc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getCuotas",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    

                    "columns":
                    [
                        {"data":"rucTerceroDesc"},
                        {"data":"idCompromiso"},
                        {"data":"nroCuota"},
                        {"data":"fechaVencimientoCuota"},
                        {"data":"mtoCuota"},
                        {"data":"saldoMtoEmb"},                        
                        {"data":"mtoPago"},
                        

                        {"data": "estadoPago","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                    
                            if(sData=='Pendiente'){                                 
                                $(nTd).css('color', '#FF9999');
                            }else  if(sData=='Pagado'){                                 
                                $(nTd).css('color', '#99FF99');
                            };
                                                        
                        }} 


                    ]

                
                 


                });
             
                
                if($('#shape').val()=='1'){
                    //Consulta General
                    table.column(2).visible(false);
                    table.column(5).visible(false);
                    table.order([[3,'desc']]); 

                    
                }
                if($('#shape').val()=='2'){
                    //Consulta de Cuotas por idCompromiso
                    table.column(2).visible(true);
                    table.column(5).visible(true);
                    table.order([[2,'asc']]); 
                }
                if($('#shape').val()=='3'){
                    //Consulta de Cuotas por tercero
                    table.column(2).visible(false);
                    table.column(5).visible(false);
                    table.order([[3,'desc']]); 
                }

                if ($('#shape').val()=='1' || $('#shape').val()=='2' || $('#shape').val()=='3'){
                    var buttons = new $.fn.dataTable.Buttons(table, {
                        buttons: [
                           { 
                                extend: 'excel', 
                                text: 'Descargar Excel', 
                                className:'buttonDataTable', 
                                type:'button'
                            }
                        ]
                    }).container().appendTo($('#buttonModule'));

                    $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");
                }

                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                    
                   
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Información');
                    $("#btnAceptModalCrud").attr('accion','get');
                    $("#btnAceptModalCrud").text('Aceptar');
                    $("#btnCancelModalCrud").hide();

                  

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);



                    $("#formCrud div.form-group").show();
                    $("#idCompromisoDiv").show();
                    $("#idCompromiso").prop('disabled', true);
                    $("#rcDiv").show();
                    $("#recDiv").show();
                    $("#rucDiv").show();
                    
                    $("#codTerceroDiv").show(); 
                    $("#fecPagoPropuestoDiv").show(); 
                    $("#fecPagoPropuestoRangoDiv").hide();        
                    $("#cantidadPagoPropuesto").show();
                    $("#formaPagoPropuestoDiv").show();
                    $("#dniEncargadoTerceroDiv").show(); 
                    $("#nombreEncargadoTerceroDiv").show(); 
                    $("#observacionDiv").show(); 


                    $("#fecRegRangoDiv").hide();
                    $("#fecRegDiv").show();
                    $("#usuRegDiv").show();
                    $("#estadoDiv").show();




                    $("#idCompromiso").focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr("idCompromiso"));     

                    $('#modalCrud').modal('show');

                    // $("#idUsuario").change();
                    // $("#horasOcupadas").keyup();
                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){
                     
                    $('#tituloModalCrud').text('Modificar');
                    $("#btnAceptModalCrud").attr('accion','upd');
                    $("#btnAceptModalCrud").text('Guardar');
                    $("#btnCancelModalCrud").show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $("#formCrud div.form-group").show();
                    $("#idCompromisoDiv").show();
                    $("#idCompromiso").prop('disabled', true);
                    $("#rcDiv").show();
                    $("#recDiv").show();
                    $("#rucDiv").show();
                    

                    $("#codTerceroDiv").show(); 
                    $("#fecPagoPropuestoDiv").show(); 
                    $("#fecPagoPropuestoRangoDiv").hide();        
                    $("#formaPagoPropuestoDiv").show();
                    $("#cantidadPagoPropuesto").show();
                    $("#dniEncargadoTerceroDiv").show(); 
                    $("#nombreEncargadoTerceroDiv").show(); 
                    $("#observacionDiv").show(); 

                    $("#fecRegRangoDiv").hide();
                    $("#fecRegDiv").hide();
                    $("#usuRegDiv").hide();
                    $("#estadoDiv").show();

                    $("#rcDiv").focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr("idCompromiso"));

                    $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Eliminar');       
                    $("#btnAceptModalCrud").attr('accion','del');
                    $("#btnAceptModalCrud").text('Eliminar');
                    $("#btnCancelModalCrud").show();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);
                    
                    $("#formCrud div.form-group").show();
                    $("#idCompromisoDiv").show();
                    $("#idCompromiso").prop('disabled', true);
                    $("#rcDiv").show();
                    $("#recDiv").show();
                    $("#rucDiv").show();

                    $("#codTerceroDiv").hide(); 
                    $("#fecPagoPropuestoDiv").hide(); 
                    $("#fecPagoPropuestoRangoDiv").hide();        
                    $("#formaPagoPropuestoDiv").hide();
                    $("#cantidadPagoPropuesto").hide();
                    $("#dniEncargadoTerceroDiv").hide(); 
                    $("#nombreEncargadoTerceroDiv").hide(); 
                    $("#observacionDiv").hide(); 

                    $("#fecRegRangoDiv").hide();
                    $("#fecRegDiv").hide();
                    $("#usuRegDiv").hide();
                    $("#estadoDiv").hide();

                    $("#rcDiv").focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-danger');

                    get($(this).attr("idCompromiso"));

                    $('#modalCrud').modal('show');
                })


                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
                $("#btnAceptModalCrud").prop("disabled", false);
            }
        }

        /*if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            if (($("#idCompromiso").val() != "" && $("#idCompromiso").val() != null) &&
                ($("#rc").val() != "" && $("#rc").val() != null) &&
                ($("#rec").val() != "" && $("#rec").val() != null)){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);



                $.ajax({
                    method:"POST",
                    url: "./updCompromiso",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');
                        messageBox(1,"Exito","Se modificaron los datos.");
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Comunicarse con el administrador.");
                    }
                });
            }else{
                messageBox(2,"Error","Existen campos vacíos");
                $('#formCrud *').prop('disabled', false);
                $("#idActividad").prop('disabled', true);
            }
        }
      

        if ($(this).attr('accion')=='del'){
           
            $('#formCrud *').prop('disabled', false);
            var frm = $("#formCrud").serialize();
            $('#formCrud *').prop('disabled', true);

            $.ajax({
                method:"POST",
                url: "./delCompromiso",
                data: frm,
                success : function(data) {
                    
                    $('#modalCrud').modal('hide');
                    $('#dataTable').DataTable().ajax.reload();
                   
                },
                error: function( req, status, err ) {
                    messageBox(3,"Error","Comunicarse con el administrador.");
                }
            });
        }*/

        /*if ($(this).attr('accion')=='ins'){
            
            if (($("#rc").val() != "" && $("#rc").val() != null) &&
                ($("#rec").val() != "" && $("#rec").val() != null) ){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insCompromiso",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');
                        messageBox(1,"Exito","Se registraron los datos.");
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,"Error","Comunicarse con el administrador.");
                    }
                });
            
            }else{
                messageBox(2,"Error","Existen campos vacíos");
                $('#formCrud *').prop('disabled', false);
                $("#idActividad").prop('disabled', false);
            }

        }*/
    }); 
        
    //Consulta
    $("#btnAceptModalCrud").attr('accion','sel');
    $('#btnAceptModalCrud').trigger('click');

        
});

function getDatosGenerales(id){

    $.ajax({
        method:"POST",
        url : './getCompromisos',
        data: {
            "idCompromiso":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                $("#rc").val(row.rc);
                $("#ruc").val(row.ruc);
                
                getListaTerceros(row.rc);               
                $("#codTercero").append($("<option selected='selected'></option>").val(row.codTercero).text(row.num_ruc_ter + ' - ' + row.nom_ter)).trigger('change');
                

            }

        }
    });
}



function getListaTerceros(rc){

    $.ajax({
        'url' : './getListaTerceros',
        data: {
            "rc":rc
        },
        'type' : 'POST',
        'success' : function(data) {
            
            var jsonData = JSON.parse(data);
            

            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];

                $('#codTercero').append($('<option></option>').val(row.codTercero).html(row.rucTercero+' - '+row.nombreTercero));    
                
            }
        }
    });
}

function limpiarModalCrud(){
    $("#formCrud")[0].reset();
}


function deserializar(dataArray){

   
    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
          row[field.name] = field.value;
        });

        //$('#idCompromiso').val(dataObj['idCompromiso']);
        $("#idCompromiso").val(row.idCompromiso);
        $("#fechaVencimientoCuotaIni").val(row.fechaVencimientoCuotaIni);
        $("#fechaVencimientoCuotaFin").val(row.fechaVencimientoCuotaFin);
        $("#mtoCuotaIni").val(row.mtoCuotaIni);
        $("#mtoCuotaFin").val(row.mtoCuotaFin);
        $("#saldoMtoEmbIni").val(row.saldoMtoEmbIni);
        $("#saldoMtoEmbFin").val(row.saldoMtoEmbFin);
        
    }
}
   
function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').hide();
        $('#pdfCronograma').hide();
        $('#cardDatosGenerales').hide();
        
    }
    if($('#shape').val()=='2'){
        //Consulta de Cuotas por idCompromiso
        $('#dropMenu').hide();
        $('#mostrarModalSel').hide();
        $('#mostrarModalIns').hide();
        $('#pdfCronograma').show();
        $('#cardDatosGenerales').show();
    }
    if($('#shape').val()=='3'){
        //Consulta de Cuotas por tercero
        $('#mostrarModalSel').hide();
        $('#mostrarModalIns').hide();
        $('#pdfCronograma').hide();
        $('#cardDatosGenerales').hide();
    }

    setInterval(timer, 10000);

        
   
    $('#tipoFrecuencia').append($('<option></option>').val("03").html("03 - SEMANAL"));
    $('#tipoFrecuencia').append($('<option></option>').val("05").html("05 - BIMENSUAL"));
    $('#tipoFrecuencia').append($('<option></option>').val("07").html("07 - MENSUAL"));    
    $('#tipoFrecuencia').append($('<option></option>').val("09").html("09 - BIMESTRAL"));
    $('#tipoFrecuencia').append($('<option></option>').val("11").html("11 - TRIMESTRAL"));
    $('#tipoFrecuencia').append($('<option></option>').val("13").html("13 - CUATRIMESTRAL"));
    $('#tipoFrecuencia').append($('<option></option>').val("15").html("15 - SEMESTRAL"));
    $('#tipoFrecuencia').append($('<option></option>').val("17").html("17 - ANUAL"));
    

    getDatosGenerales($("#idCompromiso2").val());

    $("#pdfCronograma").on("click", function(){
         $("#pdfCronogramaForm").submit();
    });

    //$("#pdfCronograma").on("click", function(){
        //window.open("pdfCronograma?idCompromiso="+$("#idCompromiso2").val(),'_blank');    
    // })


                /*if (row.numOrdFis !== null && row.numOrdFis.trim() !== "" ){
                    $("#numOrdFis").append($("<option selected='selected'></option>").val(row.numOrdFis).text(row.numOrdFis)).trigger('change');
                }*/

                
            
                
                

    /*$('#cantidadPagoPropuesto').keyup(function(){

        if($(this).val() != ""){
            //$(this).val(Number($(this).val()));

            //if(Number.isInteger(parseInt($(this).val())) == false ) {
            if(isNumeric($(this).val())==false){
                alert("Sólo números válidos");  
                $(this).val("");     
            }
        }
    });  */

    
    


    
    $('#fechaVencimientoCuotaIni').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fechaVencimientoCuotaIniContainer'
    });

    $('#fechaVencimientoCuotaFin').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fechaVencimientoCuotaFinContainer'
    });


    

    
    //$("#fecPagoPropuesto").mask("99/99/9999");
    
    

     

    
    
    

    /*$("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            $(this).val($(this).val().replace('"', ''));
            $(this).val($(this).val().replace("'", ""));
        });
    });
    */

  


    /*$("#numOrdFis").select2({ 

        placeholder: "Seleccionar OF", 
        minimumInputLength: 3, 
        language: {
            inputTooShort: function() {
                return 'Agregar carateres para buscar...'
            }
        },
        multiple: false, 
        width: 400, 
        ajax: { 
            
            url: "./getOfCombo",
            type: "POST", 
            data: function(term) { 
                return term;
            }, 
            processResults: function(data, page) { 
                var jsonData = JSON.parse(data);
                return { 

                    results: $.map(jsonData.data, function (item) {
            
                        return {
                            id: item.id,
                            text: item.descripcion
                            
                        }
                    })                    
                }; 
            }, 
        } 
    });*/ 
}





