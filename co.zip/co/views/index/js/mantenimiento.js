$(document).ready(function(){

	inicializarModulo();
 
});

function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){

    }
    
    setInterval(timer, 10000);

 
 }    

