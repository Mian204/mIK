
$(document).ready(function () {

    inicializarModulo();
    
    var frmSelBkp = null;

    //Modal Sel
    $('#mostrarModalSel').on('click', function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Seleccionar');
        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').text('Buscar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').hide();
        $('#idTomaDichoDiv').show();
        $('#idTomaDicho').prop('disabled', false);
        $('#rc').show();
        $('#rucContribuyenteDiv').show();
        $('#rucContribuyente').prop('disabled', false);
        $('#codTerceroDiv').hide();
        $('#rucTerceroDiv').show();
        $('#fecTomaDichoDiv').hide();
        $('#fecTomaDichoRangoDiv').show();        
        $('#resultadoDiv').show();
        $('#mtoInformadoDiv').hide(); 
        $('#nombreEncargadoTerDiv').hide();      
        $('#telefonoEncargadoTerDiv').hide();
        $('#correoEncargadoTerDiv').hide(); 
        $('#regResponsableDiligenciaDiv').show();
        $('#codAuxRcDiv').show();
        $('#codAuxRc').prop('disabled', false);
        $('#codEjeRcDiv').show(); 
        $('#codEjeRc').prop('disabled', false);
        $('#usuRegDiv').hide(); 
        $('#fecRegDiv').hide(); 
        $('#fecRegRangoDiv').show(); 
        $('#usuModDiv').hide(); 
        $('#fecModDiv').hide(); 
        $('#estadoDiv').hide(); 

        $('#rc').focus();

        $('#btnAceptModalCrud').attr('class','btn btn-primary');

        if (frmSelBkp!==null){
            deserializar(frmSelBkp);
        }

        $('#modalCrud').modal('show');
    });  
    
    //Modal Ins
    $('#mostrarModalIns').on('click', function(){
        
        limpiarModalCrud();

        $('#tituloModalCrud').text('Nuevo Registro');
        $('#btnAceptModalCrud').attr('accion','ins');
        $('#btnAceptModalCrud').text('Registrar');
        $('#btnCancelModalCrud').show();

        $('#formCrud *').prop('disabled', false);
        $('#btnAceptModalCrud').prop('disabled', false);

        $('#formCrud div.form-group').show();
        $('#idTomaDichoDiv').hide();
        $('#idTomaDicho').prop('disabled', false);
        $('#rc').show();
        $('#rucContribuyenteDiv').show();
        $('#rucContribuyente').prop('disabled', true);
        $('#codTerceroDiv').show();
        $('#rucTerceroDiv').hide();
        $('#fecTomaDichoDiv').hide();
        $('#fecTomaDichoRangoDiv').hide();        
        $('#resultadoDiv').hide();
        $('#mtoInformadoDiv').hide(); 
        $('#nombreEncargadoTerDiv').hide();      
        $('#telefonoEncargadoTerDiv').hide();
        $('#correoEncargadoTerDiv').hide(); 
        $('#regResponsableDiligenciaDiv').show();
        $('#codAuxRcDiv').hide();
        $('#codAuxRc').prop('disabled', true);
        $('#codEjeRcDiv').hide(); 
        $('#codEjeRc').prop('disabled', true);
        $('#usuRegDiv').hide(); 
        $('#fecRegDiv').hide(); 
        $('#fecRegRangoDiv').hide(); 
        $('#usuModDiv').hide(); 
        $('#fecModDiv').hide(); 
        $('#estadoDiv').hide(); 

        $('#rc').focus();
        
        //$("#fecRegDiv .input-group.date").datepicker().datepicker("setDate", moment(new Date()).format('DD/MM/YYYY'));
        //$("#fecReg").val(moment(new Date()).format('DD/MM/YYYY'));
       

        $('#btnAceptModalCrud').attr('class','btn btn-primary');         

        $('#modalCrud').modal('show');
    });       

    //btnAceptModalCrud
    $('#btnAceptModalCrud').on('click', function(){

        if ($(this).attr('accion')=='sel'){

            if (true){

                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                frmSelBkp = $("#formCrud").serializeArray();
                $('#formCrud *').prop('disabled', true);

                $('#btnAceptModalCrud').prop('disabled', true);

                $('#dataTable').dataTable().fnClearTable();

                var table = $('#dataTable').DataTable({
                    "destroy": true,            
                    "pageLength": 10,
                    
                    "scrollX": true,
                    "language":{
                        "sProcessing":     "Procesando...",
                        "sLengthMenu":     "Mostrar _MENU_ registros",
                        "sZeroRecords":    "No se encontraron resultados",
                        "sEmptyTable":     "Ningún dato disponible en esta tabla",
                        "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
                        "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
                        "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
                        "sInfoPostFix":    "",
                        "sSearch":         "Filtrar:",
                        "sUrl":            "",
                        "sInfoThousands":  ",",
                        "sLoadingRecords": "Cargando...",
                        "oPaginate": {
                            "sFirst":    "Primero",
                            "sLast":     "Último",
                            "sNext":     "Siguiente",
                            "sPrevious": "Anterior"
                        },
                        "oAria": {
                            "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                            "sSortDescending": ": Activar para ordenar la columna de manera descendente"
                        }
                    },
                    "bSort": true,
                    //"order": [],
                    "order":[[0,"desc"]],                 
                    
                    "ajax":
                    {
                        "method":"POST",
                        "url": "./getTomaDichos",
                        "data": function(d) {
                            return frm;
                        },     
                        error: function (jqXHR, textStatus, errorThrown) {
                            messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                            $('#btnAceptModalCrud').prop('disabled', false);
                        } 
                    },

                    
                            

                    "columns":
                    [
                        {"data":"id"},                        
                        {"data":"rc"},
                        {"data":"rucDesc"},
                        {"data":"rucTerceroDesc"},

                        {"data":"cantDiligencias","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            if($('#shape').val()=='1'){
                                $(nTd).html("<form target='_blank' method='post' action='./diligencia'>\
                                <input type='hidden' name='idTomaDicho' value='"+oData.id+"'>\
                                <input type='hidden' name='shape' value='2'>\
                                <input type='hidden' name='title' value='Diligencias de la Toma de Dicho N° "+oData.id+"''>\
                                <left><input class='btn btn-primary' type='submit' value='"+oData.cantDiligencias+"'></left>\
                                </form>");                           
                            }
                            else if($('#shape').val()=='2'){
                                $(nTd).html("<form target='_blank' method='post' action='./diligencia'>\
                                <input type='hidden' name='idTomaDicho' value='"+oData.id+"'>\
                                <input type='hidden' name='shape' value='3'>\
                                <input type='hidden' name='title' value='Diligencias de la Toma de Dicho N° "+oData.id+"''>\
                                <left><input class='btn btn-primary' type='submit' value='"+oData.cantDiligencias+"'></left>\
                                </form>");     
                            }
                            else if($('#shape').val()=='3'){
                                $(nTd).html("<form target='_blank' method='post' action='./diligencia'>\
                                <input type='hidden' name='idTomaDicho' value='"+oData.id+"'>\
                                <input type='hidden' name='shape' value='3'>\
                                <input type='hidden' name='title' value='Diligencias de la Toma de Dicho N° "+oData.id+"''>\
                                <left><input class='btn btn-primary' type='submit' value='"+oData.cantDiligencias+"'></left>\
                                </form>");        
                            }else{
                                $(nTd).html("");
                            }
                            
                        }},


                        {"data":"fecTomaDicho"},
                        {"data":"resultadoDesc"},       
                        {"data":"subResultadoDesc"}, 
                        {"data":"fecUltimaDiligencia"},
                        {"data":"mtoInformado"},
                        {"data":"nombreEncargadoTer"},
                        {"data":"telefonoEncargadoTer"},
                        {"data":"correoEncargadoTer"},
                        {"data":"codAuxRc"},
                        {"data":"codEjeRc"},
                        {"data":"regResponsableDiligenciaDesc"},
                        {"data":"fecReg"},
                        {"data":"estadoDesc"},

                        {"data":"id","fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
                            if ($('#shape').val()=='1'){
                                if (oData.estado=='01'){
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idTomaDicho='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                            <button type='button' idTomaDicho='"+oData.id+"' class='mostrarPdf btn btn-primary'data-toggle='tooltip' title='PDF'><i class='fas fa-file-pdf'></i></button>\
                                        </div>\
                                    </div>");
                                }else{
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idTomaDicho='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        </div>\
                                    </div>");
                                }
                                
                            }else if ($('#shape').val()=='2'){
                                if (oData.estado=='01'){
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idTomaDicho='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                            <button type='button' idTomaDicho='"+oData.id+"' class='mostrarModalUpd btn btn-primary'data-toggle='tooltip' title='Modificar'><i class='far fa-edit'></i></button>\
                                            <button type='button' idTomaDicho='"+oData.id+"' class='mostrarPdf btn btn-primary'data-toggle='tooltip' title='PDF'><i class='fas fa-file-pdf'></i></button>\
                                            <button type='button' idTomaDicho='"+oData.id+"' class='mostrarModalDel btn btn-danger' data-toggle='tooltip' title='Eliminar' ><i class='fas fa-trash-alt'></i></button>\
                                        </div>\
                                    </div>");
                                }else{
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idTomaDicho='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        </div>\
                                    </div>");
                                }
                            }else if ($('#shape').val()=='3'){
                                if (oData.estado=='01'){
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idTomaDicho='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                            <button type='button' idTomaDicho='"+oData.id+"' class='mostrarPdf btn btn-primary'data-toggle='tooltip' title='PDF'><i class='fas fa-file-pdf'></i></button>\
                                        </div>\
                                    </div>");
                                }else{
                                    $(nTd).html("<div class='btn-toolbar m-b-10'>\
                                        <div class='btn-group'>\
                                            <button type='button' idTomaDicho='"+oData.id+"' class='mostrarModalGet btn btn-primary' data-toggle='tooltip' title='Información'><i class='fas fa-info'></i></button>\
                                        </div>\
                                    </div>");
                                }
                            }else{                                
                                $(nTd).html("");
                            }
                            
                        }}
                    ],
                });
                

                //seleccionar todo
                $("#select_all").on( "click", function(e) {
                if ($(this).is(":checked")) {
                    table.rows().select();        
                } else {
                    table.rows().deselect(); 
                }});

                if($('#shape').val()=='1' ||  $('#shape').val()=='2'){
                    var buttons = new $.fn.dataTable.Buttons(table, {
                    buttons: [
                       { 
                            extend: 'excel', 
                            text: 'Descargar Excel', 
                            className:'buttonDataTable', 
                            type:'button'
                        }
                    ]
                    }).container().appendTo($('#buttonModule'));

                    $(".buttonDataTable").removeClass("btn-secondary").addClass("btn btn-primary waves-effect waves-light");
                }


                //Modal Crud (get)
                $('#dataTable tbody').on('click','button.mostrarModalGet',function(){
                                       
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Información');
                    $('#btnAceptModalCrud').attr('accion','get');
                    $('#btnAceptModalCrud').text('Aceptar');
                    $('#btnCancelModalCrud').hide();
                
                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#idTomaDichoDiv').show();
                    $('#idTomaDicho').prop('disabled', true);
                    $('#rc').show();
                    $('#rucContribuyenteDiv').show();
                    $('#rucContribuyente').prop('disabled', true);
                    $('#codTerceroDiv').show();
                    $('#rucTerceroDiv').hide();
                    $('#fecTomaDichoDiv').show();
                    $('#fecTomaDichoRangoDiv').hide();        
                    $('#resultadoDiv').show();
                    $('#mtoInformadoDiv').show(); 
                    $('#nombreEncargadoTerDiv').show();      
                    $('#telefonoEncargadoTerDiv').show();
                    $('#correoEncargadoTerDiv').show(); 
                    $('#codAuxRcDiv').show();
                    $('#codAuxRc').prop('disabled', true);
                    $('#codEjeRcDiv').show(); 
                    $('#codEjeRc').prop('disabled', true);
                    $('#usuRegDiv').show(); 
                    $('#fecRegDiv').show(); 
                    $('#fecRegRangoDiv').hide(); 
                    $('#usuModDiv').show(); 
                    $('#fecModDiv').show(); 
                    $('#estadoDiv').show(); 


                    $('#rc').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('idTomaDicho'));     

                    $('#modalCrud').modal('show');

                    // $("#idUsuario").change();
                    // $("#horasOcupadas").keyup();
                });

                //Modal Crud (upd)
                $('#dataTable tbody').on('click','button.mostrarModalUpd',function(){

                    limpiarModalCrud();
                     
                    $('#tituloModalCrud').text('Modificar');
                    $('#btnAceptModalCrud').attr('accion','upd');
                    $('#btnAceptModalCrud').text('Guardar');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', false);
                    $('#btnAceptModalCrud').prop('disabled', false);

                    $('#formCrud div.form-group').show();
                    $('#idTomaDichoDiv').show();
                    $('#idTomaDicho').prop('disabled', true);
                    $('#rc').show();
                    $('#rucContribuyenteDiv').show();
                    $('#rucContribuyente').prop('disabled', true);
                    $('#codTerceroDiv').show();
                    $('#rucTerceroDiv').hide();
                    $('#fecTomaDichoDiv').hide();
                    $('#fecTomaDichoRangoDiv').hide();        
                    $('#resultadoDiv').hide();
                    $('#mtoInformadoDiv').hide(); 
                    $('#nombreEncargadoTerDiv').hide();      
                    $('#telefonoEncargadoTerDiv').hide();
                    $('#correoEncargadoTerDiv').hide(); 
                    $('#regResponsableDiligenciaDiv').show();
                    $('#codAuxRcDiv').show();
                    $('#codAuxRc').prop('disabled', true);
                    $('#codEjeRcDiv').show(); 
                    $('#codEjeRc').prop('disabled', true);
                    $('#usuRegDiv').hide(); 
                    $('#fecRegDiv').hide(); 
                    $('#fecRegRangoDiv').hide(); 
                    $('#usuModDiv').hide(); 
                    $('#fecModDiv').hide(); 
                    $('#estadoDiv').show(); 

                    $('#rcDiv').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-primary');

                    get($(this).attr('idTomaDicho'));

                    $('#modalCrud').modal('show');
                })

                //Modal Crud (del)
                $('#dataTable tbody').on('click','button.mostrarModalDel',function(){
                    
                    limpiarModalCrud();

                    $('#tituloModalCrud').text('Eliminar');       
                    $('#btnAceptModalCrud').attr('accion','del');
                    $('#btnAceptModalCrud').text('Eliminar');
                    $('#btnCancelModalCrud').show();

                    $('#formCrud *').prop('disabled', true);
                    $('#btnAceptModalCrud').prop('disabled', false);
                    
                    $('#formCrud div.form-group').show();
                    $('#idTomaDichoDiv').show();
                    $('#idTomaDicho').prop('disabled', true);
                    $('#rc').show();
                    $('#rucContribuyenteDiv').show();
                    $('#rucContribuyente').prop('disabled', true);
                    $('#codTerceroDiv').show();
                    $('#rucTerceroDiv').hide();
                    $('#fecTomaDichoDiv').hide();
                    $('#fecTomaDichoRangoDiv').hide();        
                    $('#resultadoDiv').hide();
                    $('#mtoInformadoDiv').hide(); 
                    $('#nombreEncargadoTerDiv').hide();      
                    $('#telefonoEncargadoTerDiv').hide();
                    $('#correoEncargadoTerDiv').hide(); 
                    $('#regResponsableDiligenciaDiv').hide();
                    $('#codAuxRcDiv').show();
                    $('#codEjeRcDiv').show(); 
                    $('#usuRegDiv').hide(); 
                    $('#fecRegDiv').hide(); 
                    $('#fecRegRangoDiv').hide(); 
                    $('#usuModDiv').hide(); 
                    $('#fecModDiv').hide(); 
                    $('#estadoDiv').hide();

                    $('#rcDiv').focus();

                    $('#btnAceptModalCrud').attr('class','btn btn-danger');

                    get($(this).attr('idTomaDicho'));

                    $('#modalCrud').modal('show');
                })

                $('#dataTable tbody').on('click','button.mostrarPdf',function(){                    
                    window.open("genPdfInd?idTomaDicho="+$(this).attr("idTomaDicho"),'_blank');
                })

                $('#alertaDataTable').hide();

                $('#modalCrud').modal('hide');
            }
            else{
                messageBox(2,"Error","Debe seleccionar aún criterio de selección");
                $("#btnAceptModalCrud").prop("disabled", false);
            }
        }

        if ($(this).attr('accion')=='get'){
            $('#modalCrud').modal('hide');
        }
   
        if ($(this).attr('accion')=='upd'){
           

            if (($("#rc").val() != "" && $("#rc").val() != null) &&
                ($("#codTercero").val() != "" && $("#codTercero").val() != null)){
                
                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./updTomaDicho",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se actualizó el registro con el Id: '+msjDatos);                         
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }
     
        if ($(this).attr('accion')=='del'){
           
            $('#formCrud *').prop('disabled', false);
            var frm = $("#formCrud").serialize();            
            $('#formCrud *').prop('disabled', true);

            $.ajax({
                method:"POST",
                url: "./delTomaDicho",
                data: frm,
                success : function(data) {
                    
                    $('#modalCrud').modal('hide');
                    $('#dataTable').DataTable().ajax.reload();

                    try {
                        var jsonData = JSON.parse(data);
                        var msjDatos = '';
                        for (var i = 0; i < jsonData.data.length; i++) {
                            var row = jsonData.data[i];
                            msjDatos += row.id + ' ';
                        }   
                        messageBox(1,'Exito','Se eliminó el registro con el Id: '+msjDatos);
                    }
                    catch(e) {
                       messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }   
                   
                },
                error: function( req, status, err ) {
                    messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                }
            });
        }

        if ($(this).attr('accion')=='ins'){
            
            if (($("#rc").val() != "" && $("#rc").val() != null) &&
                ($("#codTercero").val() != "" && $("#codTercero").val() != null) ){


                $('#formCrud *').prop('disabled', false);
                var frm = $("#formCrud").serialize();
                $('#formCrud *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insTomaDicho",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalCrud').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + ' ';
                            }   
                            messageBox(1,'Exito','Se registraron los datos con el Id: '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   

                        
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }
    });   
        
    //Consulta
    //$('#btnAceptModalCrud').attr('accion','sel');
    //$('#btnAceptModalCrud').trigger('click');   

    if($('#shape').val()=='1'){
        var myDateIni = new Date();
        $('#fecRegIni').val(moment(myDateIni).add(-1, 'months').format('DD/MM/YYYY'));
        $('#fecRegFin').val(moment(myDateIni).format('DD/MM/YYYY'));

        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').trigger('click'); 

        frmSelBkp = null;

        $('#alertaDataTable').show();  
        $('#alertaDataTableMensaje').text('Se muestran los registros de los últimos 30 días. Para  busqueda mas avanzada, dar clic en el botón "Buscar".');
    }


    if($('#shape').val()=='2'){
        var myDateIni = new Date();
        $('#fecRegIni').val(moment(myDateIni).add(-1, 'months').format('DD/MM/YYYY'));
        $('#fecRegFin').val(moment(myDateIni).format('DD/MM/YYYY'));

        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').trigger('click'); 

        frmSelBkp = null;

        $('#alertaDataTable').show();  
        $('#alertaDataTableMensaje').text('Se muestran los registros de los últimos 30 días. Para  busqueda mas avanzada, dar clic en el botón "Buscar".');
    }

    if($('#shape').val()=='3'){
        //var myDateIni = new Date();
        //$('#fecRegIni').val(moment(myDateIni).add(-1, 'months').format('DD/MM/YYYY'));
        //$('#fecRegFin').val(moment(myDateIni).format('DD/MM/YYYY'));

        $('#btnAceptModalCrud').attr('accion','sel');
        $('#btnAceptModalCrud').trigger('click'); 

        frmSelBkp = null;

        //$('#alertaDataTable').show();  
    }

    $('#mostrarModalPdf').on('click', function(){

        $('#formPdf')[0].reset();


        var table = $('#dataTable').DataTable();

        var ids = $.map(table.rows('.selected').data(), function (item) {
            return item.id  
        });

        var totalItems = 0;

        ids.forEach(function(id) {
            totalItems = totalItems + 1;
        });


        if(totalItems!=0){


            $('#tituloModalPdf').text('Generación de Formatos Toma de Dichos');
            $('#btnAceptModalPdf').attr('accion','gen');
            $('#btnAceptModalPdf').text('Generar');
            $('#btnCancelModalPdf').show();

            $('#formPdf *').prop('disabled', false);
            $('#btnAceptModalPdf').prop('disabled', false);

            $('#formPdf div.form-group').show();
            
            $('#totalItems').val(totalItems);

            $('#modalPdf').modal('show');
                         

        }else{
            messageBox(2,'Error','Seleccionar al menos un registro');
            
        }
    }); 

    $('#mostrarModalInsMas').on('click', function(){

        $('#formInsMas')[0].reset();

        $('#tituloModalInsMas').text('Registro Masivo');
        $('#btnAceptModalInsMas').attr('accion','insMas');
        $('#btnAceptModalInsMas').text('Registrar');
        $('#btnCancelModalInsMas').show();

        $('#formInsMas *').prop('disabled', false);
        $('#btnAceptModalInsMas').prop('disabled', false);

        $('#formInsMas div.form-group').show();
        
        $('#modalInsMas').modal('show');
    });

    $('#btnAceptModalInsMas').on('click', function(){

        if ($(this).attr('accion')=='insMas'){
            
            if (true){

                $('#formInsMas *').prop('disabled', false);
                var frm = $("#formInsMas").serialize();
                $('#formInsMas *').prop('disabled', true);

                $.ajax({
                    method:"POST",
                    url: "./insMasTomaDicho",
                    data: frm,
                    success : function(data) {
                        
                        $('#dataTable').DataTable().ajax.reload();
                        $('#modalInsMas').modal('hide');

                        try {
                            var jsonData = JSON.parse(data);
                            var msjDatos = '';
                            for (var i = 0; i < jsonData.data.length; i++) {
                                var row = jsonData.data[i];
                                msjDatos += row.id + '<br>';
                            }   
                            messageBox(1,'Exito','Se registró '+jsonData.data.length+' registros con los siguientes Ids: <br> '+msjDatos);
                        }
                        catch(e) {
                           messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                        }   
                    },
                    error: function( req, status, err ) {
                        messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }
                });
            
            }else{
                messageBox(2,'Error','Existen campos vacíos');
            }
        }
    });

    
  
});

function get(id){

    $.ajax({
        method:"POST",
        url : './getTomaDichos',
        data: {
            "idTomaDicho":id,
        },
        success: function(data) {
            
            var jsonData = JSON.parse(data);
            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];
          
                $('#idTomaDicho').val(row.id);
                
                /*if (row.idArea !== null && row.idArea.trim() !== "" ){
                    $("#idArea").append($("<option selected='selected'></option>").val(row.idArea).text(row.idArea)).trigger('change');
                }*/

                /*if (row.idUsuario !== null && row.idUsuario.trim() !== "" ){
                    $("#idUsuario").append($("<option selected='selected'></option>").val(row.idUsuario).text(row.idUsuario)).trigger('change');
                }*/

                

                $('#rc').val(row.rc);
                $('#rucContribuyente').val(row.rucContribuyente);
               
                
                //$("#codTercero").val(row.codTercero);

                getListaTerceros(row.rc);                           
                $('#codTercero').append($("<option selected='selected'></option>").val(row.codTercero).text(row.rucTerceroDesc)).trigger('change');
                
                $('#rucTercero').val(row.rucTercero);
                             
                if(row.fecTomaDicho != null){
                    $('#fecTomaDicho').val(moment(row.fecTomaDicho, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                }     

                $('#resultado').val(row.resultado);

                $('#mtoInformado').val(row.mtoInformado);
                $('#nombreEncargadoTer').val(row.nombreEncargadoTer);
                $('#telefonoEncargadoTer').val(row.telefonoEncargadoTer);
                
                
                $('#correoEncargadoTer').val(row.correoEncargadoTer);     
                $('#regResponsableDiligencia').val(row.regResponsableDiligencia);     
                $('#codAuxRc').val(row.codAuxRc);     
                $('#codEjeRc').val(row.codEjeRc);
                $('#usuReg').val(row.usuReg);
                $('#fecReg').val(moment(row.fecReg, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                $('#usuMod').val(row.usuMod);
                if(row.fecMod != null){
                    $('#fecMod').val(moment(row.fecMod, 'YYYY-MM-DD').format('DD/MM/YYYY'));
                }                
                $('#estado').val(row.estado);


            
                
            }

        }
    });
}

function deserializar(dataArray){

   
    if (dataArray!==null)
    {
        var row = {};

        $(dataArray).each(function(i, field){
          row[field.name] = field.value;
        });
        
        $('#idTomaDicho').val(row.idTomaDicho);
        $('#rc').val(row.rc);
        $('#rucContribuyente').val(row.rucContribuyente);
        $('#rucTercero').val(row.rucTercero);
        $('#fecTomaDichoIni').val(row.fecTomaDichoIni);
        $('#fecTomaDichoFin').val(row.fecTomaDichoFin);
        $('#regResponsableDiligencia').val(row.regResponsableDiligencia);
        $('#resultado').val(row.resultado);
        $('#codAuxRc').val(row.codAuxRc);
        $('#codEjeRc').val(row.codEjeRc);
        $('#fecRegIni').val(row.fecRegIni);
        $('#fecRegFin').val(row.fecRegFin);        
        $('#estado').val(row.estado);
        
    }
}

function limpiarModalCrud(){

    $("#formCrud")[0].reset();
    
    $('#codTercero').empty();
    $("#codTercero").val("");
    $("#codTercero").text("");



    //$('[name^="nro_rtf_array"]').remove();
}
   
function inicializarModulo(){

    document.title = $('#title').val();
    $('#titleModule').text($('#title').val());

    if($('#shape').val()=='1'){
        //Consulta General
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').hide();
        $('#mostrarModalInsMas').hide();
    }

    if($('#shape').val()=='2'){
        //Registro
        $('#dropMenu').show();
        $('#mostrarModalSel').show();
        $('#mostrarModalIns').show();
        $('#mostrarModalInsMas').show();
    }

    if($('#shape').val()=='3'){
        //MisAsignados
        $('#dropMenu').show();
        $('#mostrarModalSel').hide();
        $('#mostrarModalIns').hide();
        $('#mostrarModalInsMas').hide();
    }

     
    $('#resultado').append($('<option></option>').val('').html('Seleccionar'));
    $('#resultado').append($('<option></option>').val('0').html('0 - SIN RESPUESTA'));
    $('#resultado').append($('<option></option>').val('1').html('1 - NO HA PRESENTADO ESCRITO'));
    $('#resultado').append($('<option></option>').val('2').html('2 - NO ES CLIENTE DEL EJECUTADO'));
    $('#resultado').append($('<option></option>').val('3').html('3 - ES CLIENTE DEL EJECUTADO, SIN MONTO A RETENER'));
    $('#resultado').append($('<option></option>').val('4').html('4 - ES CLIENTE DEL EJECUTADO, CON MONTO A RETENER'));

  

    
    $('#plano').change(function() {
        var file = this.files[0];
        var item = '';
        var reader = new FileReader();

        reader.onload = function(progressEvent){

            var arrayOne = new Array();
            var arrayOneRow = new Array();
            var mensajeError = '';
            var linea = 0;
            var lines = this.result.split('\n');
            var htmlArray= '';

            for(var line = 0; line < lines.length; line++){
                item = lines[line];
                item = item.trim();
                if (item != ''){

                    arrayOneRow = item.split("\t");

                    var rc = arrayOneRow[0];
                    var codTercero = arrayOneRow[1];
                    var regResponsableDiligencia = arrayOneRow[2];                 
                    
                    linea=line+1

                    if (rc.length != 13 ){
                        mensajeError += '<br><br>Fila '+linea+', columna rc: '+rc+' debe tener 13 dígitos';
                    }
                    if (codTercero.length != 4 ){
                        mensajeError += '<br><br>Fila '+linea+', columna codTercero: '+codTercero+' debe tener 4 dígitos';
                    }
                    if (regResponsableDiligencia.length != 4 ){
                        mensajeError += '<br><br>Fila '+linea+', columna regResponsableDiligencia: '+regResponsableDiligencia+' debe tener 4 dígitos';
                    }
                    if(mensajeError==''){
                        //arrayOne[line] = arrayOneRow;
                        //hidden
                        htmlArray += '<input type="hidden" name="datosArray['+line+'][0]" value="'+arrayOneRow[0]+ '">';
                        htmlArray += '<input type="hidden" name="datosArray['+line+'][1]" value="'+arrayOneRow[1]+ '">';
                        htmlArray += '<input type="hidden" name="datosArray['+line+'][2]" value="'+arrayOneRow[2]+ '">';
                    }
                }
            }

            if (linea==0 || mensajeError!=''){
                if (arrayOne.length==0){
                    messageBox(2,'Error','El plano esta vacío.');
                }

                if(mensajeError!=''){
                    messageBox(2,'Error','Se detectaron errores en el plano, corregirlo por favor: '+mensajeError);
                }
                arrayOne = new Array();
                $('#plano').val('');
                document.getElementById('datosHiddenDiv').innerHTML = '';
            }else{

                document.getElementById('datosHiddenDiv').innerHTML = htmlArray;
            }
            

        };
        reader.readAsText(file);
    });

    $('#estado').change(function(){
        if ($('#btnAceptModalCrud').attr('accion')=='upd'){
            if($('#estado').val()=='02'){
                messageBox(2,'Atención','Cambiaras el estado del registro a: '+$('#estado option:selected').text());    
            }
            
        }
    });


    setInterval(timer, 10000);


    $('#fecTomaDicho').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecTomaDichoContainer'
    });

    $('#fecTomaDichoIni').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecTomaDichoIniContainer'
    });

    $('#fecTomaDichoFin').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '-90d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecTomaDichoFinContainer'
    });
    
    $('#fecRegIni').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecRegIniContainer'
    });

    $('#fecRegFin').datepicker({
        todayBtn: "linked",
        //keyboardNavigation: false,
        //forceParse: false,
        calendarWeeks: false,
        autoclose: true,
        format: 'dd/mm/yyyy',
        //startDate: '0d',  
        //endDate: '+90d', //startDate: '-1d',  
        language: 'es',
        //daysOfWeekDisabled: [0],
        container:'#fecRegFinContainer'
    });


    $("#formCrud").find(':input').each(function() {
        $("#"+this.id).keyup(function(){
            $(this).val($(this).val().replace('"', ''));
            $(this).val($(this).val().replace("'", ""));
        });
    });
    

    $('#rc').change(function(){
        
        

        if($(this).val().length == 13){
            $.ajax({
                'url' : './getDatosRC',                
                data: {
                    "rc":$(this).val()
                },
                'type' : 'POST',
                'success' : function(data) {
                    
                    var jsonData = JSON.parse(data);
                    //var regUsuario;
                    //$('#codTercero').empty();
                    for (var i = 0; i < jsonData.data.length; i++) {
                        var row = jsonData.data[i];

                        $('#rucContribuyente').val(row.ruc);
                        
                        
                    }
                }
            });


            
            getListaTerceros($(this).val());
            

            $.ajax({
                'url' : './getTomaDichos',                
                data: {
                    "rc":$(this).val()
                },
                'type' : 'POST',
                'success' : function(data) {
                    
                    

                    try {
                        var jsonData = JSON.parse(data);
                        var msjDatos = '';
                        for (var i = 0; i < jsonData.data.length; i++) {
                            var row = jsonData.data[i];
                            msjDatos += row.rc + ' ';
                        }   
                        if (msjDatos != ''){
                            messageBox(2,'Información','Existe registro(s) anterior(es) de la rc');    
                        }
                        
                    }
                    catch(e) {
                       messageBox(3,'Error','Reportar a: '+$('#correoti').val());
                    }   



                }
            });



        }
    });   
}



function getListaTerceros(rc){

    $('#codTercero').empty();
    $('#codTercero').val('');
    $('#codTercero').text('');

    $.ajax({
        'url' : './getListaTerceros',
        data: {
            "rc":rc
        },
        'type' : 'POST',
        'success' : function(data) {
            
            var jsonData = JSON.parse(data);
            

            for (var i = 0; i < jsonData.data.length; i++) {
                var row = jsonData.data[i];

                $('#codTercero').append($('<option></option>').val(row.codTercero).html(row.rucTercero+' - '+row.nombreTercero));    
                
            }
        }
    });
}

/*function validarPlanoInsMas(){
    var file = $('#plano').files[0];
    var item = '';
    var reader = new FileReader();

    reader.onload = function(progressEvent){

        var arrayOne = new Array();
        var arrayOneRow = new Array();
        var mensajeError = '';
        var linea = 0;
        var lines = this.result.split('\n');


        for(var line = 0; line < lines.length; line++){
            item = lines[line];
            item = item.trim();
            if (item != ''){

                arrayOneRow = item.split("\t");

                var rc = arrayOneRow[0];
                var rucTercero = arrayOneRow[1];
                var regResponsableDiligencia = arrayOneRow[2];                 
                
                linea=lines+1

                if (rc.length != 13 ){
                    mensajeError += '<br>Fila: '+linea+', columna rc: '+rc+' debe tener 13 dígitos';
                }
                if (rucTercero.length != 12 ){
                    mensajeError += '<br>Fila: '+linea+', columna rucTercero: '+rucTercero+' debe tener 11 dígitos';
                }
                if (regResponsableDiligencia.length != 4 ){
                    mensajeError += '<br>Fila: '+linea+', columna regResponsableDiligencia: '+regResponsableDiligencia+' debe tener 4 dígitos';
                }
                if(mensajeError==''){
                    arrayOne[line] = arrayPlanoFila;
                }
            }
        }

        if(mensajeError!=''){
            messageBox(2,'Error','Se detectaron errores en el plano, corregirlo por favor: '+mensajeError);
            arrayOne = new Array();
        }
        
        if (arrayOne.length==0){
            alert('El archivo plano está vacío.');
            arrayOne = new Array();
            $('#plano').val("");
        }

    };
    reader.readAsText(file);
    return arrayOne;
}*/

function esDiaHabil(fechaString,feriadosArray){
    
    //*****Formato: 'DD/MM/YYYY' ********/

    //convirtiendo a YYYY-MM-DD
    fechaString=moment(fechaString, 'DD/MM/YYYY').format('YYYY-MM-DD');

    fechaDate = new Date(fechaString);
    
    fechaDate.setTime(fechaDate.getTime() + 24*60*60*1000);

    var anio = fechaDate.getFullYear();
    var mes = (fechaDate.getMonth() + 1) < 10 ? "0" + (fechaDate.getMonth()+1) : fechaDate.getMonth()+1;
    var dia = (fechaDate.getDate()) < 10 ? "0" + (fechaDate.getDate()) : fechaDate.getDate();

    var fechaString = anio + "-" + mes + "-" + dia;

    var feriado = feriadosArray.indexOf(fechaString);

    if(fechaDate.getDay() == 6 || fechaDate.getDay() == 0 || feriado>=0){
        return false;
    }else{
        return true;
    }
}




