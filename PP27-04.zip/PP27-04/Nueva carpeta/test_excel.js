const Exceljs = require('exceljs');
const path = require('path');

async function diagnosticarExcel() {
    const RutaArchivoExcel = path.resolve(process.cwd(), 'Data', 'Base_Contribuyente.xlsx');
    
    console.log(`Leyendo archivo desde: ${RutaArchivoExcel}`);
    
    const workbook = new Exceljs.Workbook();
    
    try {
        await workbook.xlsx.readFile(RutaArchivoExcel);
        console.log('✓ Archivo leído correctamente');
        
        console.log(`Total de hojas en el workbook: ${workbook.worksheets.length}`);
        
        workbook.worksheets.forEach((sheet, index) => {
            console.log(`Hoja ${index}: "${sheet.name}" - ${sheet.rowCount} filas`);
        });
        
        // Intentar acceso con índice 1
        const sheet1 = workbook.getWorksheet(1);
        console.log(`\ngetWorksheet(1): ${sheet1 ? `"${sheet1.name}"` : 'undefined'}`);
        
        // Intentar acceso con índice 0
        const sheet0 = workbook.getWorksheet(0);
        console.log(`getWorksheet(0): ${sheet0 ? `"${sheet0.name}"` : 'undefined'}`);
        
        // Obtener por nombre
        const hojas = workbook.worksheets.map(s => s.name);
        console.log(`\nNombres de hojas: ${hojas.join(', ')}`);
        
        // Obtener la primera hoja disponible
        const primeraHoja = workbook.worksheets[0];
        if (primeraHoja) {
            console.log(`\nPrimera hoja: "${primeraHoja.name}"`);
            console.log(`Filas: ${primeraHoja.rowCount}`);
            console.log(`Columnas: ${primeraHoja.columnCount}`);
            
            // Mostrar primeras 3 filas
            console.log('\n--- Primeras 3 filas ---');
            for (let i = 1; i <= Math.min(3, primeraHoja.rowCount); i++) {
                const row = primeraHoja.getRow(i);
                const values = row.values.slice(1, 6); // Primeras 5 columnas
                console.log(`Fila ${i}: ${values.join(' | ')}`);
            }
        }
        
    } catch (error) {
        console.error('Error al leer el archivo Excel:', error.message);
    }
}

diagnosticarExcel();
