const fs = require('fs/promises')
const pdf = require('pdf-parse');

async function ExtraerDatosPdf(pdfPath, numeroLiquidacion) {
    
    try{

        const dataBuffer = await fs.readFile(pdfPath)
        const pdfData = await pdf(dataBuffer)
        const text = pdfData.text


        // console.log(text)

        if(text){
            const nameMatch = text.match(/SOCIAL\s*.\s*(.+)/)
            // console.log(nameMatch[1])
        
            const documentMatch = text.match(/DOCUMENTO\s*.\s*(.+)/)
        
            //console.log(documentMatch[1])
        
            const tipoDocumentMatch = documentMatch[1].match(/(.+)\s*N/)
        
            const numeroDocumentoMatch = documentMatch[1].match(/\s*N\.?.?.?\s*(.+)/)

            // console.log(tipoDocumentMath[1],'|',numeroDocumentoMatch[1])
        
            const expedienteMatch = text.match(/EXPEDIENTE\s*.\s*(.+)/)
        
            // console.log(expedienteMatch[1])
        
            const numeroLiquidacionMatch = text.matchAll(/(\d{3}\s*-\s*(\d{2}|\d{4})\s*-\s*(\d{6}))\s*(\d{4}|\d{2})/g)
        
            const arregloNumeroLiquidacion = Array.from(numeroLiquidacionMatch)

            // console.log(arregloNumeroLiquidacion);

            // console.log(arregloNumeroLiquidacion)

            // Usar un Set para almacenar coincidencias únicas
        
            const setNumeroLiquidacion = new Set();
        
            for (const numeroLiquidacion of arregloNumeroLiquidacion) {

            //   console.log("Valor actual", numeroLiquidacion);

              setNumeroLiquidacion.add(numeroLiquidacion[1].replace(/\s/g, ""));
            }
        
        
            const arregloNumeroLiquidacionUnicos = Array.from(setNumeroLiquidacion)
            
            console.log(arregloNumeroLiquidacionUnicos)

            let numeroDatos = []
        
            for (const numeroLiquidacionUnico of arregloNumeroLiquidacionUnicos) {
                
                if(numeroLiquidacion == numeroLiquidacionUnico){
                  const razonSocial = nameMatch ? nameMatch[1].trim() : "No Encontrado"
                  const tipoDocumento = tipoDocumentMatch ? tipoDocumentMatch[1].trim() : "No Encontrado"
                  const numeroDocumento = numeroDocumentoMatch ? numeroDocumentoMatch[1].trim() : "No Encontrado"
                  const numeroExpediente = expedienteMatch ? expedienteMatch[1].trim() : "No Encontrado"

                  const fragmentarNumeroLiquidacion = numeroLiquidacionUnico.toString().split('-')

                  const codigoAduana = fragmentarNumeroLiquidacion[0].trim()
                  const anio = fragmentarNumeroLiquidacion[1].slice(-2).trim()
                  const numeroLiquidacion = fragmentarNumeroLiquidacion[2].trim()

                  // console.log("está aquí ", numeroLiquidacionUnico);

                  datos = {
                    razonSocial: razonSocial,
                    tipoDocumento: tipoDocumento,
                    numeroDocumento: numeroDocumento,
                    numeroExpediente: numeroExpediente,
                    numeroLiquidacionUnico: numeroLiquidacionUnico,
                    codigoAduana: codigoAduana,
                    anio: anio,
                    numeroLiquidacion: numeroLiquidacion
                  }

                  numeroDatos.push(datos)
                }
                // else{
                //   console.log("Analizando REC")
                // }

            }
            
            await fs.unlink(pdfPath);

            return numeroDatos.length > 0 ? numeroDatos : false;
      }
        // } else {

        //     await fs.unlink(pdfPath)

        //     return false
        // }
    

    }catch(error){
        console.log('===> Documento sin contenido')
        
        await fs.unlink(pdfPath)

        return false
    }
}

module.exports = ExtraerDatosPdf 


// const datafile = 'Memo.pdf'
// const datafile = 'nuevo_caso.pdf'
// const datafile = 'rec_extensa.pdf'
// const datafile = 'test.pdf'
// const datafile = "CasosLiquidacion.pdf"


// async function basic(){
//   const Resultados = await ExtraerDatosPdf(datafile,'118-2024-043570')

//     // console.log(Resultados.length)

//     // console.log(Resultados)
// }

// basic()