const os = require('os')
const path = require('path')
const fs = require('fs/promises')

async function FormatoFecha(){
    const fechaActual = new Date()

    const hostName = os.hostname().toLocaleUpperCase()
    const userInfo = os.userInfo().username.toLocaleUpperCase()

    let diaActual = fechaActual.getDate()
    let mesActual = fechaActual.getMonth() + 1 
    let anioActual = fechaActual.getFullYear()
    let horaActual = fechaActual.getHours()
    let minutosActuales = fechaActual.getMinutes()
    let segundosActuales = fechaActual.getSeconds()
    
    //console.log(mesActual)

    if (diaActual.toString().length === 1){
        diaActual = `0${fechaActual.getDate()}D`
    } else {
        diaActual = fechaActual.getDate()+'D'
    }

    if (mesActual.toString().length === 1){
        mesActual = `0${fechaActual.getMonth()+1}M`
    } else {
        mesActual = `${fechaActual.getMonth()+1}M`
    }

    if (horaActual.toString().length === 1){
        horaActual = `0${fechaActual.getHours()}H`
    } else {
        horaActual = fechaActual.getHours()+'H'
    }

    if (minutosActuales.toString().length === 1){
        minutosActuales = `0${fechaActual.getMinutes()}M`
    } else {
        minutosActuales = `${fechaActual.getMinutes()}M`
    }

    if (segundosActuales.toString().length === 1){
        segundosActuales = `0${fechaActual.getSeconds()}S`
    } else {
        segundosActuales = fechaActual.getSeconds()+'S'
    }

    return `RESULTADO_CONSULTA_ECHASKI_${userInfo}_${diaActual}_${mesActual}_${anioActual}_${horaActual}_${minutosActuales}_${segundosActuales}`
}

async function CrearDirectorioDescargas() {
    const NombreResultadoCarpeta = await FormatoFecha()
    const rutaDescargarDocumentos = path.join(process.cwd(), NombreResultadoCarpeta)
    try {
        await fs.mkdir(rutaDescargarDocumentos, { recursive: true });
        return rutaDescargarDocumentos
        //console.log(`Directorio creado exitosamente ${rutaDescargarDocumentos}`);
    } catch (err) {
        console.log('Error al crear el directorio:', err);
    }
}  

module.exports = CrearDirectorioDescargas

// async function basic() {
//     console.log(await CrearDirectorioDescargas())
// }

// basic()